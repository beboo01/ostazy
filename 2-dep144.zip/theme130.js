(function(){var c=`
:root{--gbtn:linear-gradient(135deg,#0F6E8C 0%,#0B4F8A 55%,#0A3A6E 100%);--gbtn2:linear-gradient(135deg,#0E7C86 0%,#0B5E7A 100%)}
body{background:linear-gradient(160deg,#EEF3FA 0%,#E3EBF6 55%,#DCE8F3 100%) fixed!important}
:root[data-theme="dark"] body{background:linear-gradient(160deg,#0A1424 0%,#0C1B33 55%,#0A2236 100%) fixed!important}
button:not(.ghost):not(.wa-btn):not(.sm):not([class*="danger"]):not([class*="bad"]),.btn:not(.ghost):not(.wa-btn),a.btn:not(.wa-btn){background-image:var(--gbtn)!important;background-color:#0B4F8A!important;color:#fff!important;border-color:transparent!important}
button:not(.ghost):not(.wa-btn):not(.sm):hover{filter:brightness(1.08)}
nav.side .active,nav.side [aria-current],nav.side .on{background:var(--gbtn2)!important;color:#fff!important}
.stu .btns button:not(.wa-btn),.stu .btns a:not(.wa-btn){background-image:none}
.card,.panel{background-image:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,0))}
`;var s=document.createElement('style');s.id='theme130';s.textContent=c;document.head.appendChild(s);
/* replace bright cyan inline from dash128 */
var s2=document.createElement('style');s2.textContent='[style*="#00D4FF"],[style*="rgb(0, 212, 255)"]{background-image:var(--gbtn2)!important;color:#fff!important}';document.head.appendChild(s2);
})();
