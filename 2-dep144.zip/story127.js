/* ستوري ٢٠٢٧ بحسب المادة (أصلية): رياضيات، علوم، لغات. بدون بنفسجي أو وردي. */
(function(){'use strict';
if(typeof VTPLS==='undefined')return;
const base={duration:10,width:540,height:960,fps:30};
const T=(v,font,size,color,y,a,b,x)=>Object.assign({type:'text',value:v,font,weight:800,size,color,y,fadeIn:[a,b],maxW:440},x||{});
const S=(shape,o)=>Object.assign({type:'shape',shape},o);
const R=(x,y,w,h,color,a,o)=>S('rect',Object.assign({x,y,w,h,radius:30,color,fadeIn:[a,a+.6],zoomFrom:.94,zoomTo:1},o||{}));
const F=(d,f)=>({defaults:d,fields:f});
const FL=[['title','العنوان'],['sub','المادة'],['when','المواعيد'],['place','المكان'],['cta','دعوة']];
Object.assign(VTPLS,{
'math27':Object.assign({label:'رياضيات: شبكة',photo:false},F({title:'معسكر الرياضيات',sub:'الصف الثالث الإعدادي',when:'السبت والثلاثاء ٥ مساءً',place:'سنتر النور',cta:'احجز الآن'},FL),{
 build(v){const g=[];for(let i=0;i<8;i++)g.push(R(40,150+i*100,460,2,'#FFFFFF',.3+i*.1,{radius:1,alpha:.12}));for(let i=0;i<5;i++)g.push(R(40+i*115,150,2,700,'#FFFFFF',.3,{radius:1,alpha:.12}));
  return Object.assign({},base,{background:{from:'#0B1F44',to:'#0A3A66'},layers:g.concat([
  R(60,190,420,150,'#00B8E6',.8),T('+ − × ÷','Changa',60,'#0B1F44',285,1.1,1.8),
  T(v.title,'Noto Kufi Arabic',50,'#FFFFFF',440,1.6,2.4,{slideIn:'up'}),T(v.sub,'Cairo',32,'#BFE9FF',520,2.2,3),
  R(60,580,420,110,'#FFFFFF',3,{alpha:.12}),T(v.when,'Cairo',32,'#FFD166',645,3,3.8,{slideIn:'up'}),T(v.place,'Cairo',30,'#FFFFFF',740,3.6,4.4),
  R(130,800,280,80,'#F5B301',4.2,{radius:40}),T(v.cta,'Cairo',32,'#0B1F44',855,4.6,5.4,{maxW:240,pulse:{scale:1.04,period:1.6}})])})}}),
'sci27':Object.assign({label:'علوم: دوائر',photo:false},F({title:'معمل العلوم',sub:'تجارب وفهم وحفظ أسهل',when:'الأحد والأربعاء ٦ مساءً',place:'سنتر المستقبل',cta:'سجّل الآن'},FL),{
 build(v){return Object.assign({},base,{background:{from:'#064E3B',to:'#04271F'},layers:[
  S('circle',{x:-80,y:60,r:230,color:'#22C55E',alpha:.25,fadeIn:[0,1],zoomFrom:.6,zoomTo:1}),S('circle',{x:300,y:520,r:260,color:'#D4A72C',alpha:.22,fadeIn:[.3,1.3],zoomFrom:.6,zoomTo:1}),
  S('circle',{x:200,y:200,r:70,color:'#FFFFFF',alpha:.12,fadeIn:[.6,1.4],zoomFrom:.6,zoomTo:1}),
  T(v.title,'Noto Kufi Arabic',58,'#FFFFFF',330,.8,1.6,{slideIn:'up'}),R(240,370,60,5,'#D4A72C',1.6,{radius:3}),T(v.sub,'Cairo',32,'#CDEFD9',460,1.8,2.6,{maxW:420}),
  R(50,560,440,190,'#FFFFFF',3,{alpha:.1}),T(v.when,'Cairo',32,'#FFE08A',630,3.2,4,{slideIn:'up'}),T(v.place,'Cairo',30,'#FFFFFF',705,3.8,4.6),
  R(130,800,280,80,'#D4A72C',4.4,{radius:40}),T(v.cta,'Cairo',32,'#04271F',855,4.8,5.6,{maxW:240,pulse:{scale:1.04,period:1.6}})]})}}),
'lang27':Object.assign({label:'لغات: بطاقات',photo:false},F({title:'نادي اللغة',sub:'عربي وإنجليزي بثقة',when:'الإثنين والخميس ٤ عصرًا',place:'سنتر الأمل',cta:'احجز مقعدك'},FL),{
 build(v){return Object.assign({},base,{background:{from:'#FFF1E3',to:'#FFE3C7'},layers:[
  R(40,90,460,260,'#7C2D12',.2),T('أ  Aa','Changa',72,'#FF8A1F',185,.6,1.2),T(v.title,'Noto Kufi Arabic',46,'#FFFFFF',290,.9,1.7,{slideIn:'up'}),
  R(40,370,460,130,'#FFFFFF',1.2),T(v.sub,'Cairo',32,'#7C2D12',440,1.6,2.4,{maxW:420}),
  R(40,520,460,120,'#FF8A1F',2),T(v.when,'Cairo',32,'#FFFFFF',585,2.4,3.2,{slideIn:'up'}),
  R(40,660,460,100,'#FFFFFF',2.8),T(v.place,'Cairo',32,'#7C2D12',720,3.2,4),
  R(40,780,460,100,'#7C2D12',3.4),T(v.cta,'Cairo',34,'#FFD7B0',840,3.8,4.6,{maxW:420,pulse:{scale:1.03,period:1.6}})]})}})
});
if(typeof fillVTplSel==='function')fillVTplSel();
})();
