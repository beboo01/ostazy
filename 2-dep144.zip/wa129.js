(function(){
var ICON='<svg class="wa-ic" viewBox="0 0 32 32" width="20" height="20" aria-hidden="true"><path fill="#fff" d="M16 3C9 3 3.4 8.6 3.4 15.5c0 2.3.6 4.4 1.7 6.3L3 29l7.4-2c1.8 1 3.800 1.500 5.800 1.500h0c6.900 0 12.500-5.600 12.500-12.500S22.900 3 16 3zm0 22.800c-1.900 0-3.700-.5-5.300-1.500l-.4-.2-4.400 1.200 1.200-4.300-.3-.4a10.200 10.200 0 0 1-1.600-5.500C5.200 9.900 10 5.200 16 5.200s10.800 4.700 10.800 10.600S21.900 25.800 16 25.800zm5.900-7.700c-.3-.2-1.900-.9-2.200-1s-.5-.2-.7.200-.8 1-1 1.200-.4.200-.7.100a8.700 8.700 0 0 1-4.300-3.800c-.3-.6.300-.5.900-1.700.1-.2 0-.4 0-.5l-1-2.300c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.100-.8.400s-1 1-1 2.500 1.100 2.900 1.200 3.100 2.100 3.300 5.200 4.600c1.900.8 2.700.9 3.600.7.600-.1 1.900-.8 2.100-1.500s.3-1.400.2-1.500-.3-.2-.6-.3z"/></svg>';
var css='.wa-btn{background:#25D366!important;background-image:none!important;color:#fff!important;border:0!important;display:inline-flex!important;align-items:center;justify-content:center;gap:8px;font-weight:700;text-decoration:none;box-shadow:0 2px 8px rgba(37,211,102,.35)}.wa-btn:hover{background:#1ebe5a!important}.wa-btn .wa-ic{flex:none;display:inline-block}';
css+='html body a.wa-btn,html body button.wa-btn,html[data-theme] body .stu .btns .wa-btn,html[data-theme] body #auth .wa-btn{background:#25D366!important;background-image:none!important;color:#fff!important;border:0!important;text-shadow:none}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
function isWA(el){
 var h=(el.getAttribute('href')||'');
 if(/wa\.me|whatsapp\.com/i.test(h))return true;
 if(/\bwa\b/.test(el.className||''))return true;
 var oc=el.getAttribute('onclick')||'';
 if(/wa\.me|whatsapp/i.test(oc))return true;
 var t=(el.textContent||'').trim();
 return t.length<40&&/واتساب|واتس|whatsapp|ابعت لولي الأمر/i.test(t);
}
function scan(root){
 (root||document).querySelectorAll('a,button').forEach(function(el){
  if(el.dataset.waDone)return;
  if(!isWA(el))return;
  if(el.closest('[data-no-wa]'))return;
  el.dataset.waDone='1';el.classList.add('wa-btn');
  if(!el.querySelector('.wa-ic'))el.insertAdjacentHTML('afterbegin',ICON);
 });
}
var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(function(){scan()},120)}).observe(document.documentElement,{childList:true,subtree:true});
scan();
})();
