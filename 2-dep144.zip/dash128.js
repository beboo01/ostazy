/* تحسين لوحة الرئيسية: بطاقات مؤشرات ملوّنة بأيقونة وحلقة نسبة. بدون بنفسجي أو وردي. */
(function(){'use strict';
const css=`.ostazy-app .stats .stat.k28{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:18px 10px 14px;border-radius:20px;background:var(--k-bg,var(--field)) !important;border:1px solid rgba(0,0,0,.05) !important;overflow:hidden;text-align:center}
.ostazy-app #view>.hero .stats .stat.k28{padding:20px 8px 14px !important;background:var(--k-bg) !important;border:1px solid rgba(0,0,0,.05) !important;border-radius:20px}
:root[data-theme=dark] .ostazy-app #view>.hero .stats .stat.k28,:root[data-theme=dark] .ostazy-app .stats .stat.k28{background:color-mix(in srgb,var(--k-c) 20%,#0E1C38) !important;border-color:rgba(255,255,255,.08) !important}
:root[data-theme=dark] .ostazy-app .stat.k28 strong,:root[data-theme=dark] .ostazy-app .stat.k28 span,:root[data-theme=dark] .ostazy-app .stat.k28 .k28r b{color:#fff !important}
.ostazy-app .stats .stat.k28::before{content:"";position:absolute;inset:0 0 auto 0;height:4px;background:var(--k-c)}
.ostazy-app .stat.k28 .k28i{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--k-c);color:#fff;margin-bottom:4px}
.ostazy-app .stat.k28 .k28i svg{width:22px;height:22px}
.ostazy-app .stat.k28 strong{font-size:28px;line-height:1.1;color:var(--k-t,inherit);display:block;text-align:center}
.ostazy-app .stat.k28 span{font-size:13px;opacity:.8;text-align:center;display:block}
.ostazy-app .stat.k28 .k28r{position:relative;width:64px;height:64px;display:flex;align-items:center;justify-content:center;margin-bottom:2px}
.ostazy-app .stat.k28 .k28r svg{position:absolute;inset:0;width:64px;height:64px;transform:rotate(-90deg)}
.ostazy-app .stat.k28 .k28r b{position:relative;font-size:15px;color:var(--k-t);font-weight:800}
.ostazy-app .stat.k28 .k28r+strong{display:none}`;
const ST=document.createElement('style');ST.textContent=css;document.head.appendChild(ST);
const IC={
'طالب':['#1D4ED8','#EAF1FF','<path d="M16 11a3 3 0 100-6 3 3 0 000 6zM8 12a3 3 0 100-6 3 3 0 000 6zM2 20c0-3 3-5 6-5s6 2 6 5M14 15c3 0 8 1 8 5" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>'],
'نسبة الحضور':['#16A34A','#E8F8EE',''],
'متوسط الدرجات':['#D99A00','#FFF6DD','<path d="M5 20V10M12 20V4M19 20v-7" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>'],
'تحصيل بمبالغ مسجلة':['#0D9488','#E4F7F5','<rect x="3" y="6" width="18" height="13" rx="3" stroke="currentColor" stroke-width="2" fill="none"/><path d="M3 10h18" stroke="currentColor" stroke-width="2"/>'],
'تقدير المطلوب بالسعر الحالي':['#EA7A0B','#FFF0E0','<circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2" fill="none"/><path d="M12 7v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'],
'متأخرين عن شهور':['#C2410C','#FDEBDD','<path d="M12 3l10 18H2z" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round"/><path d="M12 10v5M12 18v.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>']};
function deco(){document.querySelectorAll('.ostazy-app .stats .stat:not(.k28)').forEach(el=>{
 const s=el.querySelector('span'),n=el.querySelector('strong');if(!s||!n)return;const lab=s.textContent.trim();const d=IC[lab];if(!d)return;
 el.classList.add('k28');el.style.setProperty('--k-c',d[0]);el.style.setProperty('--k-bg',d[1]);el.style.setProperty('--k-t',d[0]);
 const val=n.textContent.trim();const pm=/^(\d+(?:\.\d+)?)\s*%$/.exec(val);
 if(pm){const p=Math.min(100,+pm[1]),C=2*Math.PI*26;const r=document.createElement('div');r.className='k28r';r.innerHTML='<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" fill="none" stroke="rgba(0,0,0,.08)" stroke-width="7"/><circle cx="32" cy="32" r="26" fill="none" stroke="'+d[0]+'" stroke-width="7" stroke-linecap="round" stroke-dasharray="'+(C*p/100).toFixed(1)+' '+C.toFixed(1)+'"/></svg><b>'+val+'</b>';el.insertBefore(r,n)}
 else if(d[2]){const i=document.createElement('div');i.className='k28i';i.innerHTML='<svg viewBox="0 0 24 24">'+d[2]+'</svg>';el.insertBefore(i,n)}
})}
const v=document.getElementById('view');if(v){new MutationObserver(deco).observe(v,{childList:true,subtree:true});}
document.addEventListener('DOMContentLoaded',deco);deco();

const css2=`.ob28{background:linear-gradient(135deg,#0B1F44,#0A3A66);color:#fff;border-radius:24px;padding:20px;margin:0 0 14px}
.ob28 h3{margin:0 0 4px;font-size:20px;color:#fff;text-align:center}.ob28 p{margin:0 0 14px;text-align:center;opacity:.85;font-size:14px}
.ob28 .obs{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}
.ob28 button{display:flex;align-items:center;justify-content:center;gap:10px;text-align:center;min-height:56px;border-radius:16px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.1);color:#fff;font:800 15px Tajawal,sans-serif;cursor:pointer;padding:10px 14px}
.ob28 button:hover{background:rgba(255,255,255,.18)}.ob28 button i{font-style:normal;width:30px;height:30px;border-radius:50%;background:#0E7C86;color:#0B1F44;display:flex;align-items:center;justify-content:center;font-weight:800;flex:none}`;
const S2=document.createElement('style');S2.textContent=css2;document.head.appendChild(S2);
function onboard(){const v=document.getElementById('view');if(!v||v.querySelector('.ob28'))return;const h=v.querySelector('h2');if(!h||h.textContent.indexOf('في أستاذي')<0)return;
 const st=[['g','أضف أول مجموعة'],['s','أضف طلابك'],['a','سجّل أول حضور'],['p','تابع المصاريف']];
 const d=document.createElement('div');d.className='ob28';d.innerHTML='<h3>ابدأ في ٤ خطوات سريعة</h3><p>كل خطوة بتاخد دقيقة، وبياناتك بتفضل خاصة بيك.</p><div class="obs">'+st.map((x,i)=>'<button type="button" data-go="'+x[0]+'"><i>'+(i+1)+'</i><span>'+x[1]+'</span></button>').join('')+'</div>';
 d.addEventListener('click',e=>{const b=e.target.closest('button[data-go]');if(!b)return;const t=[...document.querySelectorAll('button[data-t="'+b.dataset.go+'"]')];const x=t.find(y=>y.offsetParent)||t[0];if(x)x.click()});
 const hero=v.querySelector('.hero')||h.parentNode;hero.parentNode.insertBefore(d,hero)}
if(v){new MutationObserver(onboard).observe(v,{childList:true,subtree:true})}document.addEventListener('DOMContentLoaded',onboard);onboard();

const css3=`#auth .row{display:flex !important;flex-direction:column !important;gap:10px}#auth .row>button{width:100% !important;flex:none !important}#auth #li{min-height:56px;font-size:18px;width:100%}#auth #su{min-height:48px;width:100%}
#auth #aem,#auth #apw{text-align:left}#auth .pw28{position:relative}
#auth #trialRequest button{min-height:44px;background:transparent !important;color:#0F7A3E !important;border:1.5px solid #16A34A !important;box-shadow:none !important;font-size:14px}
:root[data-theme=dark] #auth #trialRequest button{color:#6EE7A0 !important}
#auth .eye28{display:block;margin:6px auto 0;background:none;border:0;color:#0B7FA6;font:800 13px Tajawal,sans-serif;cursor:pointer;padding:6px 10px;text-align:center}
#wiz{max-width:560px;margin:0 auto;text-align:center}#wiz h1,#wiz p{text-align:center}#wiz .card{text-align:right;padding:22px}
#wiz .row{display:flex !important;gap:10px}#wiz .row>#next{flex:1 1 auto !important;width:100% !important;min-height:52px;font-size:17px}#wiz #back{min-height:52px;min-width:96px}
#wiz .st28{direction:rtl;display:flex;justify-content:center;gap:8px;margin:10px 0 14px}#wiz .st28 i{width:34px;height:6px;border-radius:3px;background:rgba(0,0,0,.12)}#wiz .st28 i.on{background:#00B8E6}`;
const S3=document.createElement('style');S3.textContent=css3;document.head.appendChild(S3);
function eye(){const pw=document.getElementById('apw');if(!pw||document.querySelector('.eye28'))return;const b=document.createElement('button');b.type='button';b.className='eye28';b.textContent='إظهار الباسورد';b.onclick=()=>{const s=pw.type==='password';pw.type=s?'text':'password';b.textContent=s?'إخفاء الباسورد':'إظهار الباسورد'};pw.insertAdjacentElement('afterend',b)}
function wizSteps(){const w=document.getElementById('wiz');if(!w||w.querySelector('.st28'))return;const d=document.createElement('div');d.className='st28';d.innerHTML='<i></i><i></i><i></i>';const c=w.querySelector('.card');c.parentNode.insertBefore(d,c);const upd=()=>{const t=(document.getElementById('wt')||{}).textContent||'';const n=/بتدر|المادة|إيه/.test(t)?0:/مجموع|مواعيد/.test(t)?1:2;d.querySelectorAll('i').forEach((x,i)=>x.classList.toggle('on',i<=n))};new MutationObserver(upd).observe(document.getElementById('wt'),{childList:true,subtree:true,characterData:true});upd()}
document.addEventListener('DOMContentLoaded',()=>{eye();wizSteps()});eye();wizSteps();

const css4=`.ostazy-app #view .stu{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:12px 4px;border-bottom:1px solid rgba(0,0,0,.06)}
:root[data-theme=dark] .ostazy-app #view .stu{border-bottom-color:rgba(255,255,255,.08)}
.ostazy-app #view .stu>span{display:flex;align-items:center;gap:10px;font-weight:800;font-size:16px;flex:1 1 200px;min-width:0}
.ostazy-app #view .stu .av28{width:40px;height:40px;border-radius:50%;background:#0B1F44;color:#0E7C86;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:17px;flex:none}
.ostazy-app #view .stu .btns button[data-a]{min-width:74px;min-height:42px;display:inline-flex;align-items:center;justify-content:center;text-align:center;border-radius:12px;font-weight:800}
.ostazy-app #view .stu .btns button[data-a].ghost{background:transparent;color:inherit;border:1.5px solid rgba(100,116,139,.35);box-shadow:none}
.ostazy-app #view .stu .btns button[data-a="p"]:not(.ghost){background:#16A34A;border-color:#16A34A;color:#fff}
.ostazy-app #view .stu .btns button[data-a="l"]:not(.ghost){background:#F59E0B;border-color:#F59E0B;color:#2B1B00}
.ostazy-app #view .stu .btns button[data-a="e"]:not(.ghost){background:#2563EB;border-color:#2563EB;color:#fff}
.ostazy-app #view .stu .btns button[data-a="x"]:not(.ghost){background:#DC2626;border-color:#DC2626;color:#fff}`;
const S4=document.createElement('style');S4.textContent=css4;document.head.appendChild(S4);
function avs(){document.querySelectorAll('.ostazy-app #view .stu:not(.av-d)').forEach(r=>{r.classList.add('av-d');const sp=r.querySelector(':scope>span');if(!sp||sp.querySelector('.av28'))return;const nm=(sp.firstChild&&sp.firstChild.nodeType===3?sp.firstChild.nodeValue:sp.textContent).trim();const a=document.createElement('div');a.className='av28';a.textContent=nm.charAt(0)||'?';sp.insertBefore(a,sp.firstChild)})}
if(v){new MutationObserver(avs).observe(v,{childList:true,subtree:true})}avs();

const css5=`.ostazy-app .content>#bill>.card,.ostazy-app section.customer-account{padding:8px 14px !important;margin:0 0 8px !important;border-radius:14px !important;font-size:13px;line-height:1.5}
.ostazy-app section.customer-account .row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:0}
.ostazy-app section.customer-account .row b{font-size:14px}
.ostazy-app section.customer-account .row button{min-height:34px;padding:4px 12px;font-size:13px}
.ostazy-app .content>#bill>.card{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.ostazy-app #bill details{display:inline-block;margin:0}.ostazy-app #bill details summary{font-size:13px;padding:2px 0;min-height:0}
.ostazy-app #bill details[open]{flex-basis:100%}`;
const S5=document.createElement('style');S5.textContent=css5;document.head.appendChild(S5);

const css6=`@media(max-width:700px){.ostazy-app #bill{gap:6px;margin-bottom:10px}.ostazy-app #bill>.card,.ostazy-app #bill>.customer-account,.ostazy-app #bill>.customer-account.workspaceAccount62,.ostazy-app #bill>.card:not(.customer-account){flex:1 1 100% !important;padding:8px 12px !important;font-size:13px !important;line-height:1.6 !important}
.ostazy-app #bill>.customer-account .row{flex-wrap:nowrap}.ostazy-app #bill>.customer-account .row b{white-space:nowrap}}`;
const S6=document.createElement('style');S6.textContent=css6;document.head.appendChild(S6);

const css7=`@media(min-width:900px){.ostazy-app nav.side{height:auto !important;max-height:none !important;overflow:visible !important}.ostazy-app nav.side .tabs{height:auto !important;max-height:none !important;overflow:visible !important;padding-bottom:10px}
.ostazy-app nav.side .tabs button{min-height:46px !important;flex:none !important}
.ostazy-app nav.side .tabs button[aria-selected=true]{background:linear-gradient(90deg,#0E7C86,#0B5E7A) !important;color:#0B1F44 !important;font-weight:800}
.ostazy-app nav.side .tabs button:not([aria-selected=true]):hover{background:#E8F7FC !important}}`;
const S7=document.createElement('style');S7.textContent=css7;document.head.appendChild(S7);

const css8=`.ostazy-app #view .stu .btns{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:flex-start}
.ostazy-app #view .stu .btns>button,.ostazy-app #view .stu .btns>a{box-sizing:border-box;min-height:42px;height:42px;min-width:74px;padding:0 14px !important;display:inline-flex !important;align-items:center;justify-content:center;text-align:center;line-height:1;font-size:14px !important;font-weight:800;border-radius:12px;margin:0 !important;white-space:nowrap;text-decoration:none}
.ostazy-app #view .stu .btns>a.wa,.ostazy-app #view .stu .btns>a[href*="wa.me"]{background:#16A34A;color:#fff;border:0}
@media(max-width:700px){.ostazy-app #bill>.customer-account{padding:6px 12px !important}.ostazy-app #bill>.customer-account .row{width:100%;justify-content:space-between !important;align-items:center}
.ostazy-app #bill>.customer-account .row>button{width:auto !important;max-width:60%;min-height:38px;flex:0 0 auto;padding:0 16px;display:inline-flex;align-items:center;justify-content:center;background:#E8F7FC;border:1px solid #BFE9F7;color:#0B1F44}
.ostazy-app #view .stu .btns{width:100%}.ostazy-app #view .stu .btns>button,.ostazy-app #view .stu .btns>a{flex:1 1 calc(25% - 8px);min-width:64px;padding:0 6px !important}}`;
const S8=document.createElement('style');S8.textContent=css8;document.head.appendChild(S8);

const css9=`.ostazy-app #bill>.customer-account>*:not(.row){margin-top:0 !important;margin-bottom:0 !important}.ostazy-app #bill>.customer-account>*:not(.row):empty{display:none !important}.ostazy-app #bill>.customer-account{min-height:0 !important;height:auto !important;align-self:flex-start}`;
const S9=document.createElement('style');S9.textContent=css9;document.head.appendChild(S9);
})();
