/* شهادات ٢٠٢٧ بحسب المادة (أصلية): رياضيات، علوم، فيزياء، كيمياء، أحياء، عربي، إنجليزي × لونين. بدون بنفسجي أو وردي. */
(function(){'use strict';
if(typeof CERTS==='undefined'||typeof LIBMETA==='undefined')return;
const PAL={navy:{n:'كحلي وسماوي',a:'#0B1F44',b:'#00B8E6',c:'#EAF6FC',g:'#F5B301'},green:{n:'أخضر وذهبي',a:'#064E3B',b:'#D4A72C',c:'#EAF6EE',g:'#22C55E'}};
const I={
math:['الرياضيات','<path d="M5 7h14M12 4v6M5 17h14M7 14l10 6M17 14L7 20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>','شهادة تميّز في الرياضيات'],
sci:['العلوم','<path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round"/>','شهادة تميّز في العلوم'],
phys:['الفيزياء','<circle cx="12" cy="12" r="2" fill="currentColor"/><ellipse cx="12" cy="12" rx="10" ry="4" stroke="currentColor" stroke-width="1.8" fill="none"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)" stroke="currentColor" stroke-width="1.8" fill="none"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)" stroke="currentColor" stroke-width="1.8" fill="none"/>','شهادة تميّز في الفيزياء'],
chem:['الكيمياء','<circle cx="7" cy="8" r="3" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="17" cy="8" r="3" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="12" cy="17" r="3" stroke="currentColor" stroke-width="2" fill="none"/><path d="M9.5 9.5L11 14.5M14.5 9.5L13 14.5M10 8h4" stroke="currentColor" stroke-width="1.6"/>','شهادة تميّز في الكيمياء'],
bio:['الأحياء','<path d="M12 21c-5 0-8-4-8-9 5 0 8 3 8 9zM12 21c5 0 8-4 8-9-5 0-8 3-8 9zM12 21V8M12 8c0-3 1-5 3-6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>','شهادة تميّز في الأحياء'],
ar:['اللغة العربية','<text x="12" y="19" text-anchor="middle" font-size="20" font-weight="800" fill="currentColor" font-family="Tajawal,Cairo">أ</text>','شهادة تميّز في اللغة العربية'],
en:['اللغة الإنجليزية','<text x="12" y="18" text-anchor="middle" font-size="15" font-weight="800" fill="currentColor" font-family="Tajawal,Cairo">Aa</text>','شهادة تميّز في الإنجليزية']};
const px=(x,y,w,h,st,inner)=>`<div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;height:${h}px;${st||''}">${inner||''}</div>`;
const tx=(x,y,w,h,t,st)=>px(x,y,w,h,`display:flex;align-items:center;justify-content:center;text-align:center;line-height:1.35;${st||''}`,t);
const nsz=(m,big)=>{const l=String(m.name).length;return l>40?big*.55:l>28?big*.7:l>18?big*.85:big};
const R=(k,m,c)=>{const d=I[k];return `<div class="kpage" style="background:${c.c};font-family:Tajawal,Cairo,sans-serif;color:${c.a}">`+
 px(40,40,1043,714,`background:#fff;border-radius:40px;border:3px solid ${c.a}`)+
 px(40,40,1043,200,`background:${c.a};border-radius:40px 40px 0 0`)+
 px(43,43,1037,194,'overflow:hidden;border-radius:37px 37px 0 0',px(20,90,260,260,`border-radius:50%;border:2px solid ${c.b};opacity:.28`)+px(80,50,200,200,`border-radius:50%;border:2px solid ${c.b};opacity:.2`)+px(800,-60,220,220,`border-radius:50%;border:2px solid ${c.b};opacity:.2`))+
 px(481,70,160,160,`border-radius:50%;background:${c.b};color:${c.a};box-shadow:0 8px 0 ${c.g}`,tx(0,0,160,160,`<svg width="92" height="92" viewBox="0 0 24 24" style="color:${c.a}">${d[1]}</svg>`))+
 tx(60,258,1003,56,`<div style="font-family:Changa,Tajawal;font-size:44px;font-weight:800;color:${c.a}">${m.title||d[2]}</div>`)+
 px(511,318,100,5,`background:${c.g};border-radius:3px`)+
 tx(60,334,1003,30,`<div style="font-size:18px;color:#64748B;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+
 tx(80,368,963,96,`<div style="font-family:'El Messiri',Amiri,serif;font-size:${nsz(m,62)}px;font-weight:800;color:${c.a}">${m.name}</div>`)+
 tx(140,470,843,80,`<div style="font-size:19px;font-weight:700;color:#334155;line-height:1.7">${m.reason}</div>`)+
 px(80,600,440,110,`background:${c.c};border-radius:24px`,tx(0,0,440,110,`<div><div style="font-size:12px;color:#64748B;font-weight:800">المدرّس · ${d[0]}</div><div style="font-size:23px;font-weight:800;color:${c.a}">${m.teacher}</div></div>`))+
 px(603,600,440,110,`background:${c.a};border-radius:24px`,tx(0,0,440,110,`<div><div style="font-size:12px;color:${c.b};font-weight:800">${m.stageLabel}</div><div style="font-size:21px;font-weight:800;color:#fff">${m.date} · ${m.school}</div></div>`))+`</div>`};
Object.keys(I).forEach(k=>Object.keys(PAL).forEach((pk,vi)=>{const id='lib-sub27-'+k+'-'+pk;CERTS[id]={label:I[k][0]+' — '+PAL[pk].n,cat:'modern',subjects:[k],aud:['child','mature'],render:m=>R(k,m,PAL[pk])};LIBMETA[id]={fam:'sub27',cat:'modern',pal:pk,v:vi,label:CERTS[id].label}}));
})();
