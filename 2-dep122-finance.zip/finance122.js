/* مصروفات وربح المدرس + خصم وأقساط لكل طالب. بيانات كل مدرس في حسابه فقط (نفس حفظ الحساب)، ولا يُرسل شيء لأي جهة. */
(function(){'use strict';
const view=document.getElementById('view');if(!view||typeof C==='undefined')return;
const q=(s,r)=>(r||document).querySelector(s);
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
const num=v=>{v=parseFloat(String(v).replace(/[\u0660-\u0669]/g,d=>d.charCodeAt(0)-1632));return isFinite(v)?v:0};
function net(sid){const base=+S.price||0,d=S.disc&&S.disc[sid];if(!d)return base;
 return d.t==='pct'?Math.max(0,Math.round(base*(1-clamp(d.v,0,100)/100))):Math.max(0,Math.round(base-Math.max(0,d.v)))}
function openPays(sid,m){const L=(S.paymentLedger||[]).filter(x=>x.studentId===sid&&x.month===m);const rev=new Set(L.filter(x=>x.kind==='reversal').map(x=>x.paymentId));return L.filter(x=>x.kind==='payment'&&!rev.has(x.id))}
function paidSoFar(sid,m){return openPays(sid,m).reduce((a,x)=>a+(+x.amount||0),0)}
function remain(sid,m){if(S.pay&&S.pay[m]&&S.pay[m][sid]&&!openPays(sid,m).length)return 0;return Math.max(0,net(sid)-paidSoFar(sid,m))}
window.ozNet=net;window.ozRemain=remain;window.ozPaidSoFar=paidSoFar;window.ozOpenPays=openPays;
/* الدفع الكامل يسجّل المتبقي فقط، والإلغاء يعكس كل الدفعات المفتوحة للشهر */
const orig=C.togglePayment;
C.togglePayment=function(state,month,sid,id,now){
 const was=!!(state.pay[month]&&state.pay[month][sid]);const rem=was?0:remain(sid,month);
 orig.apply(C,arguments);
 const L=state.paymentLedger;
 if(!was){const last=L[L.length-1];if(last&&last.id===id&&last.kind==='payment'){if(rem<=0)L.pop();else last.amount=rem}}
 else{const t=now||new Date().toISOString();openPays(sid,month).forEach((p,i)=>{L.push({id:id+'r'+i,month,studentId:sid,studentName:p.studentName,kind:'reversal',amount:p.amount,paymentId:p.id,occurredAt:t})})}
};
function addTags(){view.querySelectorAll('button[data-a="pay"]').forEach(b=>{
 const row=b.closest('.stu');if(!row)return;const sid=b.dataset.id;
 if(!b.parentNode.querySelector('[data-fin]')){const f=document.createElement('button');f.type='button';f.className='sm ghost';f.setAttribute('data-fin',sid);f.textContent='خصم / أقساط';b.parentNode.appendChild(f)}
 const nm=row.querySelector('span');if(!nm||nm.querySelector('[data-fintag]'))return;
 const d=S.disc&&S.disc[sid],part=paidSoFar(sid,pmonth),paidFlag=!!(S.pay&&S.pay[pmonth]&&S.pay[pmonth][sid]);let t='';
 if(d&&d.v>0)t+=' خصم '+(d.t==='pct'?d.v+'%':d.v+' جنيه');
 if(part>0&&!paidFlag)t+=(t?' · ':' ')+'دفع '+part+' وباقي '+remain(sid,pmonth);
 if(t){const s=document.createElement('span');s.className='tag';s.setAttribute('data-fintag','1');s.textContent=t.trim();nm.appendChild(document.createTextNode(' '));nm.appendChild(s)}
 else{const s=document.createElement('i');s.setAttribute('data-fintag','0');s.hidden=true;nm.appendChild(s)}})}
function expCard(){
 if(!q('#pm',view)||q('#ozExp',view))return;
 S.expenses=Array.isArray(S.expenses)?S.expenses:[];
 const m=pmonth,list=S.expenses.filter(x=>x.month===m),tot=list.reduce((a,x)=>a+(+x.amount||0),0),col=C.monthlyTotals(S,m).amount,prof=col-tot;
 const esc2=typeof esc==='function'?esc:(s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
 const d=document.createElement('div');d.id='ozExp';d.className='card';
 d.innerHTML='<h2>مصروفات وربح الشهر</h2><div class="stats"><div class="stat"><strong>'+col+'</strong><span>اتحصّل</span></div><div class="stat"><strong>'+tot+'</strong><span>مصروفات</span></div><div class="stat"><strong style="color:'+(prof<0?'#B91C1C':'inherit')+'">'+prof+'</strong><span>صافي الربح</span></div></div>'
 +list.map(x=>'<div class="stu"><span>'+esc2(x.title)+' <span class="tag">'+esc2(x.amount)+' جنيه</span></span><div class="btns"><button type="button" class="sm ghost" data-expdel="'+esc2(x.id)+'">حذف</button></div></div>').join('')
 +'<div class="row" style="margin-top:10px"><div><label for="ozEt">بند المصروف</label><input id="ozEt" maxlength="60" placeholder="إيجار القاعة"></div><div><label for="ozEa">المبلغ (جنيه)</label><input id="ozEa" type="number" min="0" step="1" inputmode="numeric"></div></div><button type="button" class="sm" id="ozEadd" style="margin-top:8px">إضافة مصروف</button><p class="note">بيانات المصروفات في حسابك أنت فقط.</p>';
 view.appendChild(d)}
const mo=new MutationObserver(()=>{addTags();expCard()});mo.observe(view,{childList:true,subtree:true});addTags();expCard();
const ok=()=>{if(typeof active==='function'&&!active()){if(typeof flash==='function')flash();return false}return true};
function save(){persist();render()}
view.addEventListener('click',e=>{
 const a=e.target.closest('#ozEadd');if(a){if(!ok())return;const t=(q('#ozEt').value||'').trim().slice(0,60),v=Math.round(num(q('#ozEa').value));if(!t||v<=0||v>10000000){alert('اكتب اسم البند ومبلغ صحيح');return}
  S.expenses=S.expenses||[];if(S.expenses.length>=5000){alert('وصلت للحد الأقصى من المصروفات');return}
  S.expenses.push({id:rid(),month:pmonth,title:t,amount:v});save();return}
 const x=e.target.closest('[data-expdel]');if(x){if(!ok()||!confirm('حذف المصروف؟'))return;S.expenses=(S.expenses||[]).filter(y=>y.id!==x.dataset.expdel);save();return}
 const f=e.target.closest('[data-fin]');if(f)openFin(f.dataset.fin)});
function openFin(sid){
 const st=findSt(sid);if(!st)return;const old=q('#ozFin');if(old)old.remove();
 const w=document.createElement('div');w.id='ozFin';w.setAttribute('role','dialog');w.setAttribute('aria-modal','true');document.body.appendChild(w);document.body.classList.add('rc-open');
 const close=()=>{w.remove();document.body.classList.remove('rc-open')};
 const esc2=typeof esc==='function'?esc:(s=>String(s));
 function fill(){const d=(S.disc&&S.disc[sid])||{t:'',v:0},m=pmonth,ps=openPays(sid,m),part=paidSoFar(sid,m),rem=remain(sid,m);
  w.innerHTML='<div class="rc-box"><div class="fin-p"><h3>'+esc2(st.name)+'</h3><small>'+esc2(mname(m))+'</small>'
  +'<div class="rc-r"><span>سعر الشهر</span><b>'+S.price+' جنيه</b></div><div class="rc-r"><span>بعد الخصم</span><b>'+net(sid)+' جنيه</b></div><div class="rc-r"><span>المدفوع</span><b>'+part+' جنيه</b></div><div class="rc-r"><span>المتبقي</span><b>'+rem+' جنيه</b></div>'
  +'<h4 class="st-t">الخصم الدائم للطالب</h4><div class="row"><div><label for="ozDt">النوع</label><select id="ozDt"><option value="">بدون خصم</option><option value="pct"'+(d.t==='pct'?' selected':'')+'>نسبة %</option><option value="amt"'+(d.t==='amt'?' selected':'')+'>مبلغ ثابت</option></select></div><div><label for="ozDv">القيمة</label><input id="ozDv" type="number" min="0" step="1" value="'+(d.v||'')+'"></div></div><button type="button" class="sm" id="ozDs" style="margin-top:8px">حفظ الخصم</button>'
  +'<h4 class="st-t">أقساط هذا الشهر</h4>'+(ps.length?ps.map(p=>'<div class="rc-r"><span>'+new Date(p.occurredAt).toLocaleDateString('ar-EG-u-nu-latn',{day:'numeric',month:'short'})+'</span><b>'+p.amount+' جنيه</b></div>').join(''):'<p class="note">لا دفعات مسجلة.</p>')
  +(rem>0?'<div class="row" style="margin-top:8px"><div><label for="ozIa">قسط جديد (جنيه)</label><input id="ozIa" type="number" min="1" max="'+rem+'" step="1" value=""></div></div><button type="button" class="sm" id="ozIs" style="margin-top:8px">تسجيل قسط</button>':'')
  +'</div><div class="rc-b"><button type="button" class="ghost" id="ozFc">إغلاق</button></div></div>';
  q('#ozFc',w).onclick=close;
  q('#ozDs',w).onclick=()=>{if(!ok())return;const t=q('#ozDt',w).value,v=clamp(num(q('#ozDv',w).value),0,t==='pct'?100:1000000);S.disc=S.disc||{};if(!t||v<=0)delete S.disc[sid];else S.disc[sid]={t,v:Math.round(v*100)/100};persist();render();fill()};
  const is=q('#ozIs',w);if(is)is.onclick=()=>{if(!ok())return;const v=Math.round(num(q('#ozIa',w).value));const r=remain(sid,pmonth);if(v<=0||v>r){alert('المبلغ لازم يكون من 1 إلى '+r);return}
   S.paymentLedger=S.paymentLedger||[];S.paymentLedger.push({id:rid(),month:pmonth,studentId:sid,studentName:st.name,kind:'payment',amount:v,currency:'EGP',occurredAt:new Date().toISOString(),part:true});
   if(remain(sid,pmonth)<=0){S.pay[pmonth]=S.pay[pmonth]||{};S.pay[pmonth][sid]=true}persist();render();fill()}}
 w.addEventListener('click',e=>{if(e.target===w)close()});fill();q('#ozFc',w).focus()}
})();
