/* DEP153: new-teacher UX fixes: collapsible account block, clearer empty states, tidy status bar */
(function(){
var css='.acc153{display:block;width:100%;box-sizing:border-box;margin:0 0 12px;border-radius:18px;border:1px solid rgba(14,124,134,.25);background:var(--card,#fff);overflow:hidden}.acc153>summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;min-height:48px;padding:8px 14px;font-weight:800;text-align:center}.acc153>summary::-webkit-details-marker{display:none}.acc153>summary:after{content:"\\25BE";font-size:14px;transition:transform .2s}.acc153[open]>summary:after{transform:rotate(180deg)}.acc153>.card{margin:0;border:0;border-top:1px solid rgba(14,124,134,.15);border-radius:0;box-shadow:none}.acc153 small{font-weight:600;opacity:.75}'
+'.note153{margin:12px 0;padding:12px 14px;border-radius:14px;text-align:center;font-weight:700;background:rgba(14,124,134,.10);border:1px solid rgba(14,124,134,.25)}'
+'.out153{background:transparent!important;border:0!important;box-shadow:none!important;color:inherit;opacity:.7;text-decoration:underline;min-height:40px;font-weight:700;display:flex;align-items:center;justify-content:center;margin:6px auto}'
+'#sync:empty{display:none}.wide156{flex:1 1 100%!important;width:100%!important;order:9;min-height:44px;justify-content:center}'
+'#themeBtn{opacity:.6}@media(max-width:900px){#themeBtn{width:32px!important;height:32px!important;left:4px!important}body.ostazy-app,body:has(#view){padding-bottom:120px!important}#tabs button,#tabs a{font-size:12px!important}#tabs button span,#tabs a span{font-size:12px!important}#tabs button[data-t=t],#tabs button[data-t=t] *{font-size:12px!important;font-weight:800!important;line-height:1.2!important}}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
function smallest(re){var best=null;document.querySelectorAll('#view *,main *').forEach(function(e){var t=e.textContent||'';if(re.test(t)&&t.length<600&&(!best||t.length<=best.textContent.length))best=e});return best}
function collapse(){
 var ca=document.querySelector('.customer-account');if(!ca||ca.closest('.acc153'))return;
 var tr=null;ca.parentNode.querySelectorAll('.card,section,div').forEach(function(e){if(!tr&&!e.contains(ca)&&!ca.contains(e)&&/تفاصيل الاشتراك بعد التجربة/.test(e.textContent||'')&&(e.textContent||'').length<2500&&e.classList.contains('card'))tr=e});
 var tm=((tr&&tr.textContent)||'').match(/باقي\s*(\d+)\s*يوم/);
 var d=document.createElement('details');d.className='acc153';d.innerHTML='<summary>الاشتراك وبيانات الحساب'+(tm?' <small>· تجربة باقي '+tm[1]+' يوم</small>':'')+'</summary>';
 ca.parentNode.insertBefore(d,ca);if(tr&&tr!==ca)d.appendChild(tr);d.appendChild(ca)}
function misc(){
 var v=document.getElementById('view');if(!v)return;
 var sy=document.getElementById('sync');if(sy&&sy.textContent==='تم تحميل بياناتك.'&&!sy.dataset.h){sy.dataset.h='1';setTimeout(function(){if(sy.textContent==='تم تحميل بياناتك.')sy.textContent='';sy.dataset.h=''},3500)}
 v.querySelectorAll('.stat span').forEach(function(s){if(s.textContent==='تفصيل التحصيل')s.textContent='إجمالي التحصيل'});
 var stats=v.querySelector('.stats');
 if(stats&&!v.querySelector('.note153')&&/إجمالي التحصيل/.test(stats.textContent)){var ns=[].map.call(stats.querySelectorAll('strong'),function(x){return parseFloat(x.textContent)||0});if(ns.length&&ns.every(function(n){return n===0}))stats.insertAdjacentHTML('afterend','<div class="note153">لسه مفيش مصاريف مسجّلة. أول ما تسجّل دفعة لطالب هتظهر هنا.</div>')}
 var ex=v.querySelector('.report-export');
 if(ex&&!ex.querySelector('.note153')){var bs=[].slice.call(v.querySelectorAll('.card')).filter(function(c){return /الدخل آخر 6 شهور/.test(c.textContent)})[0];if(bs){var vals=[].map.call(bs.querySelectorAll('.stu b'),function(x){return parseFloat(x.textContent)||0});if(vals.length&&vals.every(function(n){return n===0})){var p=document.createElement('div');p.className='note153';p.textContent='مفيش بيانات مسجّلة لسه. ملف Excel هيطلع فاضي لحد ما تضيف طلاب وتسجّل حضور ومصاريف.';ex.appendChild(p)}}}
 document.querySelectorAll('.wa-btn').forEach(function(a){if(a.textContent.trim().length>7)a.classList.add('wide156')});
 document.querySelectorAll('button').forEach(function(b){if(b.textContent.trim()==='تسجيل خروج')b.classList.add('out153')});
 var mn=document.querySelector('main')||document.body;var tx=mn.textContent||'';var gm=tx.match(/(\d+)\s*مجموع/),sm=tx.match(/(\d+)\s*طالب/);
 [['g',gm,'راجع مجموعاتك'],['s',sm,'راجع طلابك']].forEach(function(x){var bt=v.querySelector('.ob28 button[data-go="'+x[0]+'"]');if(bt&&x[1]&&+x[1][1]>0&&!bt.dataset.dn){bt.dataset.dn='1';bt.querySelector('span').textContent=x[2];bt.querySelector('i').textContent='\u2713'}});
}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button.go153');if(!b)return;var t=document.querySelector('#tabs button[data-t="'+b.dataset.go153+'"]');if(t)t.click()});
function run(){collapse();misc()}
var t;new MutationObserver(function(){clearTimeout(t);t=setTimeout(run,150)}).observe(document.documentElement,{childList:true,subtree:true,characterData:true});run();
})();
