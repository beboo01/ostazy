/* تحسين لوحة الرئيسية: بطاقات مؤشرات ملوّنة بأيقونة وحلقة نسبة. بدون بنفسجي أو وردي. */
(function(){'use strict';
const css=`.ostazy-app .stats .stat.k28{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:18px 10px 14px;border-radius:20px;background:var(--k-bg,var(--field)) !important;border:1px solid rgba(0,0,0,.05) !important;overflow:hidden;text-align:center}
.ostazy-app #view>.hero .stats .stat.k28{padding:20px 8px 14px !important;background:var(--k-bg) !important;border:1px solid rgba(0,0,0,.05) !important;border-radius:20px}
:root[data-theme=dark] .ostazy-app #view>.hero .stats .stat.k28,:root[data-theme=dark] .ostazy-app .stats .stat.k28{background:color-mix(in srgb,var(--k-c) 20%,#0E1C38) !important;border-color:rgba(255,255,255,.08) !important}
:root[data-theme=dark] .ostazy-app .stat.k28 strong,:root[data-theme=dark] .ostazy-app .stat.k28 span,:root[data-theme=dark] .ostazy-app .stat.k28 .k28r b{color:#fff !important}
.ostazy-app .stats .stat.k28::before{content:"";position:absolute;inset:0 0 auto 0;height:4px;background:var(--k-c)}
.ostazy-app .stat.k28 .k28i{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--k-c);color:#fff;margin-bottom:4px}
.ostazy-app .stat.k28 .k28i svg{width:22px;height:22px}
.ostazy-app .stat.k28 strong{font-size:28px;line-height:1.1;color:var(--k-t,inherit);display:block;text-align:center}
.ostazy-app .stat.k28 span{font-size:13px;opacity:.8;text-align:center;display:block}
.ostazy-app .stat.k28 .k28r{position:relative;width:64px;height:64px;display:flex;align-items:center;justify-content:center;margin-bottom:2px}
.ostazy-app .stat.k28 .k28r svg{position:absolute;inset:0;width:64px;height:64px;transform:rotate(-90deg)}
.ostazy-app .stat.k28 .k28r b{position:relative;font-size:15px;color:var(--k-t);font-weight:800}
.ostazy-app .stat.k28 .k28r+strong{display:none}`;
const ST=document.createElement('style');ST.textContent=css;document.head.appendChild(ST);
const IC={
'طالب':['#1D4ED8','#EAF1FF','<path d="M16 11a3 3 0 100-6 3 3 0 000 6zM8 12a3 3 0 100-6 3 3 0 000 6zM2 20c0-3 3-5 6-5s6 2 6 5M14 15c3 0 8 1 8 5" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>'],
'نسبة الحضور':['#16A34A','#E8F8EE',''],
'متوسط الدرجات':['#D99A00','#FFF6DD','<path d="M5 20V10M12 20V4M19 20v-7" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>'],
'تحصيل بمبالغ مسجلة':['#0D9488','#E4F7F5','<rect x="3" y="6" width="18" height="13" rx="3" stroke="currentColor" stroke-width="2" fill="none"/><path d="M3 10h18" stroke="currentColor" stroke-width="2"/>'],
'تقدير المطلوب بالسعر الحالي':['#EA7A0B','#FFF0E0','<circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2" fill="none"/><path d="M12 7v5l3 2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'],
'متأخرين عن شهور':['#C2410C','#FDEBDD','<path d="M12 3l10 18H2z" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round"/><path d="M12 10v5M12 18v.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>']};
function deco(){document.querySelectorAll('.ostazy-app .stats .stat:not(.k28)').forEach(el=>{
 const s=el.querySelector('span'),n=el.querySelector('strong');if(!s||!n)return;const lab=s.textContent.trim();const d=IC[lab];if(!d)return;
 el.classList.add('k28');el.style.setProperty('--k-c',d[0]);el.style.setProperty('--k-bg',d[1]);el.style.setProperty('--k-t',d[0]);
 const val=n.textContent.trim();const pm=/^(\d+(?:\.\d+)?)\s*%$/.exec(val);
 if(pm){const p=Math.min(100,+pm[1]),C=2*Math.PI*26;const r=document.createElement('div');r.className='k28r';r.innerHTML='<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" fill="none" stroke="rgba(0,0,0,.08)" stroke-width="7"/><circle cx="32" cy="32" r="26" fill="none" stroke="'+d[0]+'" stroke-width="7" stroke-linecap="round" stroke-dasharray="'+(C*p/100).toFixed(1)+' '+C.toFixed(1)+'"/></svg><b>'+val+'</b>';el.insertBefore(r,n)}
 else if(d[2]){const i=document.createElement('div');i.className='k28i';i.innerHTML='<svg viewBox="0 0 24 24">'+d[2]+'</svg>';el.insertBefore(i,n)}
})}
const v=document.getElementById('view');if(v){new MutationObserver(deco).observe(v,{childList:true,subtree:true});}
document.addEventListener('DOMContentLoaded',deco);deco();
})();
