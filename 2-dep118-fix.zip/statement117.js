/* كشف حساب الطالب: مدفوعات + حضور + درجات، للطباعة أو واتساب. محلي بالكامل، لا يرسل شيئًا ولا يغيّر بيانات. */
(function(){'use strict';
const view=document.getElementById('view');if(!view)return;
const q=(s,r)=>(r||document).querySelector(s);
function addBtns(){view.querySelectorAll('button[data-a="pay"]').forEach(b=>{
 if(b.parentNode.querySelector('[data-st]'))return;
 const r=document.createElement('button');r.type='button';r.className='sm ghost';r.setAttribute('data-st',b.dataset.id);r.textContent='كشف';b.parentNode.appendChild(r)})}
new MutationObserver(addBtns).observe(view,{childList:true,subtree:true});addBtns();
function months(n){const o=[],d=new Date();d.setDate(1);for(let i=0;i<n;i++){o.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'));d.setMonth(d.getMonth()-1)}return o}
function open(id){
 const st=findSt(id),g=S.groups.find(x=>x.students.includes(st));if(!st||!g)return;
 const ms=months(6),since=S.since||'';
 const pr=ms.map(m=>{const paid=!!(S.pay&&S.pay[m]&&S.pay[m][id]);return {m,paid,rel:!since||m>=since}}).filter(x=>x.rel);
 let pres=0,abs=0,late=0,exc=0;Object.keys(S.att||{}).forEach(k=>{if(k.split('|')[1]!==g.id)return;const v=S.att[k][id];if(v===undefined)return;if(v===true)pres++;else if(v===false)abs++;else if(v==='l')late++;else if(v==='e')exc++});
 const tot=pres+abs+late+exc,rate=tot?Math.round((pres+late)/tot*100):0;
 const ex=(S.exams||[]).filter(e=>e.gid===g.id&&e.scores&&e.scores[id]!==undefined&&e.scores[id]!=='').sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,5);
 const unpaid=pr.filter(x=>!x.paid).length,due=unpaid*(+S.price||0);
 const old=q('#stModal117');if(old)old.remove();
 const w=document.createElement('div');w.id='stModal117';w.setAttribute('role','dialog');w.setAttribute('aria-modal','true');
 const row=(a,b)=>'<div class="rc-r"><span>'+a+'</span><b>'+b+'</b></div>';
 const today=new Date().toLocaleDateString('ar-EG-u-nu-latn',{day:'numeric',month:'long',year:'numeric'});
 w.innerHTML='<div class="rc-box"><div class="rc-paper"><div class="rc-h"><img src="ostazy3-logo-light.png" alt="أستاذي" height="44"><div><h3>كشف حساب الطالب</h3><small>'+today+'</small></div></div>'
 +row('الطالب',esc(st.name))+row('المجموعة',esc(gname(g)))+row('المادة',esc(S.subject))
 +'<h4 class="st-t">المصاريف</h4>'+pr.map(x=>row(mname(x.m),x.paid?'<em class="st-ok">مدفوع</em>':'<em class="st-no">غير مدفوع</em>')).join('')
 +(unpaid?row('المتأخر',esc(due)+' جنيه'):'')
 +'<h4 class="st-t">الحضور</h4>'+row('حضور',pres)+row('غياب',abs)+row('تأخير',late)+row('نسبة الحضور',rate+'%')
 +(ex.length?'<h4 class="st-t">آخر الدرجات</h4>'+ex.map(e=>row(esc(e.title),esc(e.scores[id])+' / '+esc(e.max))).join(''):'')
 +'<small class="rc-s">تم التطوير بواسطة YAMO TECH</small></div><div class="rc-b"><button type="button" id="stPrint">طباعة / حفظ PDF</button><a class="wa" id="stWa" target="_blank" rel="noopener">نص على واتساب</a><button type="button" class="ghost" id="stClose">إغلاق</button></div></div>';
 document.body.appendChild(w);
 const txt='كشف حساب: '+st.name+'\nالمادة: '+S.subject+'\n'+pr.map(x=>mname(x.m)+': '+(x.paid?'مدفوع':'غير مدفوع')).join('\n')+(unpaid?'\nالمتأخر: '+due+' جنيه':'')+'\nحضور '+pres+' | غياب '+abs+' | تأخير '+late+' (نسبة الحضور '+rate+'%)';
 q('#stWa').href=wa(st.phone,txt);
 q('#stPrint').onclick=()=>window.print();
 const close=()=>{w.remove();document.body.classList.remove('rc-open')};
 q('#stClose').onclick=close;w.addEventListener('click',e=>{if(e.target===w)close()});
 document.addEventListener('keydown',function k(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',k)}});
 document.body.classList.add('rc-open');q('#stClose').focus()}
view.addEventListener('click',e=>{const b=e.target.closest('[data-st]');if(b)open(b.dataset.st)});
})();
