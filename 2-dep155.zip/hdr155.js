/* DEP155: on phones the theme toggle lives inside the header instead of floating over content */
(function(){
var mq=window.matchMedia('(max-width:900px)');
var st=document.createElement('style');st.textContent='@media(max-width:900px){header #themeBtn{position:static!important;flex:none;width:36px!important;height:36px!important;margin:0 8px!important;opacity:1!important;box-shadow:none!important;display:inline-flex!important;align-items:center;justify-content:center;padding:0}header.brand,header.studio-header{align-items:center}}';document.head.appendChild(st);
function place(){var b=document.getElementById('themeBtn');if(!b)return;var h=document.querySelector('header.brand,header.studio-header');if(!h)return;
 if(mq.matches){if(b.parentNode!==h)h.appendChild(b)}else if(b.parentNode===h)document.body.appendChild(b)}
var n=0,t=setInterval(function(){place();if(++n>40)clearInterval(t)},150);
if(mq.addEventListener)mq.addEventListener('change',place);
document.addEventListener('DOMContentLoaded',place);
})();
