(function(){
var css='.gbar{flex:0 0 100%;order:9;height:8px;border-radius:99px;background:rgba(11,79,138,.12);overflow:hidden;margin-top:6px}.gbar i{display:block;height:100%;border-radius:99px}.rk{display:inline-flex;align-items:center;justify-content:center;min-width:26px;height:26px;border-radius:99px;font-weight:800;font-size:13px;color:#fff;margin-inline-start:8px;background:linear-gradient(135deg,#0E7C86,#0B4F8A)}.rk.r1{background:linear-gradient(135deg,#F5B301,#E08A00)}.rk.r2{background:linear-gradient(135deg,#8FA3BF,#5D6E88)}.rk.r3{background:linear-gradient(135deg,#E48A3C,#B45309)}.gsum{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 4px}.gsum span{flex:1 1 120px;padding:8px 12px;border-radius:12px;text-align:center;font-weight:800;background:linear-gradient(135deg,rgba(14,124,134,.14),rgba(11,79,138,.10))}.gsum small{display:block;font-weight:600;opacity:.75}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
function run(){
 var groups=new Map();
 document.querySelectorAll('.stu').forEach(function(r){var inp=r.querySelector('input');if(!inp||r.dataset.gdone&&r.dataset.gv===inp.value)return;var m=(r.textContent||'').match(/\/\s*(\d+)/);if(!m||r.querySelector('.rbar'))return;var p=r.parentElement;if(!groups.has(p))groups.set(p,[]);groups.get(p).push([r,inp,+m[1]])});
 groups.forEach(function(rows,p){
  var vals=rows.map(function(x){return parseFloat(x[1].value)||0});var sorted=vals.slice().sort(function(a,b){return b-a});
  rows.forEach(function(x,i){var r=x[0];r.classList.add('has-rbar');r.style.flexWrap='wrap';r.dataset.gdone='1';r.dataset.gv=x[1].value;
   r.querySelectorAll('.gbar,.rk').forEach(function(e){e.remove()});
   var rank=sorted.indexOf(vals[i])+1,pc=Math.min(100,vals[i]/x[2]*100);
   var col=pc>=75?'linear-gradient(90deg,#16A34A,#0E7C86)':pc>=50?'linear-gradient(90deg,#0E7C86,#0B4F8A)':'linear-gradient(90deg,#F59E0B,#EA580C)';
   var sp=r.querySelector('span');if(sp){var k=document.createElement('b');k.className='rk r'+(rank<=3?rank:'');k.textContent=rank;sp.appendChild(k)}
   var b=document.createElement('div');b.className='gbar';b.innerHTML='<i style="width:'+pc+'%;background:'+col+'"></i>';r.appendChild(b);
   x[1].oninput=function(){run()};
  });
  if(!p.querySelector('.gsum')){var avg=vals.reduce(function(a,b){return a+b},0)/vals.length,mx=rows[0][2];var s=document.createElement('div');s.className='gsum';s.innerHTML='<span>'+(Math.round(avg*10)/10)+' / '+mx+'<small>المتوسط</small></span><span>'+sorted[0]+'<small>الأعلى</small></span><span>'+sorted[sorted.length-1]+'<small>الأقل</small></span>';rows[0][0].insertAdjacentElement('beforebegin',s)}
 });
}
var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(run,200)}).observe(document.documentElement,{childList:true,subtree:true});run();
})();
