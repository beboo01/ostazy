(function(){
var css='.rbar{flex:0 0 100%;order:9;height:8px;border-radius:99px;background:rgba(11,79,138,.12);overflow:hidden;margin-top:6px}.rbar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#0E7C86,#0B4F8A)}.stu.has-rbar{flex-wrap:wrap}.rnote{margin:8px 0 2px;padding:10px 14px;border-radius:12px;background:linear-gradient(135deg,rgba(14,124,134,.12),rgba(11,79,138,.08));font-weight:700;text-align:center;color:inherit}.th-btn{background:linear-gradient(135deg,#0F6E8C 0%,#0B4F8A 55%,#0A3A6E 100%)!important;color:#fff!important;border-color:transparent!important}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
function num(t){var m=(t||'').replace(/[٠-٩]/g,function(d){return '٠١٢٣٤٥٦٧٨٩'.indexOf(d)}).replace(/,/g,'').match(/(\d+(?:\.\d+)?)\s*جنيه/);return m?parseFloat(m[1]):null}
function run(){
 document.querySelectorAll('button').forEach(function(b){if(b.classList.contains('th-btn')||b.classList.contains('wa-btn'))return;var c=getComputedStyle(b),s=c.backgroundImage+c.backgroundColor;if(/rgb\(0, 212, 255\)|rgb\(56, 189, 248\)|rgb\(34, 211, 238\)/.test(s))b.classList.add('th-btn')});
 document.querySelectorAll('.card,section,div').forEach(function(card){
  if(card.dataset.rdone)return;var h=card.firstElementChild;if(!h||!/الدخل آخر/.test(h.textContent||''))return;
  var rows=[].slice.call(card.querySelectorAll('.stu'));if(!rows.length)return;card.dataset.rdone='1';
  var vals=rows.map(function(r){var b=r.querySelector('b');return num(b&&b.textContent)||0});var mx=Math.max.apply(null,vals);
  rows.forEach(function(r,i){r.classList.add('has-rbar');var bar=document.createElement('div');bar.className='rbar';bar.innerHTML='<i style="width:'+(mx?Math.max(vals[i]/mx*100,vals[i]?4:0):0)+'%"></i>';r.appendChild(bar)});
  if(!mx){var n=document.createElement('div');n.className='rnote';n.textContent='لسه مفيش تحصيل مسجّل. أول ما تسجّل دفعة هتظهر هنا كشريط لكل شهر.';h.insertAdjacentElement('afterend',n)}
 });
}
var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(run,150)}).observe(document.documentElement,{childList:true,subtree:true});run();
})();
