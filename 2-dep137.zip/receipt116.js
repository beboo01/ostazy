/* إيصال استلام مصاريف قابل للطباعة. محلي بالكامل، لا يرسل شيئًا، ولا يغيّر أي بيانات. */
(function(){'use strict';
const view=document.getElementById('view');if(!view)return;
const q=(s,r)=>(r||document).querySelector(s);
function addBtns(){view.querySelectorAll('button[data-a="pay"]').forEach(b=>{
 if(b.textContent.trim()!=='إلغاء'||b.parentNode.querySelector('[data-rc]'))return;
 const r=document.createElement('button');r.type='button';r.className='sm ghost';r.setAttribute('data-rc',b.dataset.id);r.textContent='إيصال';b.parentNode.insertBefore(r,b)})}
new MutationObserver(addBtns).observe(view,{childList:true,subtree:true});addBtns();
function num(id,m){const l=(typeof S!=='undefined'&&S.paymentLedger||[]).filter(x=>x.studentId===id&&x.month===m);if(!l.length)return {amount:(window.ozNet?ozNet(id):S.price),date:null};const p=l.filter(x=>x.kind==='payment').pop();const open=window.ozOpenPays?ozOpenPays(id,m):[];const sum=open.reduce((a,x)=>a+(+x.amount||0),0);return {amount:open.length?sum:(p?p.amount:S.price),date:p?p.occurredAt:null}}
function open(id){
 const st=findSt(id),g=S.groups.find(x=>x.students.includes(st)),m=pmonth;if(!st||!g)return;
 const n=num(id,m),d=new Date(n.date||Date.now()),ds=d.toLocaleDateString('ar-EG-u-nu-latn',{day:'numeric',month:'long',year:'numeric'});
 const no='OZ-'+m.replace('-','')+'-'+String(id).replace(/\W/g,'').slice(-4).toUpperCase();
 const old=q('#rcModal116');if(old)old.remove();
 const w=document.createElement('div');w.id='rcModal116';w.setAttribute('role','dialog');w.setAttribute('aria-modal','true');
 const row=(a,b)=>'<div class="rc-r"><span>'+a+'</span><b>'+b+'</b></div>';
 w.innerHTML='<div class="rc-box"><div id="rcPaper116" class="rc-paper"><div class="rc-h"><img src="ostazy3-logo-light.png" alt="أستاذي" height="44"><div><h3>إيصال استلام مصاريف</h3><small>رقم '+no+'</small></div></div>'+row('الطالب',esc(st.name))+row('المجموعة',esc(gname(g)))+row('المادة',esc(S.subject))+row('عن شهر',mname(m))+row('المبلغ',esc(n.amount)+' جنيه')+row('تاريخ الاستلام',ds)+'<p class="rc-f">تم استلام المبلغ أعلاه. شكرًا لحضرتك.</p><small class="rc-s">تم التطوير بواسطة YAMO TECH</small></div><div class="rc-b"><button type="button" id="rcPrint">طباعة / حفظ PDF</button><a class="wa" id="rcWa" target="_blank" rel="noopener">نص على واتساب</a><button type="button" class="ghost" id="rcClose">إغلاق</button></div></div>';
 document.body.appendChild(w);
 const txt='إيصال استلام مصاريف ('+no+')\nالطالب: '+st.name+'\nالمادة: '+S.subject+'\nعن شهر: '+mname(m)+'\nالمبلغ: '+n.amount+' جنيه\nتاريخ الاستلام: '+ds;
 q('#rcWa').href=wa(st.phone,txt);
 q('#rcPrint').onclick=()=>window.print();
 const close=()=>{w.remove();document.body.classList.remove('rc-open')};
 q('#rcClose').onclick=close;w.addEventListener('click',e=>{if(e.target===w)close()});
 document.addEventListener('keydown',function k(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',k)}});
 document.body.classList.add('rc-open');q('#rcClose').focus()}
view.addEventListener('click',e=>{const b=e.target.closest('[data-rc]');if(b)open(b.dataset.rc)});
})();
