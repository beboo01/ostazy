(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.OstazyHomework=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function build({subject,groupName,classDate,homework}={}){
  if(typeof classDate!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(classDate))throw Error('اختار تاريخ حصة صحيح.');
  const d=new Date(classDate+'T12:00:00Z');
  if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==classDate)throw Error('اختار تاريخ حصة صحيح.');
  if(typeof homework!=='string'||!homework.trim())throw Error('احفظ واجب الحصة الأول، وبعدها جهّز رسالة المجموعة.');
  if(typeof subject!=='string'||!subject.trim()||typeof groupName!=='string'||!groupName.trim())throw Error('بيانات المادة أو المجموعة غير جاهزة.');
  return 'السلام عليكم،\nواجب '+subject.trim()+'\nالمجموعة: '+groupName.trim()+'\nتاريخ الحصة: '+classDate+'\n\n'+homework.trim();
}
return Object.freeze({build});
});
