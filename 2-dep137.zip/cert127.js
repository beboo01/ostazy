/* شهادات ٢٠٢٧ بحسب المادة (أصلية): رياضيات، علوم، فيزياء، كيمياء، أحياء، عربي، إنجليزي × لونين. بدون بنفسجي أو وردي. */
(function(){'use strict';
if(typeof CERTS==='undefined'||typeof LIBMETA==='undefined')return;
const PAL={navy:{n:'كحلي وسماوي',a:'#0B1F44',b:'#00B8E6',c:'#EAF6FC',g:'#F5B301'},green:{n:'أخضر وذهبي',a:'#064E3B',b:'#D4A72C',c:'#EAF6EE',g:'#22C55E'}};
const I={
math:['الرياضيات','<path d="M5 7h14M12 4v6M5 17h14M7 14l10 6M17 14L7 20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>','شهادة تميّز في الرياضيات'],
sci:['العلوم','<path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round"/>','شهادة تميّز في العلوم'],
phys:['الفيزياء','<circle cx="12" cy="12" r="2" fill="currentColor"/><ellipse cx="12" cy="12" rx="10" ry="4" stroke="currentColor" stroke-width="1.8" fill="none"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)" stroke="currentColor" stroke-width="1.8" fill="none"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)" stroke="currentColor" stroke-width="1.8" fill="none"/>','شهادة تميّز في الفيزياء'],
chem:['الكيمياء','<circle cx="7" cy="8" r="3" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="17" cy="8" r="3" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="12" cy="17" r="3" stroke="currentColor" stroke-width="2" fill="none"/><path d="M9.5 9.5L11 14.5M14.5 9.5L13 14.5M10 8h4" stroke="currentColor" stroke-width="1.6"/>','شهادة تميّز في الكيمياء'],
bio:['الأحياء','<path d="M12 21c-5 0-8-4-8-9 5 0 8 3 8 9zM12 21c5 0 8-4 8-9-5 0-8 3-8 9zM12 21V8M12 8c0-3 1-5 3-6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>','شهادة تميّز في الأحياء'],
ar:['اللغة العربية','<text x="12" y="19" text-anchor="middle" font-size="20" font-weight="800" fill="currentColor" font-family="Tajawal,Cairo">أ</text>','شهادة تميّز في اللغة العربية'],
en:['اللغة الإنجليزية','<text x="12" y="18" text-anchor="middle" font-size="15" font-weight="800" fill="currentColor" font-family="Tajawal,Cairo">Aa</text>','شهادة تميّز في الإنجليزية']};
const RS={math:'وذلك للتفوق في الرياضيات وحل المسائل بذكاء وسرعة.',sci:'وذلك للتفوق في العلوم وروح الاستكشاف والتجريب.',phys:'وذلك للتفوق في الفيزياء وفهم القوانين وتطبيقها بثقة.',chem:'وذلك للتفوق في الكيمياء ودقة الملاحظة والتفاعلات.',bio:'وذلك للتفوق في الأحياء وحب عالم الكائنات الحية.',ar:'وذلك للتفوق في اللغة العربية والقراءة المعبّرة والإملاء.',en:'وذلك للتفوق في الإنجليزية والنطق الواثق والمفردات.'};
const rs=(k,m)=>/^وذلك للتفوق/.test(String(m.reason||'').trim())||!m.reason?RS[k]:m.reason;
const px=(x,y,w,h,st,inner)=>`<div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;height:${h}px;${st||''}">${inner||''}</div>`;
const tx=(x,y,w,h,t,st)=>px(x,y,w,h,`display:flex;align-items:center;justify-content:center;text-align:center;line-height:1.35;${st||''}`,t);
const nsz=(m,big)=>{const l=String(m.name).length;return l>40?big*.55:l>28?big*.7:l>18?big*.85:big};

const ic=(d,c,sz)=>`<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" style="color:${c}">${d}</svg>`;
const nameBlk=(m,c,x,y,w,big)=>tx(x,y,w,96,`<div style="font-family:'El Messiri',Amiri,serif;font-size:${nsz(m,big)}px;font-weight:800;color:${c}">${m.name}</div>`);
const ttlOf=(m,d)=>m.title||d[2];
const L={
A:(k,m,c)=>{const d=I[k];return `<div class="kpage" style="background:${c.c};font-family:Tajawal,Cairo,sans-serif;color:${c.a}">`+
 px(40,40,1043,714,`background:#fff;border-radius:40px;border:3px solid ${c.a}`)+px(40,40,1043,200,`background:${c.a};border-radius:40px 40px 0 0`)+
 px(43,43,1037,194,'overflow:hidden;border-radius:37px 37px 0 0',px(20,90,260,260,`border-radius:50%;border:2px solid ${c.b};opacity:.28`)+px(800,-60,220,220,`border-radius:50%;border:2px solid ${c.b};opacity:.2`))+
 px(481,70,160,160,`border-radius:50%;background:${c.b};box-shadow:0 8px 0 ${c.g}`,tx(0,0,160,160,ic(d[1],c.a,92)))+
 tx(60,276,1003,56,`<div style="font-family:Changa,Tajawal;font-size:44px;font-weight:800">${ttlOf(m,d)}</div>`)+px(511,338,100,5,`background:${c.g};border-radius:3px`)+
 tx(60,356,1003,30,`<div style="font-size:18px;color:#64748B;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+nameBlk(m,c.a,80,392,963,62)+
 tx(140,490,843,70,`<div style="font-size:19px;font-weight:700;color:#334155;line-height:1.7">${rs(k,m)}</div>`)+
 px(80,610,440,100,`background:${c.c};border-radius:24px`,tx(0,0,440,100,`<div><div style="font-size:12px;color:#64748B;font-weight:800">المدرّس · ${d[0]}</div><div style="font-size:23px;font-weight:800">${m.teacher}</div></div>`))+
 px(603,610,440,100,`background:${c.a};border-radius:24px`,tx(0,0,440,100,`<div><div style="font-size:12px;color:${c.b};font-weight:800">${m.stageLabel}</div><div style="font-size:21px;font-weight:800;color:#fff">${m.date} · ${m.school}</div></div>`))+`</div>`},
B:(k,m,c)=>{const d=I[k];return `<div class="kpage" style="background:#F4F1EA;font-family:Tajawal,Cairo,sans-serif;color:${c.a}">`+
 px(40,40,320,714,`background:${c.a};border-radius:40px;overflow:hidden`,px(-60,420,300,300,`border-radius:50%;border:2px solid ${c.b};opacity:.3`)+px(60,500,300,300,`border-radius:50%;border:2px solid ${c.b};opacity:.2`))+
 px(100,90,200,200,`border-radius:50%;background:${c.b};box-shadow:0 8px 0 ${c.g}`,tx(0,0,200,200,ic(d[1],c.a,116)))+
 tx(60,320,280,50,`<div style="font-size:22px;font-weight:800;color:#fff">${d[0]}</div>`)+tx(60,370,280,40,`<div style="font-size:15px;font-weight:700;color:${c.b}">${m.stageLabel}</div>`)+
 px(130,440,140,3,`background:${c.g}`)+tx(60,470,280,70,`<div><div style="font-size:12px;color:${c.b};font-weight:700">المدرّس</div><div style="font-size:21px;font-weight:800;color:#fff">${m.teacher}</div></div>`)+tx(60,560,280,60,`<div style="font-size:15px;font-weight:700;color:#dbe7f0">${m.school}</div>`)+tx(60,640,280,50,`<div style="font-size:15px;font-weight:700;color:#fff">${m.date}</div>`)+
 px(380,40,703,714,'background:#fff;border-radius:40px')+px(420,80,623,6,`background:${c.g};border-radius:3px`)+
 tx(400,130,663,70,`<div style="font-family:Changa,Tajawal;font-size:46px;font-weight:800">${ttlOf(m,d)}</div>`)+
 tx(400,300,663,30,`<div style="font-size:18px;color:#64748B;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+nameBlk(m,c.a,410,345,643,60)+
 px(560,460,343,3,`background:${c.b}`)+tx(430,490,603,100,`<div style="font-size:20px;font-weight:700;color:#334155;line-height:1.8">${rs(k,m)}</div>`)+`</div>`},
C:(k,m,c)=>{const d=I[k];return `<div class="kpage" style="background:${c.a};font-family:Tajawal,Cairo,sans-serif;color:${c.a}">`+
 px(30,30,1063,734,`border-radius:36px;border:3px solid ${c.b}`)+px(55,55,1013,684,`background:#fff;border-radius:26px`)+
 px(55,55,1013,684,'overflow:hidden;border-radius:26px',tx(250,40,620,620,ic(d[1],c.c,560),'opacity:.8'))+
 px(511,85,100,100,`border-radius:50%;background:${c.a};box-shadow:0 6px 0 ${c.b}`,tx(0,0,100,100,ic(d[1],c.b,58)))+
 tx(100,210,923,40,`<div style="font-size:16px;font-weight:800;color:${c.b};letter-spacing:1px">${d[0]} · ${m.stageLabel}</div>`)+
 tx(100,256,923,64,`<div style="font-family:Changa,Tajawal;font-size:48px;font-weight:800">${ttlOf(m,d)}</div>`)+
 tx(100,350,923,30,`<div style="font-size:18px;color:#64748B;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+nameBlk(m,c.a,120,392,883,64)+px(461,498,200,4,`background:${c.g};border-radius:2px`)+
 tx(160,512,803,70,`<div style="font-size:19px;font-weight:700;color:#334155;line-height:1.7">${rs(k,m)}</div>`)+
 tx(100,620,461,80,`<div><div style="font-size:12px;color:#64748B;font-weight:800">المدرّس</div><div style="font-size:22px;font-weight:800">${m.teacher}</div></div>`)+tx(562,620,461,80,`<div><div style="font-size:12px;color:#64748B;font-weight:800">${m.school}</div><div style="font-size:20px;font-weight:800">${m.date}</div></div>`)+`</div>`},
D:(k,m,c)=>{const d=I[k];return `<div class="kpage" style="background:${c.c};font-family:Tajawal,Cairo,sans-serif;color:${c.a}">`+
 px(40,40,1043,170,`background:${c.b};border-radius:36px`)+px(40,40,1043,170,'overflow:hidden;border-radius:36px',px(780,-80,300,300,`border-radius:50%;background:#fff;opacity:.28`))+
 px(70,60,130,130,`border-radius:30px;background:${c.a}`,tx(0,0,130,130,ic(d[1],c.b,76)))+
 tx(220,60,803,130,`<div style="font-family:Changa,Tajawal;font-size:46px;font-weight:800;color:${c.a}">${ttlOf(m,d)}</div>`)+
 px(40,230,680,360,`background:#fff;border-radius:36px`)+tx(60,250,640,30,`<div style="font-size:18px;color:#64748B;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+nameBlk(m,c.a,60,295,640,56)+tx(80,420,600,140,`<div style="font-size:19px;font-weight:700;color:#334155;line-height:1.8">${rs(k,m)}</div>`)+
 px(740,230,343,170,`background:${c.a};border-radius:36px`,tx(0,0,343,170,`<div><div style="font-size:12px;color:${c.b};font-weight:800">${d[0]}</div><div style="font-size:24px;font-weight:800;color:#fff">${m.stageLabel}</div></div>`))+
 px(740,420,343,170,`background:#fff;border-radius:36px;border:3px solid ${c.a}`,tx(0,0,343,170,`<div><div style="font-size:12px;color:#64748B;font-weight:800">${m.date}</div><div style="font-size:22px;font-weight:800">${m.school}</div></div>`))+
 px(40,610,1043,144,`background:${c.a};border-radius:36px`,tx(0,0,1043,144,`<div><div style="font-size:13px;color:${c.b};font-weight:800">المدرّس</div><div style="font-size:30px;font-weight:800;color:#fff;font-family:'El Messiri',Tajawal">${m.teacher}</div></div>`))+`</div>`}
};
const LAB={A:'شريط علوي',B:'عمود جانبي',C:'إطار مركزي',D:'بطاقات'};
Object.keys(I).forEach(k=>Object.keys(L).forEach(lk=>Object.keys(PAL).forEach((pk,vi)=>{const id='lib-sub27-'+k+'-'+lk+'-'+pk;CERTS[id]={label:I[k][0]+' · '+LAB[lk]+' — '+PAL[pk].n,cat:'modern',subjects:[k],aud:['child','mature'],render:m=>L[lk](k,m,PAL[pk])};LIBMETA[id]={fam:'sub27'+lk,cat:'modern',pal:pk,v:vi,label:CERTS[id].label}})));
})();
