/* DEP111: light/dark toggle, choice saved in this browser only */
(function(){var K='ostazy-theme',r=document.documentElement,st;
try{st=localStorage.getItem(K)}catch(e){}
function sys(){return window.matchMedia&&matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'}
function cur(){return r.getAttribute('data-theme')||sys()}
function apply(t){r.setAttribute('data-theme',t);var m=document.querySelector('meta[name=theme-color]');if(m)m.setAttribute('content',t==='dark'?'#06152E':'#0B1F44')}
if(st==='dark'||st==='light')apply(st);
var SUN='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',MOON='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
function mk(){if(document.getElementById('themeBtn'))return;var b=document.createElement('button');b.id='themeBtn';b.type='button';
function lab(){var d=cur()==='dark';b.innerHTML=d?SUN:MOON;b.title=d?'الوضع الفاتح':'الوضع الداكن';b.setAttribute('aria-label',b.title)}
b.onclick=function(){var t=cur()==='dark'?'light':'dark';apply(t);try{localStorage.setItem(K,t)}catch(e){}lab()};lab();document.body.appendChild(b)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mk);else mk()})();
