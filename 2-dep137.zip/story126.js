/* قوالب ستوري ٢٠٢٦ (أصلية): زجاجي، بينتو، نيو بروتاليست، أورورا. بدون بنفسجي أو وردي. */
(function(){'use strict';
if(typeof VTPLS==='undefined')return;
const base={duration:10,width:540,height:960,fps:30};
const T=(v,font,size,color,y,a,b,x)=>Object.assign({type:'text',value:v,font,weight:800,size,color,y,fadeIn:[a,b],maxW:440},x||{});
const S=(shape,o)=>Object.assign({type:'shape',shape},o);
const R=(x,y,w,h,color,a,o)=>S('rect',Object.assign({x,y,w,h,radius:30,color,fadeIn:[a,a+.6],zoomFrom:.94,zoomTo:1},o||{}));
const BX=(x,y,w,h,fill,a)=>[R(x+8,y+8,w,h,'#111111',a,{radius:22}),R(x-4,y-4,w+8,h+8,'#111111',a,{radius:26}),R(x,y,w,h,fill,a,{radius:22})];
const F=(d,f)=>({defaults:d,fields:f});
Object.assign(VTPLS,{
'glass26':Object.assign({label:'زجاجي ٢٠٢٦',photo:false},F({title:'التسجيل مفتوح',subject:'مادة الرياضيات',when:'السبت والثلاثاء ٤ عصرًا',place:'سنتر النور',cta:'احجز مكانك الآن'},[['title','العنوان'],['subject','المادة'],['when','المواعيد'],['place','المكان'],['cta','دعوة']]),{
 build(v){return Object.assign({},base,{background:{from:'#0A1430',to:'#06344F'},layers:[
  S('circle',{x:20,y:60,r:200,color:'#1D4ED8',alpha:.55,fadeIn:[0,1],zoomFrom:.7,zoomTo:1.05}),
  S('circle',{x:330,y:560,r:230,color:'#06B6D4',alpha:.4,fadeIn:[.2,1.2],zoomFrom:.7,zoomTo:1.05}),
  S('circle',{x:300,y:40,r:120,color:'#F5B301',alpha:.35,fadeIn:[.4,1.4],zoomFrom:.7,zoomTo:1.05}),
  R(40,170,460,620,'#FFFFFF',.2,{alpha:.14}),
  T(v.title,'Noto Kufi Arabic',44,'#FFFFFF',290,.8,1.6,{slideIn:'up'}),
  R(220,320,100,5,'#F5B301',1.4,{radius:3}),
  T(v.subject,'Changa',50,'#FFD166',440,1.6,2.6,{zoomFrom:.8,zoomTo:1}),
  T(v.when,'Cairo',32,'#FFFFFF',560,2.6,3.6,{slideIn:'up'}),
  T(v.place,'Cairo',28,'#BFD3FF',620,3.2,4.2),
  R(130,690,280,70,'#F5B301',4,{radius:35}),
  T(v.cta,'Cairo',28,'#0A1430',738,4.4,5.2,{maxW:240,pulse:{scale:1.04,period:1.6}})]})}}),
'bento26':Object.assign({label:'بينتو ٢٠٢٦',photo:false},F({title:'مراجعة نهائية',subject:'الرياضيات',when:'الخميس ٥ مساءً',place:'في السنتر',cta:'احجز مقعدك'},[['title','العنوان'],['subject','المادة'],['when','الموعد'],['place','المكان'],['cta','دعوة']]),{
 build(v){return Object.assign({},base,{background:{from:'#F1EEE7',to:'#E4DFD2'},layers:[
  R(30,70,480,240,'#0B1F44',.1),T(v.title,'Noto Kufi Arabic',46,'#FFFFFF',205,.5,1.3,{slideIn:'up'}),R(240,240,60,5,'#00D4FF',1.2,{radius:3}),
  R(30,326,232,200,'#FBBF24',.6),T('المادة','Cairo',20,'#6B4A1F',380,1,1.6,{maxW:200,x:146}),T(v.subject,'Changa',40,'#0B1F44',450,1.2,2,{maxW:200,x:146}),
  R(278,326,232,200,'#FFFFFF',.9),T('الموعد','Cairo',20,'#64748B',380,1.3,1.9,{maxW:200,x:394}),T(v.when,'Cairo',30,'#0B1F44',450,1.6,2.4,{maxW:200,x:394}),
  R(30,542,480,150,'#14181F',1.3),T(v.place,'Cairo',40,'#FFFFFF',635,1.8,2.6,{maxW:440}),
  R(30,708,480,170,'#16A34A',2),T(v.cta,'Changa',46,'#FFFFFF',815,2.4,3.2,{maxW:440,pulse:{scale:1.03,period:1.8}})]})}}),
'brut26':Object.assign({label:'نيو بروتاليست',photo:false},F({title:'حجز المجموعات',subject:'مادة العلوم',when:'الأحد والأربعاء ٦ مساءً',place:'سنتر المستقبل',cta:'اتصل واحجز'},[['title','العنوان'],['subject','المادة'],['when','المواعيد'],['place','المكان'],['cta','دعوة']]),{
 build(v){return Object.assign({},base,{background:{from:'#FFE066',to:'#FFD43B'},layers:[].concat(
  BX(40,90,452,230,'#FFFFFF',.2),[T(v.title,'Changa',54,'#111111',225,.6,1.4,{slideIn:'up',maxW:410})],
  BX(40,370,452,120,'#FF8A1F',1),[T(v.subject,'Changa',46,'#111111',450,1.2,2,{maxW:410})],
  BX(40,540,452,110,'#5EB6FF',1.6),[T(v.when,'Cairo',32,'#111111',610,1.9,2.7,{maxW:410})],
  BX(40,700,452,90,'#FFFFFF',2.2),[T(v.place,'Cairo',34,'#111111',760,2.5,3.3,{maxW:410})],
  BX(40,840,452,80,'#111111',2.8),[T(v.cta,'Changa',38,'#FFE066',895,3,3.8,{maxW:410,pulse:{scale:1.04,period:1.6}})])})}}),
'aurora26':Object.assign({label:'أورورا ٢٠٢٦',photo:false},F({title:'عام دراسي جديد',big:'٢٠٢٧',sub:'ابدأ بخطة مذاكرة واضحة',cta:'سجّل دلوقتي'},[['title','العنوان'],['big','الرقم الكبير'],['sub','سطر داعم'],['cta','دعوة']]),{
 build(v){return Object.assign({},base,{background:{from:'#0B1F44',to:'#042A3B'},layers:[
  S('circle',{x:-60,y:80,r:260,color:'#1D4ED8',alpha:.6,fadeIn:[0,1],zoomFrom:.6,zoomTo:1.1}),
  S('circle',{x:300,y:300,r:240,color:'#06B6D4',alpha:.45,fadeIn:[.3,1.3],zoomFrom:.6,zoomTo:1.1}),
  S('circle',{x:120,y:620,r:260,color:'#F59E0B',alpha:.5,fadeIn:[.6,1.6],zoomFrom:.6,zoomTo:1.1}),
  T(v.big,'Changa',250,'#FFFFFF',430,.4,1.6,{maxW:480,alpha:.22,zoomFrom:.8,zoomTo:1}),
  T(v.title,'Noto Kufi Arabic',58,'#FFFFFF',560,1.2,2.2,{slideIn:'up',maxW:460}),
  R(240,600,60,5,'#FFFFFF',2,{radius:3,alpha:.8}),
  T(v.sub,'Cairo',32,'#E6F6FF',680,2.2,3.2,{maxW:440}),
  R(120,770,300,76,'#FFFFFF',3.2,{radius:38}),T(v.cta,'Cairo',30,'#0B1F44',822,3.6,4.4,{maxW:260,pulse:{scale:1.04,period:1.6}})]})}})
});
if(typeof fillVTplSel==='function')fillVTplSel();
})();
