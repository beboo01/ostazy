/* شهادات اتجاهات ٢٠٢٦ (أصلية): بينتو، زجاجي، تحريري، نيو بروتاليست × ٤ ألوان (أزرق/تيل/زمردي/غروب). بدون بنفسجي أو وردي. */
(function(){'use strict';
if(typeof CERTS==='undefined'||typeof LIBMETA==='undefined')return;
const PAL={azur:{n:'أزرق سماوي',a:'#0B1F44',b:'#00B8E6',c:'#E8F7FC',g:'#F5B301'},teal:{n:'تيل وذهبي',a:'#0B4F4A',b:'#F5B301',c:'#E6F6F2',g:'#14B8A6'},emerald:{n:'زمردي',a:'#064E2B',b:'#D4A72C',c:'#EAF6EE',g:'#22C55E'},sunset:{n:'غروب برتقالي',a:'#7C2D12',b:'#FF8A1F',c:'#FFF1E3',g:'#FBBF24'}};
const W=1123,H=794;
const px=(x,y,w,h,st,inner)=>`<div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;height:${h}px;${st||''}">${inner||''}</div>`;
const tx=(x,y,w,h,t,st)=>px(x,y,w,h,`display:flex;align-items:center;justify-content:center;text-align:center;line-height:1.35;${st||''}`,t);
const nsz=n=>String(n).replace(/&[^;]+;/g,'x').length;
const nameSz=(m,big)=>{const l=nsz(m.name);return l>40?(big*.55):l>28?(big*.7):l>18?(big*.85):big};
const ttl=(m)=>m.title||'شهادة تقدير وتميّز';
const sig=(m,col,mut,x,y,w)=>px(x,y,w,60,'display:flex;gap:0',px(0,0,w/2,60,'',tx(0,0,w/2,60,`<div><div style="font-size:12px;color:${mut};font-weight:700">المدرّس</div><div style="font-size:19px;font-weight:800;color:${col}">${m.teacher}</div></div>`))+px(w/2,0,w/2,60,'',tx(0,0,w/2,60,`<div><div style="font-size:12px;color:${mut};font-weight:700">المدرسة</div><div style="font-size:19px;font-weight:800;color:${col}">${m.school}</div></div>`)));
function seal(x,y,r,a,b){return px(x-r,y-r,2*r,2*r,`border-radius:50%;background:${b};box-shadow:inset -8px -10px 20px rgba(0,0,0,.14),inset 8px 8px 18px rgba(255,255,255,.45)`,px(r*.14,r*.14,r*1.72,r*1.72,`border-radius:50%;border:3px solid ${a}`)+tx(0,0,2*r,2*r,`<svg width="${r}" height="${r}" viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z" fill="${a}"/></svg>`))}
const F={
bento:(m,c)=>`<div class="kpage" style="background:#F1EEE7;font-family:Tajawal,Cairo,sans-serif">`+
 px(40,40,300,714,`background:${c.a};border-radius:36px`,px(60,60,180,180,`border-radius:50%;border:2px solid ${c.b};opacity:.5`)+px(120,150,190,190,`border-radius:50%;border:2px solid ${c.b};opacity:.25`))+seal(190,260,86,c.a,c.b)+
 tx(60,380,260,60,`<div style="font-size:14px;color:${c.b};font-weight:800">${m.stageLabel}</div>`)+tx(60,430,260,60,`<div style="font-size:16px;color:#fff;font-weight:700">${m.date}</div>`)+
 px(100,560,180,2,`background:${c.b};opacity:.7`)+tx(60,580,260,80,`<div><div style="font-size:12px;color:${c.b};font-weight:700">المدرّس</div><div style="font-size:22px;color:#fff;font-weight:800;font-family:'El Messiri',Tajawal">${m.teacher}</div></div>`)+tx(60,660,260,70,`<div style="font-size:15px;color:#cfe3f0;font-weight:700">${m.school}</div>`)+
 px(360,40,723,150,`background:${c.a};border-radius:36px`)+tx(360,40,723,150,`<div style="font-family:Changa,Tajawal;font-size:54px;font-weight:800;color:#fff">${ttl(m)}</div>`)+px(681,172,120,5,`background:${c.b};border-radius:3px`)+
 px(360,206,723,330,`background:#fff;border-radius:36px`)+tx(360,232,723,34,`<div style="font-size:18px;color:#64748B;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+tx(380,274,683,110,`<div style="font-family:'El Messiri',Amiri,serif;font-size:${nameSz(m,66)}px;font-weight:800;color:${c.a}">${m.name}</div>`)+px(461,392,200,4,`background:${c.b};border-radius:2px`)+tx(420,410,583,110,`<div style="font-size:21px;font-weight:600;color:#334155;line-height:1.9">${m.reason}</div>`)+
 px(360,552,723,202,`background:${c.c};border-radius:36px`)+tx(380,572,683,160,`<div style="font-family:'El Messiri',Amiri,serif;font-size:30px;font-weight:800;color:${c.a}">مع أطيب التمنيات بدوام التفوّق</div>`)+`</div>`,
glass:(m,c)=>`<div class="kpage" style="background:${c.a};font-family:Tajawal,Cairo,sans-serif">`+
 px(-80,-60,420,420,`border-radius:50%;background:${c.b};filter:blur(70px);opacity:.75`)+px(800,-40,400,400,`border-radius:50%;background:${c.g};filter:blur(80px);opacity:.55`)+px(300,520,520,420,`border-radius:50%;background:${c.b};filter:blur(90px);opacity:.45`)+
 px(56,56,1011,682,`border-radius:40px;background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.38);box-shadow:0 30px 70px rgba(0,0,0,.35)`)+
 tx(56,84,1011,40,`<div style="font-size:15px;color:#DCE6FF;font-weight:700;letter-spacing:2px">${m.stageLabel} · ${m.date}</div>`)+
 tx(56,126,1011,100,`<div style="font-family:Changa,Tajawal;font-size:60px;font-weight:800;color:#fff">${ttl(m)}</div>`)+px(521,236,80,4,`background:${c.b};border-radius:2px`)+
 tx(56,262,1011,34,`<div style="font-size:18px;color:#C7D8F5;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+tx(100,300,923,110,`<div style="font-family:'El Messiri',Amiri,serif;font-size:${nameSz(m,66)}px;font-weight:800;color:#fff">${m.name}</div>`)+
 tx(160,430,803,110,`<div style="font-size:21px;font-weight:600;color:#E6EEFF;line-height:1.9">${m.reason}</div>`)+px(120,580,883,1.5,'background:rgba(255,255,255,.35)')+sig(m,'#fff','#BFD3FF',200,610,723)+`</div>`,
editorial:(m,c)=>`<div class="kpage" style="background:#F6F3EB;font-family:Tajawal,Cairo,sans-serif">`+
 tx(0,60,W,620,`<div style="font-family:Changa,Tajawal;font-size:300px;font-weight:800;color:#111;opacity:.05;line-height:1">٢٠٢٦</div>`)+
 px(60,60,14,14,`background:${c.b}`)+px(60,96,1003,2,'background:#111')+px(60,690,1003,1.5,'background:#111')+
 tx(560,64,503,30,`<div style="font-size:14px;font-weight:800;color:#111;text-align:left;width:100%;padding-left:0">${m.stageLabel} — ${m.date}</div>`)+
 tx(60,138,W-120,100,`<div style="font-family:'El Messiri',Amiri,serif;font-size:66px;font-weight:800;color:#111">${ttl(m)}</div>`)+px(521,250,80,4,`background:${c.b}`)+
 tx(60,282,W-120,34,`<div style="font-size:18px;color:#6B6455;font-weight:700">تُمنح هذه الشهادة إلى</div>`)+tx(100,322,W-200,120,`<div style="font-family:Amiri,'Noto Naskh Arabic',serif;font-size:${nameSz(m,74)}px;font-weight:700;color:${c.a}">${m.name}</div>`)+
 tx(200,460,W-400,110,`<div style="font-size:21px;font-weight:600;color:#3F3B31;line-height:1.9">${m.reason}</div>`)+sig(m,'#111','#6B6455',200,604,723)+`</div>`,
brut:(m,c)=>{const bx=(x,y,w,h,bg,ex)=>px(x,y,w,h,`background:${bg};border:4px solid #111;border-radius:18px;box-shadow:8px 8px 0 #111;${ex||''}`);
 return `<div class="kpage" style="background:${c.b};font-family:Tajawal,Cairo,sans-serif">`+
 px(0,0,W,56,'background:#111')+tx(0,0,W,56,`<div style="font-family:Changa,Tajawal;font-size:20px;color:${c.b};font-weight:800;letter-spacing:3px;white-space:nowrap">★ ${m.school} ★ ${m.school} ★ ${m.school} ★ ${m.school} ★</div>`)+
 bx(60,100,1000,170,'#fff')+tx(60,100,1000,170,`<div style="font-family:Changa,Tajawal;font-size:62px;font-weight:800;color:#111">${ttl(m)}</div>`)+
 bx(60,300,1000,230,'#fff')+tx(60,314,1000,34,`<div style="font-size:18px;color:#444;font-weight:800">تُمنح هذه الشهادة إلى</div>`)+tx(80,350,960,96,`<div style="font-family:Changa,'El Messiri',serif;font-size:${nameSz(m,62)}px;font-weight:800;color:${c.a}">${m.name}</div>`)+tx(120,446,880,74,`<div style="font-size:19px;font-weight:700;color:#222;line-height:1.7">${m.reason}</div>`)+
 bx(60,570,480,120,c.a)+tx(60,570,480,120,`<div><div style="font-size:12px;color:${c.b};font-weight:800">المدرّس</div><div style="font-size:24px;color:#fff;font-weight:800">${m.teacher}</div></div>`)+
 bx(580,570,480,120,'#fff')+tx(580,570,480,120,`<div><div style="font-size:12px;color:#555;font-weight:800">${m.stageLabel}</div><div style="font-size:22px;color:#111;font-weight:800">${m.date}</div></div>`)+`</div>`}};
const FAMS=[['bento26','بينتو ٢٠٢٦','bento'],['glass26','زجاجي أورورا','glass'],['edit26','تحريري هادئ','editorial'],['brut26','نيو بروتاليست','brut']];
FAMS.forEach(([fam,label,key])=>{Object.keys(PAL).forEach((pk,vi)=>{const id='lib-'+fam+'-'+pk;CERTS[id]={label:label+' — '+PAL[pk].n,cat:'modern',subjects:'any',aud:['child','mature'],render:m=>F[key](m,PAL[pk])};LIBMETA[id]={fam,cat:'modern',pal:pk,v:vi,label:CERTS[id].label}})});
})();
