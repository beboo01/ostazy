/* قوالب ستوري متحركة إضافية، تصميم أصلي، بدون بيانات طلبة حقيقية (كل النصوص يكتبها المدرس). */
(function(){'use strict';
if(typeof VTPLS==='undefined')return;
const base={duration:10,width:540,height:960,fps:30};
const T=(v,font,size,color,y,a,b,x)=>Object.assign({type:'text',value:v,font,weight:800,size,color,y,fadeIn:[a,b],maxW:440},x||{});
const S=(shape,o)=>Object.assign({type:'shape',shape},o);
Object.assign(VTPLS,{
'countdown':{label:'عد تنازلي للامتحان',photo:false,
 defaults:{title:'باقي على الامتحان',num:'٣',unit:'أيام',subject:'مراجعة الرياضيات',cta:'احجز مكانك في المراجعة النهائية'},
 fields:[['title','العنوان'],['num','الرقم'],['unit','الوحدة'],['subject','المادة'],['cta','دعوة']],
 build(v){return Object.assign({},base,{background:{from:'#0B1F44',to:'#050E24'},layers:[
  S('circle',{x:270,y:420,r:210,color:'#00D4FF',alpha:.12,fadeIn:[0,1],zoomFrom:.6,zoomTo:1.05}),
  S('circle',{x:270,y:420,r:160,color:'#00D4FF',alpha:.18,fadeIn:[.3,1.3],zoomFrom:.6,zoomTo:1.05}),
  T(v.title,'Noto Kufi Arabic',44,'#FFFFFF',190,.5,1.5,{slideIn:'up'}),
  T(v.num,'Changa',210,'#00D4FF',460,1,2,{zoomFrom:.5,zoomTo:1,maxW:300}),
  T(v.unit,'Cairo',56,'#FF8A1F',560,1.8,2.8),
  T(v.subject,'Cairo',36,'#C9D6EE',700,2.6,3.6),
  S('rect',{x:120,y:760,w:300,h:6,radius:3,color:'#FF8A1F',fadeIn:[3.2,4]}),
  T(v.cta,'Cairo',30,'#FFFFFF',850,4,5,{pulse:{scale:1.05,period:1.6}})]})}},
'honor':{label:'لوحة الشرف',photo:false,
 defaults:{title:'لوحة الشرف',period:'متفوقو الشهر',n1:'الأول',n2:'الثاني',n3:'الثالث',foot:'مبروك لكل المتفوقين'},
 fields:[['title','العنوان'],['period','الفترة'],['n1','المركز الأول'],['n2','المركز الثاني'],['n3','المركز الثالث'],['foot','عبارة ختام']],
 build(v){return Object.assign({},base,{background:{from:'#FFF7E6',to:'#F3E3C3'},layers:[
  S('circle',{x:270,y:150,r:80,color:'#D9A441',alpha:.35,fadeIn:[0,1],zoomFrom:.5,zoomTo:1.05}),
  T('★','Amiri',90,'#B8802B',175,.2,1,{maxW:120}),
  T(v.title,'Amiri',64,'#6B4A1F',300,.6,1.6,{slideIn:'up'}),
  T(v.period,'Cairo',30,'#8A5A22',360,1,2),
  S('rect',{x:70,y:420,w:400,h:86,radius:20,color:'#D9A441',alpha:.9,fadeIn:[1.4,2.2],slideIn:'right'}),
  T('١  '+v.n1,'Changa',40,'#3A2410',478,1.6,2.4,{maxW:360}),
  S('rect',{x:70,y:540,w:400,h:86,radius:20,color:'#C9CED6',alpha:.95,fadeIn:[2.4,3.2]}),
  T('٢  '+v.n2,'Changa',40,'#2B3340',598,2.6,3.4,{maxW:360}),
  S('rect',{x:70,y:660,w:400,h:86,radius:20,color:'#D69A6B',alpha:.9,fadeIn:[3.4,4.2]}),
  T('٣  '+v.n3,'Changa',40,'#3A2410',718,3.6,4.4,{maxW:360}),
  T(v.foot,'Noto Naskh Arabic',32,'#4A3320',860,5,6)]})}},
'tips':{label:'نصائح المذاكرة',photo:false,
 defaults:{title:'٣ نصائح قبل الامتحان',t1:'نام كويس قبل اليوم الأول',t2:'حل أوراق السنين السابقة',t3:'راجع أخطاءك مش بس الصح',from:'مدرّسك'},
 fields:[['title','العنوان'],['t1','النصيحة الأولى'],['t2','النصيحة الثانية'],['t3','النصيحة الثالثة'],['from','التوقيع']],
 build(v){return Object.assign({},base,{background:{from:'#0F5C4C',to:'#07322B'},layers:[
  S('rect',{x:40,y:110,w:460,h:90,radius:22,color:'#FFD166',fadeIn:[0,.8]}),
  T(v.title,'Noto Kufi Arabic',42,'#07322B',170,.3,1.2,{maxW:420}),
  S('circle',{x:455,y:330,r:34,color:'#FFD166',fadeIn:[1,1.6],zoomFrom:.4,zoomTo:1}),T('١','Changa',44,'#07322B',379,1,1.6,{maxW:60,x:489}),
  T(v.t1,'Cairo',34,'#FFFFFF',340,1.4,2.4,{maxW:350,x:240,slideIn:'left'}),
  S('circle',{x:455,y:500,r:34,color:'#FFD166',fadeIn:[2.4,3],zoomFrom:.4,zoomTo:1}),T('٢','Changa',44,'#07322B',549,2.4,3,{maxW:60,x:489}),
  T(v.t2,'Cairo',34,'#FFFFFF',510,2.8,3.8,{maxW:350,x:240,slideIn:'left'}),
  S('circle',{x:455,y:670,r:34,color:'#FFD166',fadeIn:[3.8,4.4],zoomFrom:.4,zoomTo:1}),T('٣','Changa',44,'#07322B',719,3.8,4.4,{maxW:60,x:489}),
  T(v.t3,'Cairo',34,'#FFFFFF',680,4.2,5.2,{maxW:350,x:240,slideIn:'left'}),
  T(v.from,'Amiri',38,'#FFD166',850,5.6,6.6)]})}},
'newterm':{label:'بداية الترم',photo:false,
 defaults:{title:'بداية الترم الجديد',date:'السبت القادم',stage:'لكل المراحل',line:'مجموعات جديدة ومواعيد مناسبة',cta:'احجز مكانك دلوقتي'},
 fields:[['title','العنوان'],['date','موعد البداية'],['stage','المرحلة'],['line','سطر تعريفي'],['cta','دعوة']],
 build(v){return Object.assign({},base,{background:{from:'#0F3C8A',to:'#0B1235'},layers:[
  S('circle',{x:430,y:120,r:130,color:'#FF8A1F',alpha:.28,fadeIn:[0,1.2],zoomFrom:.6,zoomTo:1.1}),
  S('circle',{x:90,y:760,r:170,color:'#00D4FF',alpha:.16,fadeIn:[.4,1.6],zoomFrom:.6,zoomTo:1.1}),
  T(v.title,'Noto Kufi Arabic',58,'#FFFFFF',300,.6,1.6,{slideIn:'up'}),
  S('rect',{x:90,y:350,w:360,h:8,radius:4,color:'#FF8A1F',fadeIn:[1.4,2.2]}),
  T(v.date,'Changa',64,'#00D4FF',470,2,3,{zoomFrom:.8,zoomTo:1}),
  T(v.stage,'Cairo',38,'#C9D6EE',560,2.8,3.8),
  T(v.line,'Noto Naskh Arabic',34,'#FFFFFF',680,3.6,4.6,{maxW:400}),
  S('rect',{x:110,y:790,w:320,h:80,radius:40,color:'#FF8A1F',fadeIn:[4.4,5.2]}),
  T(v.cta,'Cairo',32,'#0B1235',845,4.6,5.4,{maxW:300,pulse:{scale:1.04,period:1.6}})]})}},
'review':{label:'مراجعة نهائية',photo:false,
 defaults:{title:'مراجعة ليلة الامتحان',subject:'مادة اللغة العربية',when:'الأربعاء الساعة ٧ مساءً',place:'في السنتر',bring:'هات ورقة وقلم وأسئلتك'},
 fields:[['title','العنوان'],['subject','المادة'],['when','الموعد'],['place','المكان'],['bring','المطلوب']],
 build(v){return Object.assign({},base,{background:{from:'#0B3B4F',to:'#04202B'},layers:[
  S('rect',{x:40,y:120,w:460,h:700,radius:26,color:'#FFFFFF',alpha:.08,fadeIn:[0,1],zoomFrom:.94,zoomTo:1}),
  T(v.title,'Noto Kufi Arabic',48,'#BDEBFF',230,.5,1.5,{slideIn:'up'}),
  T(v.subject,'Changa',44,'#FFFFFF',340,1.4,2.4),
  S('rect',{x:120,y:390,w:300,h:5,radius:3,color:'#FF8A1F',fadeIn:[2,2.6]}),
  T(v.when,'Cairo',38,'#FFD166',500,2.4,3.4,{slideIn:'up'}),
  T(v.place,'Cairo',34,'#FFFFFF',590,3.2,4.2),
  T(v.bring,'Noto Naskh Arabic',32,'#BFD9E6',720,4,5,{maxW:400})]})}},
'results':{label:'نتيجة وشكر',photo:false,
 defaults:{title:'ألف مبروك',big:'٩٨٪',label:'نسبة النجاح',msg:'شكرًا لثقتكم، والعام الجاي أحلى',from:'مدرّسكم'},
 fields:[['title','العنوان'],['big','الرقم'],['label','وصف الرقم'],['msg','رسالة'],['from','التوقيع']],
 build(v){return Object.assign({},base,{background:{from:'#0B3B2E',to:'#04201A'},layers:[
  S('circle',{x:270,y:400,r:200,color:'#FFD166',alpha:.14,fadeIn:[0,1],zoomFrom:.6,zoomTo:1.06}),
  T(v.title,'Amiri',70,'#FFD166',210,.4,1.4,{slideIn:'up'}),
  T(v.big,'Changa',190,'#FFFFFF',470,1,2,{zoomFrom:.5,zoomTo:1,maxW:380}),
  T(v.label,'Cairo',42,'#9FE3C8',560,1.8,2.8),
  T(v.msg,'Noto Naskh Arabic',36,'#FFFFFF',700,2.8,3.8,{maxW:400}),
  T(v.from,'Amiri',40,'#FFD166',830,4,5)]})}},
'quote':{label:'اقتباس تحفيزي',photo:false,
 defaults:{quote:'النجاح بيبدأ بقرار إنك تذاكر النهاردة',who:'مدرّسك',tag:'رسالة اليوم'},
 fields:[['tag','عنوان صغير'],['quote','الاقتباس'],['who','المصدر']],
 build(v){return Object.assign({},base,{background:{from:'#0B1F44',to:'#050E24'},layers:[
  T('❝','Amiri',200,'#FF8A1F',340,0,1,{maxW:200}),
  T(v.tag,'Cairo',30,'#7DD3FC',120,.3,1.2),
  T(v.quote,'Noto Naskh Arabic',50,'#FFFFFF',500,1,2.2,{maxW:420,slideIn:'up'}),
  S('rect',{x:200,y:660,w:140,h:6,radius:3,color:'#FF8A1F',fadeIn:[2.6,3.2]}),
  T(v.who,'Amiri',40,'#FFD166',760,3,4)]})}}
});
if(typeof fillVTplSel==='function')fillVTplSel();
})();
