/* Account contacts are separate from all teacher/student state. */
(()=>{
'use strict';
let account=null,error='',open=false,feedback='',loading=false,loadEpoch57=0,identityEpoch57=0;
function clear57(){identityEpoch57++;loadEpoch57++;account=null;error='';open=false;feedback='';loading=false;}
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date=v=>v?new Date(v).toLocaleDateString('ar-EG-u-nu-latn',{timeZone:'Africa/Cairo'}):'غير مسجل';
const choiceName=v=>({subscribe:'أرغب في الاشتراك',not_now:'ليس الآن',undecided:'لم يقرر'}[v]||'لم يقرر');
async function load(client){
 const load57=++loadEpoch57;loading=true;
 try{const r=await client.rpc('ostazy_my_account_status');if(load57!==loadEpoch57)return account;if(r.error)throw r.error;account=r.data||null;error='';}
 catch(e){if(load57!==loadEpoch57)return account;account=null;error='تعذّر تحميل بيانات التواصل. ده مش بيغيّر بيانات طلابك أو مواعيد اشتراكك.';}
 finally{if(load57===loadEpoch57)loading=false;}
 return account;
}
function html(){
 if(error)return '<div class="card customer-account"><p>'+esc(error)+'</p><button class="ghost sm" data-customer-action="refresh">حاول تاني</button></div>';
 if(!account)return '';
 const p=account.profile,expired=account.subscription_state==='expired';
 const heading=expired?'قرارك بعد التجربة':'بيانات حسابك والتجربة';
 let s='<section class="card customer-account" aria-label="بيانات حساب صاحب المجموعات"><div class="row"><b>'+heading+'</b><button class="ghost sm fx" type="button" data-customer-action="toggle" aria-expanded="'+open+'">'+(open?'إخفاء البيانات':p?'بيانات التواصل':'أضف بيانات التواصل')+'</button></div>';
 if(account.trial_started_at&&account.trial_ends)s+='<p class="customer-dates">بداية التجربة: '+esc(date(account.trial_started_at))+' · نهايتها: '+esc(date(account.trial_ends))+'.</p>';
 if(expired){
  s+='<p>التجربة خلصت، والقرار ليك. مفيش خصم أو تجديد تلقائي، وبياناتك متاحة للقراءة والنسخ الاحتياطي.</p><p>اختيارك المسجل: <b>'+esc(choiceName(p?.subscription_choice))+'</b></p><div class="btns"><button type="button" data-customer-action="choice" data-choice="subscribe">أرغب في الاشتراك</button><button type="button" class="ghost" data-customer-action="choice" data-choice="not_now">ليس الآن</button></div>';
 }
 if(open){
  s+='<div class="customer-fields"><p>تستخدم إدارة أستاذي بيانات تواصلك لمتابعة التجربة والاشتراك.</p><label for="customerName">اسمك</label><input id="customerName" name="name" autocomplete="name" maxlength="100" value="'+esc(p?.full_name)+'"><label for="customerPhone">رقم موبايلك</label><input id="customerPhone" type="tel" inputmode="tel" autocomplete="tel" maxlength="25" dir="ltr" value="'+esc(p?.phone)+'"><label class="customer-consent"><input type="checkbox" id="customerConsent"'+(p?.marketing_opt_in?' checked':'')+'> أوافق على استلام عروض أستاذي على هذا الرقم (اختياري). يمكنني إلغاء الموافقة في أي وقت.</label><button type="button" class="sm" data-customer-action="save">حفظ بيانات التواصل</button><p class="customer-privacy">رسائل العروض اختيارية ولا تؤثر على التجربة أو الاشتراك.</p></div>';
 }
 s+='<p id="customerFeedback" class="customer-feedback" role="status" aria-live="polite">'+esc(feedback)+'</p></section>';
 return s;
}
async function handleClick(event,{client,render}){
 const button=event.target.closest('[data-customer-action]');if(!button)return false;
 const action=button.dataset.customerAction,identity57=identityEpoch57;
 if(action==='toggle'){open=!open;feedback='';render();return true;}
 if(loading)return true;
 if(action==='refresh'){await load(client);render();return true;}
 if(action==='choice'&&!account?.profile){open=true;feedback='أضف بيانات التواصل أولًا لتسجيل اختيارك. لن يتم خصم أي مبلغ.';render();return true;}
 button.disabled=true;feedback='جاري حفظ اختيارك...';
 const status=document.getElementById('customerFeedback');if(status)status.textContent=feedback;
 try{
  let r;
  if(action==='save'){
   const name=document.getElementById('customerName')?.value.trim()||'',phone=document.getElementById('customerPhone')?.value.trim()||'',opt=document.getElementById('customerConsent')?.checked===true;
   if(name.length<2||name.length>100)throw new Error('اكتب اسمك من حرفين إلى 100 حرف.');
   const normalized=phone.replace(/[٠-٩۰-۹]/g,c=>String(c.charCodeAt(0)>1775?c.charCodeAt(0)-1776:c.charCodeAt(0)-1632)).replace(/[\s()-]/g,'');
   if(!/^\+?[0-9]{8,15}$/.test(normalized))throw new Error('اكتب رقم موبايل صحيح، بالأرقام وممكن علامة + في أوله.');
   r=await client.rpc('ostazy_save_customer_profile',{p_full_name:name,p_phone:normalized,p_marketing_opt_in:opt});
  }else if(action==='choice'){
   if(!['subscribe','not_now'].includes(button.dataset.choice))return true;
   r=await client.rpc('ostazy_set_subscription_choice',{p_choice:button.dataset.choice});
  }else return false;
  if(identity57!==identityEpoch57)return true;
  if(r.error)throw new Error('الحفظ ما تمّش. حاول تاني من غير ما تغيّر بيانات طلابك.');
  await load(client);if(identity57!==identityEpoch57)return true;
  feedback=action==='save'?(account?.profile?.marketing_opt_in?'تم حفظ بياناتك وموافقتك على استقبال العروض. مفيش رسائل بتتبعت تلقائيًا، وتقدر تلغي الموافقة من هنا.':'تم حفظ بياناتك بدون موافقة على رسائل العروض.'):button.dataset.choice==='subscribe'?'تم تسجيل رغبتك في الاشتراك. تواصل على واتساب لاستكمال الدفع والتفعيل. لم يتم خصم أي مبلغ.':'تم تسجيل اختيارك. مفيش خصم أو تجديد تلقائي، وتقدر تغيّر رأيك بعدين.';
 }catch(e){if(identity57!==identityEpoch57)return true;feedback=e.message||'تعذّر الحفظ. حاول تاني.';}
 finally{if(identity57===identityEpoch57){button.disabled=false;render();}}
 return true;
}
function adminHtml(rows){
 const counts={paid:0,trial:0,expired:0};for(const r of rows)if(counts[r.subscription_state]!=null)counts[r.subscription_state]++;
 let s='<div class="card"><h2>سجل العملاء الخاص</h2><p>حسابات المشتركين وفترات التجربة. بيانات التواصل يضيفها أصحاب الحسابات، والأرقام غير موثقة برسالة موبايل. تظهر الحسابات المسجلة فقط؛ طلبات واتساب دون حساب غير مدرجة.</p><div class="btns"><span class="tag ok">ساري: '+counts.paid+'</span><span class="tag warn">تجربة: '+counts.trial+'</span><span class="tag bad">منتهي: '+counts.expired+'</span></div><label for="customerSearch">ابحث بالاسم أو الرقم أو الإيميل</label><input id="customerSearch" type="search" placeholder="ابحث في سجلّك الخاص"></div>';
 s+=rows.length?rows.map(r=>{
  const state=r.subscription_state==='paid'?'<span class="tag ok">اشتراك ساري</span>':r.subscription_state==='trial'?'<span class="tag warn">تجربة، باقي '+esc(r.trial_remaining_days)+' يوم</span>':'<span class="tag bad">منتهي</span>';
  const hay=[r.full_name,r.phone,r.email].filter(Boolean).join(' ').toLowerCase();
  return '<article class="card customer-record" data-customer-search="'+esc(hay)+'"><div class="stu"><b>'+esc(r.full_name||'الاسم غير مسجل')+'</b>'+state+'</div><p dir="ltr" style="text-align:start;overflow-wrap:anywhere">'+esc(r.email)+'</p><p>الموبايل: <b dir="ltr">'+esc(r.phone||'غير مسجل')+'</b></p><p>بداية التجربة: '+esc(date(r.trial_started_at))+' · نهاية التجربة: '+esc(date(r.trial_ends))+'</p><p>مدفوع لحد: '+esc(date(r.paid_until))+' · قرار العميل: '+esc(choiceName(r.subscription_choice))+'</p><p><span class="tag '+(r.marketing_opt_in?'ok':'warn')+'">'+(r.marketing_opt_in?'موافق على رسائل العروض':'لا يوجد إذن برسائل العروض')+'</span>'+(r.marketing_opt_in?' · موافقة مسجلة: '+esc(date(r.marketing_consent_at)):'')+'</p><div class="btns"><button class="sm" data-a="adm-ext" data-id="'+esc(r.user_id)+'">تجديد شهر</button><input type="date" style="width:auto" id="admd_'+esc(r.user_id)+'" aria-label="تاريخ التفعيل"><button class="sm ghost" data-a="adm-set" data-id="'+esc(r.user_id)+'">تفعيل لحد التاريخ</button></div><small>فعّل الاشتراك بعد تأكيد استلام المبلغ. هذا الزر لا يخصم أموالًا.</small></article>';
 }).join(''):'<div class="card"><p>مفيش حسابات في السجل لسه.</p></div>';
 return s;
}
function search(value){const q=String(value||'').trim().toLowerCase();document.querySelectorAll('[data-customer-search]').forEach(e=>e.hidden=q&&!e.dataset.customerSearch.includes(q));}
window.OstazyAccount46={load,clear:clear57,html,handleClick,adminHtml,search,snapshot:()=>account};
})();
