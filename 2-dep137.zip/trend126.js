/* قوالب إعلان اتجاهات ٢٠٢٦ (أصلية): بينتو، زجاجي، أورورا، نيو بروتاليست، طين ناعم، تحريري.
   شبكة ٨px، هوامش ثابتة، تسلسل: تمهيد، عنوان، مدرّس/صف، مميزات، مواعيد، تواصل. */
(function(){'use strict';
if(typeof TPLS==='undefined'||typeof mkEls==='undefined')return;
const fs=(s,m)=>Math.min(m,Math.floor(1000/Math.max(3,s.length)));
const R=(x,y,w,h,bg,r,ex)=>bl(x,y,w,h,bg,`border-radius:${r}px;`+(ex||''));
const L=(x,y,w,t,c,sz,ex)=>`<div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;text-align:center;font-family:Tajawal,Cairo,sans-serif;font-weight:800;font-size:${sz||10}px;letter-spacing:.3px;color:${c};${ex||''}">${t}</div>`;
const E=(id,nm,x,y,o)=>[id,nm,x,y,o];
const base=(kind)=>({hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',flat:true});
Object.assign(TPLS,{
bento:Object.assign(base(),{label:'بينتو ٢٠٢٦',desc:'شبكة بطاقات مستديرة بمسافات ثابتة، كل معلومة في بطاقتها',dots:['#0B1F44','#FBBF24','#F1EEE7'],
 fx(){const s=adSubjName(),a=pal.acc;return bl(0,0,500,625,'#F1EEE7')+R(24,24,452,196,'#0B1F44',24)+R(204,170,92,4,a,2)+
  R(24,232,218,132,a,24)+R(258,232,218,132,'#fff',24,'box-shadow:0 1px 0 rgba(0,0,0,.05)')+R(24,376,452,76,'#14181F',24)+R(24,464,452,56,'#fff',24)+R(24,532,296,70,'#16A34A',24)+R(332,532,144,70,'#E4DFD2',24)+
  L(24,254,218,'المدرّس',pal.onAcc||'#10203A',11,'opacity:.7')+L(258,252,218,'المادة','#64748B',11)+
  `<div style="position:absolute;left:258px;width:218px;top:272px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${Math.min(30,Math.floor(560/Math.max(4,s.length)))}px;color:#0B1F44;line-height:1.2">${s}</div>`+L(24,386,452,'المواعيد','#94A3B8',11)},
 els(){return mkEls([E('season',NM.season,404,567,{text:TXT,size:10.5,color:'#3A352A',mw:120,weight:800}),
  E('kicker',NM.kicker,250,62,{text:'احجز مكانك الآن في',size:14,weight:800,color:pal.acc}),
  E('title',NM.title,250,126,{text:'العنوان',font:'Changa',size:46,weight:800,color:'#fff',mw:410}),
  E('teacher',NM.teacher,133,312,{text:'الأستاذ أحمد علي',font:'El Messiri',size:24,color:pal.onAcc||'#10203A',mw:190}),
  E('stage',NM.stage,367,338,{text:'المرحلة',size:13,weight:800,color:'#475569',mw:200}),
  E('sched',NM.sched,250,424,{text:SCH,size:17,weight:800,color:'#fff',mw:420}),
  E('chips',NM.chips,250,492,{text:CH,size:13,weight:700,color:'#334155',mw:420}),
  E('phone',NM.phone,172,567,{text:PH,size:16,weight:800,color:'#fff'})])}}),
glass:Object.assign(base(),{label:'زجاجي أورورا',desc:'لوح زجاجي بمسافات متوازنة فوق سحب ألوان زرقاء وتيل وذهبي',dots:['#0A1430','#1D4ED8','#06B6D4'],
 fx(){const b=(x,y,r,c,o)=>`<div style="position:absolute;left:${x-r}px;top:${y-r}px;width:${2*r}px;height:${2*r}px;border-radius:50%;background:${c};filter:blur(48px);opacity:${o||.85}"></div>`;
  return bl(0,0,500,625,'#0A1430','overflow:hidden')+b(80,110,120,'#1D4ED8')+b(430,170,100,'#06B6D4')+b(330,570,120,pal.acc,.8)+b(50,540,90,'#F97316',.7)+
  R(32,96,436,432,'rgba(255,255,255,.12)',32,'border:1.5px solid rgba(255,255,255,.36);box-shadow:0 24px 56px rgba(0,0,0,.38)')+
  bl(112,140,48,1.5,'rgba(255,255,255,.55)')+bl(340,140,48,1.5,'rgba(255,255,255,.55)')+bl(72,264,356,1.5,'rgba(255,255,255,.28)')+R(32,544,436,56,'rgba(255,255,255,.12)',28,'border:1.5px solid rgba(255,255,255,.3)')},
 els(){return mkEls([E('season',NM.season,250,52,{text:TXT,size:12,color:'#fff',weight:800,bg:'rgba(255,255,255,.16)',radius:99,pad:'4px 16px'}),
  E('kicker',NM.kicker,250,140,{text:'احجز مكانك الآن في',size:14,weight:700,color:'#DCE6FF'}),
  E('title',NM.title,250,212,{text:'العنوان',font:'Changa',size:50,weight:800,color:'#fff',mw:380}),
  E('teacher',NM.teacher,250,308,{text:'الأستاذ أحمد علي',font:'El Messiri',size:28,color:'#fff'}),
  E('stage',NM.stage,250,348,{text:'المرحلة',size:14,color:'#BFD3FF'}),
  E('chips',NM.chips,250,404,{text:CH,size:13,weight:700,color:'#E6EEFF',bg:'rgba(255,255,255,.12)',radius:99,pad:'6px 18px',mw:380}),
  E('sched',NM.sched,250,468,{text:SCH,size:16,weight:800,color:pal.onAcc||'#10203A',bg:pal.acc,radius:99,pad:'8px 24px'}),
  E('phone',NM.phone,250,572,{text:PH,size:16,weight:800,color:'#fff'})])}}),
aurora:Object.assign(base(),{label:'تدرج شبكي ضخم',desc:'تدرجات شبكية زرقاء وتيل وبرتقالي، اسم المادة عملاق شفاف وتسلسل واضح',dots:['#0B1F44','#06B6D4','#F59E0B'],
 fx(){const s=adSubjName();return bl(0,0,500,625,'radial-gradient(440px 380px at 12% 10%,#1D4ED8 0%,transparent 70%),radial-gradient(380px 340px at 92% 34%,#06B6D4 0%,transparent 70%),radial-gradient(460px 400px at 28% 102%,#F59E0B 0%,transparent 72%),#0B1F44')+
  `<div style="position:absolute;left:0;right:0;top:40px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${fs(s,180)}px;line-height:1.1;color:#fff;opacity:.2;white-space:nowrap">${s}</div>`+bl(36,290,428,1.5,'rgba(255,255,255,.5)')+bl(224,508,52,3,'#fff','border-radius:2px;opacity:.7')},
 els(){return mkEls([E('season',NM.season,250,30,{text:TXT,size:11,color:'#fff',weight:800}),
  E('kicker',NM.kicker,250,322,{text:'احجز مكانك الآن',size:14,weight:800,color:'#FDE68A'}),
  E('title',NM.title,250,392,{text:'العنوان',font:'Changa',size:54,weight:800,color:'#fff',mw:420}),
  E('teacher',NM.teacher,250,456,{text:'الأستاذ أحمد علي',font:'El Messiri',size:28,color:'#fff'}),
  E('stage',NM.stage,250,490,{text:'المرحلة',size:14,color:'#BAE6FD'}),
  E('chips',NM.chips,250,530,{text:CH,size:12.5,weight:700,color:'#fff',mw:420}),
  E('sched',NM.sched,250,568,{text:SCH,size:15,weight:800,color:'#0B1F44',bg:'#fff',radius:99,pad:'7px 22px'}),
  E('phone',NM.phone,250,604,{text:PH,size:13,weight:800,color:'#fff'})])}}),
neobrut:Object.assign(base(),{label:'نيو بروتاليست',desc:'حدود سوداء سميكة وظلال مزاحة وألوان صريحة بشبكة منظمة',dots:['#FFE066','#111','#FF8A1F'],
 fx(){const s=adSubjName(),bx=(x,y,w,h,c)=>bl(x,y,w,h,c,'border:3px solid #111;box-shadow:5px 5px 0 #111;border-radius:12px');
  return bl(0,0,500,625,'#FFE066')+bl(0,0,500,44,'#111')+L(0,10,500,`${s} ★ ${s} ★ ${s} ★ ${s}`,'#FFE066',15,'white-space:nowrap;overflow:hidden;font-family:Changa,Tajawal,sans-serif')+
  bx(32,76,432,174,'#fff')+bx(32,274,262,70,'#FF8A1F')+bx(310,274,154,70,'#5EB6FF')+bx(32,368,432,56,'#fff')+bx(32,448,432,62,'#111')+bx(32,534,262,62,'#7CE38B')+bx(310,534,154,62,'#fff')},
 els(){return mkEls([E('season',NM.season,387,565,{text:TXT,size:10.5,color:'#111',weight:800,mw:130}),
  E('kicker',NM.kicker,248,110,{text:'احجز مكانك الآن في',size:14,weight:800,color:'#111'}),
  E('title',NM.title,248,184,{text:'العنوان',font:'Changa',size:50,weight:800,color:'#111',accw:'#C2410C',mw:400}),
  E('teacher',NM.teacher,163,309,{text:'الأستاذ أحمد علي',font:'El Messiri',size:23,color:'#111',mw:236}),
  E('stage',NM.stage,387,309,{text:'المرحلة',size:11.5,weight:800,color:'#111',mw:140}),
  E('chips',NM.chips,248,396,{text:CH,size:13,weight:800,color:'#111',mw:410}),
  E('sched',NM.sched,248,479,{text:SCH,size:16,weight:800,color:'#FFE066',mw:410}),
  E('phone',NM.phone,163,565,{text:PH,size:16,weight:800,color:'#111'})])}}),
clay:Object.assign(base(),{label:'طين ناعم',desc:'كرات باستيل بظلال داخلية وبطاقة مركزية متوازنة بالأزرق والتيل والبرتقالي',dots:['#ECFEFF','#38BDF8','#FB923C'],
 fx(){const o=(x,y,r,c)=>`<div style="position:absolute;left:${x-r}px;top:${y-r}px;width:${2*r}px;height:${2*r}px;border-radius:50%;background:${c};box-shadow:inset -14px -16px 30px rgba(0,0,0,.12),inset 12px 12px 26px rgba(255,255,255,.55),0 22px 34px rgba(10,60,100,.18)"></div>`;
  return bl(0,0,500,625,'linear-gradient(180deg,#ECFEFF,#E0F2FE)')+o(420,84,64,'#38BDF8')+o(70,120,38,'#FB923C')+o(446,560,50,'#FCD34D')+o(54,574,32,'#5EEAD4')+
  R(36,160,428,330,'rgba(255,255,255,.78)',36,'box-shadow:0 22px 44px rgba(10,60,100,.14)')+bl(224,318,52,3,'#0E7490','border-radius:2px;opacity:.55')+R(120,536,260,46,'rgba(255,255,255,.85)',23,'box-shadow:0 10px 24px rgba(10,60,100,.12)')},
 els(){return mkEls([E('season',NM.season,176,44,{text:TXT,size:11,color:'#0C4A6E',weight:800}),
  E('kicker',NM.kicker,250,204,{text:'احجز مكانك الآن في',size:14,weight:800,color:'#0E7490'}),
  E('title',NM.title,250,274,{text:'العنوان',font:'Changa',size:46,weight:800,color:'#0B2A4A',accw:'#0E7490',mw:380}),
  E('teacher',NM.teacher,250,358,{text:'الأستاذ أحمد علي',font:'El Messiri',size:26,color:'#0B2A4A'}),
  E('stage',NM.stage,250,396,{text:'المرحلة',size:14,color:'#4B6A88'}),
  E('chips',NM.chips,250,432,{text:CH,size:12.5,weight:700,color:'#0C4A6E',mw:380}),
  E('sched',NM.sched,250,462,{text:SCH,size:14,weight:800,color:'#fff',bg:'#0E7490',radius:99,pad:'6px 20px'}),
  E('phone',NM.phone,250,559,{text:PH,size:15,weight:800,color:'#0B2A4A'})])}}),
editorial:Object.assign(base(),{label:'تحريري هادئ',desc:'مساحة بيضاء واسعة وخطوط رفيعة وتسلسل واضح بحرف أنيق',dots:['#F5F2EA','#111','#FBBF24'],
 fx(){const y=new Date().getFullYear()+1;return bl(0,0,500,625,'#F5F2EA')+
  `<div style="position:absolute;left:0;right:0;top:92px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:150px;line-height:1;color:#111;opacity:.055">${y}</div>`+bl(40,84,420,2,'#111')+bl(40,512,420,1,'#111')+bl(40,40,12,12,pal.acc)+bl(224,300,52,3,pal.acc)+bl(70,440,360,46,'','border:1.5px solid #111;border-radius:4px')},
 els(){return mkEls([E('season',NM.season,380,46,{text:TXT,size:12,color:'#111',weight:800}),
  E('kicker',NM.kicker,250,148,{text:'احجز مكانك الآن في',size:14,weight:700,color:'#6B6455'}),
  E('title',NM.title,250,232,{text:'العنوان',font:'El Messiri',size:58,weight:800,color:'#111',accw:'#B45309',mw:410}),
  E('teacher',NM.teacher,250,340,{text:'الأستاذ أحمد علي',font:'Amiri',size:30,color:'#111'}),
  E('stage',NM.stage,250,380,{text:'المرحلة',size:14,color:'#6B6455'}),
  E('chips',NM.chips,250,418,{text:CH,size:12.5,weight:700,color:'#6B6455',mw:400}),
  E('sched',NM.sched,250,464,{text:SCH,size:15,weight:800,color:'#111'}),
  E('phone',NM.phone,250,558,{text:PH,size:15,weight:800,color:'#fff',bg:'#111',radius:4,pad:'7px 22px'})])}})
});
const _a=applyAdCopy;applyAdCopy=function(){_a.apply(this,arguments);try{if(TPLS[curTpl]&&TPLS[curTpl].flat&&ELS.chips)ELS.chips.r=0}catch(e){}};
try{if(typeof renderAdGrid==='function')renderAdGrid()}catch(e){}
})();
