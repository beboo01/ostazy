/* قوالب إعلان ٢٠٢٧ بتخطيطات مختلفة (أصلية): شريط جانبي، شارة دائرية، أشرطة أفقية. بدون بنفسجي أو وردي. */
(function(){'use strict';
if(typeof TPLS==='undefined'||typeof mkEls==='undefined')return;
const R=(x,y,w,h,bg,r,ex)=>bl(x,y,w,h,bg,`border-radius:${r}px;`+(ex||''));
const L=(x,y,w,t,c,sz,ex)=>`<div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;text-align:center;font-family:Tajawal,Cairo,sans-serif;font-weight:800;font-size:${sz||10}px;color:${c};${ex||''}">${t}</div>`;
const E=(id,nm,x,y,o)=>[id,nm,x,y,o];
const base=()=>({hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',flat:true});
Object.assign(TPLS,{
split27:Object.assign(base(),{label:'جانبي نظيف',desc:'عمود غامق للمادة والمرحلة وجسم أبيض للتفاصيل',dots:['#0B1F44','#00B8E6','#FFFFFF'],
 fx(){const s=adSubjName();return bl(0,0,500,625,'#FFFFFF')+R(0,0,150,625,'#0B1F44',0)+R(150,0,6,625,'#00B8E6',0)+R(20,40,110,110,'#00B8E6',55)+
  `<div style="position:absolute;left:0;width:150px;top:70px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:44px;color:#0B1F44"><svg width="54" height="54" viewBox="0 0 24 24" style="margin-top:-10px"><path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z" fill="#0B1F44"/></svg></div>`+
  `<div style="position:absolute;left:10px;width:130px;top:180px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${Math.min(26,Math.floor(300/Math.max(4,s.length)))}px;color:#fff;line-height:1.2">${s}</div>`+R(60,560,30,4,'#F5B301',2)},
 els(){return mkEls([E('season',NM.season,75,596,{text:TXT,size:10.5,color:'#BFD3E6',mw:120,weight:800}),
  E('kicker',NM.kicker,328,70,{text:'احجز مكانك الآن في',size:14,weight:800,color:'#0B7FA6',mw:300}),
  E('title',NM.title,328,150,{text:'العنوان',font:'Changa',size:44,weight:800,color:'#0B1F44',accw:'#0B7FA6',mw:300}),
  E('teacher',NM.teacher,328,250,{text:'الأستاذ أحمد علي',font:'El Messiri',size:26,color:'#0B1F44',mw:300}),
  E('stage',NM.stage,328,292,{text:'المرحلة',size:14,weight:800,color:'#64748B',mw:300}),
  E('chips',NM.chips,328,360,{text:CH,size:12.5,weight:700,color:'#334155',mw:290}),
  E('sched',NM.sched,328,460,{text:SCH,size:15,weight:800,color:'#0B1F44',mw:300}),
  E('phone',NM.phone,328,548,{text:PH,size:16,weight:800,color:'#0B1F44',bg:'#F5B301',radius:20,pad:'8px 24px'})])}}),
badge27:Object.assign(base(),{label:'شارة دائرية',desc:'دائرة كبيرة للعنوان وبطاقة تفاصيل سفلية',dots:['#064E3B','#D4A72C','#EAF6EE'],
 fx(){const s=adSubjName();return bl(0,0,500,625,'#EAF6EE')+R(60,28,380,380,'#064E3B',190)+R(78,46,344,344,'transparent',172,'border:2px solid #D4A72C;opacity:.7')+R(24,372,452,170,'#FFFFFF',28,'box-shadow:0 2px 0 rgba(6,78,59,.12)')+R(24,558,452,48,'#064E3B',24)+
  R(190,336,120,30,'#D4A72C',15)+`<div style="position:absolute;left:190px;width:120px;top:341px;text-align:center;font-family:Tajawal,sans-serif;font-weight:800;font-size:${Math.min(15,Math.floor(150/Math.max(4,s.length))+6)}px;color:#064E3B">${s}</div>`},
 els(){return mkEls([E('season',NM.season,385,583,{text:TXT,size:10,color:'#D4A72C',mw:170,weight:800}),
  E('kicker',NM.kicker,250,108,{text:'احجز مكانك الآن في',size:14,weight:800,color:'#D4A72C',mw:300}),
  E('title',NM.title,250,176,{text:'العنوان',font:'Changa',size:44,weight:800,color:'#fff',mw:290}),
  E('teacher',NM.teacher,250,286,{text:'الأستاذ أحمد علي',font:'El Messiri',size:24,color:'#fff',mw:290}),
  E('stage',NM.stage,250,420,{text:'المرحلة',size:14,weight:800,color:'#64748B',mw:400}),
  E('chips',NM.chips,250,462,{text:CH,size:12.5,weight:700,color:'#334155',mw:400}),
  E('sched',NM.sched,250,508,{text:SCH,size:15,weight:800,color:'#064E3B',mw:420}),
  E('phone',NM.phone,150,583,{text:PH,size:15,weight:800,color:'#fff',mw:220})])}}),
stripe27:Object.assign(base(),{label:'أشرطة برتقالية',desc:'أشرطة أفقية متدرجة الأهمية بألوان دافئة',dots:['#7C2D12','#FF8A1F','#FFF1E3'],
 fx(){const s=adSubjName();return bl(0,0,500,625,'#FFF1E3')+R(0,0,500,210,'#7C2D12',0)+R(0,210,500,10,'#FF8A1F',0)+R(40,250,420,60,'#FFFFFF',30)+R(40,540,420,56,'#7C2D12',28)+R(40,330,420,3,'#FF8A1F',2)+
  `<div style="position:absolute;left:40px;width:420px;top:262px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${Math.min(28,Math.floor(560/Math.max(4,s.length)))}px;color:#7C2D12;line-height:1.2">${s}</div>`},
 els(){return mkEls([E('season',NM.season,385,568,{text:TXT,size:10,color:'#FFD7B0',mw:170,weight:800}),
  E('kicker',NM.kicker,250,50,{text:'احجز مكانك الآن في',size:14,weight:800,color:'#FFB866',mw:380}),
  E('title',NM.title,250,122,{text:'العنوان',font:'Changa',size:52,weight:800,color:'#fff',mw:420}),
  E('teacher',NM.teacher,250,372,{text:'الأستاذ أحمد علي',font:'El Messiri',size:28,color:'#7C2D12',mw:400}),
  E('stage',NM.stage,250,412,{text:'المرحلة',size:14,weight:800,color:'#9A5B3A',mw:400}),
  E('chips',NM.chips,250,452,{text:CH,size:12.5,weight:700,color:'#7C2D12',mw:400}),
  E('sched',NM.sched,250,500,{text:SCH,size:15,weight:800,color:'#7C2D12',mw:420}),
  E('phone',NM.phone,150,568,{text:PH,size:15,weight:800,color:'#fff',mw:220})])}})
});
try{if(typeof renderAdGrid==='function')renderAdGrid()}catch(e){}
})();
