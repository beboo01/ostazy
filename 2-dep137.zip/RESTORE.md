# Ostazy full backup (DEP105)
Static site, no build step, no npm dependencies.
Run locally: `python3 -m http.server 8080` in this folder, open http://localhost:8080/
Deploy: Cloudflare Pages project "ostazy" > Create deployment > upload this folder (or zip). Live: https://ostazy.pages.dev
Backend: Supabase project dgktjcjvhhhtcucqsrji (URL and publishable anon key are in app.js; they are public by design). Tables/RPCs: subscriptions, ostazy_admin_list_customers, admin_set_paid_until. Auth via email + Brevo SMTP. Secrets (passwords, service keys, SMTP keys) are NOT in this backup; they live in the user's vault.
External (online) assets: Google Fonts link in studio.html; offline falls back to Cairo. Local font: fonts/bahaa-naskh.woff (Droid Arabic Naskh, Apache 2.0). Photos: img/ph-*.jpg (Pixabay, see img/ATTRIBUTION.md).
Tests used offline puppeteer-core + google-chrome (pages + fake supabase stub); not included in this backup.
Rollback history: GitHub beboo01/ostazy per-DEP zips.
