# Pixabay photo attributions (Ostazy, 2026-11-24)

All photos from Pixabay (https://pixabay.com), free for commercial use under the Pixabay Content License, no attribution required (credits below as courtesy). Downloaded at 1280px, no people/faces, files stored locally (no hotlinking).

| File | Photographer | Pixabay page |
| --- | --- | --- |
| books-library-1-1659717.jpg | garten-gg | https://pixabay.com/photos/christmas-background-book-read-old-1659717/ |
| books-library-2-7720589.jpg | mirkostoedter | https://pixabay.com/photos/library-wisdom-reading-knowledge-7720589/ |
| science-lab-217041.jpg | PublicDomainPictures | https://pixabay.com/photos/laboratory-apparatus-equipment-217041/ |
| microscope-5732847.jpg | __Penelope_ | https://pixabay.com/photos/microscope-laboratory-research-lab-5732847/ |
| blackboard-chalk-1-1072366.jpg | stux | https://pixabay.com/photos/black-board-traces-of-chalk-school-1072366/ |
| blackboard-empty-916678.jpg | geralt | https://pixabay.com/photos/school-board-empty-slate-916678/ |
| notebook-pencils-desk-1891732.jpg | congerdesign | https://pixabay.com/photos/pencil-notebook-crumpled-paper-1891732/ |
| globe-7510104.jpg | lucasgeorgewendt | https://pixabay.com/photos/globe-map-world-map-7510104/ |
| colored-pencils-1-9485478.jpg | padrinan | https://pixabay.com/photos/art-school-education-creative-9485478/ |
| colored-pencils-2-8127500.jpg | Margaret8 | https://pixabay.com/photos/color-pencils-crayons-colorful-8127500/ |
| letters-numbers-1671489.jpg | deFerrer | https://pixabay.com/photos/letters-numbers-toys-magnetic-1671489/ |
| empty-classroom-2093744.jpg | WOKANDAPIX | https://pixabay.com/photos/classroom-school-education-learning-2093744/ |

## Fonts
- fonts/bahaa-naskh.woff: "Droid Arabic Naskh" (Google, Apache License 2.0), supplied by Bahaa, subset to Arabic and Latin.
