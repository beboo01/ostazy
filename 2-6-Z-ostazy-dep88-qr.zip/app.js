const DAYS=["السبت","الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة"];
const STAGES=["ابتدائي","إعدادي","ثانوية عامة","جامعي"];
const TABS=[["h","الرئيسية"],["g","المجموعات"],["s","الطلاب"],["a","الحضور"],["w","الواجب"],["p","المصاريف"],["e","الدرجات"],["r","التقارير"],["b","النسخ الاحتياطي"],["t","الإعدادات"]];
const TL=Object.fromEntries(TABS),BMAIN=["h","a","p","s"],BMORE=["g","w","e","r","b","t"];
const ADMIN_UID="1196d2ad-0eb9-4c81-a3e0-657c13d05a67",ATAB=["m","الإدارة"];
const ICG=(p,s)=>`<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
const TICON={h:ICG('<path d="M3 10.5L12 3l9 7.5"/><path d="M5 9.5V21h5v-6h4v6h5V9.5"/>'),g:ICG('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 5a3 3 0 0 1 0 6"/><path d="M17.5 14.4c2.4.7 4 2.7 4 5.6"/>'),s:ICG('<path d="M12 4L2 9l10 5 10-5-10-5z"/><path d="M6 11.2V15c0 1.7 2.7 3 6 3s6-1.3 6-3v-3.8"/>'),a:ICG('<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9.5"/>'),p:ICG('<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/>'),e:ICG('<path d="M4 20V10M10 20V4M16 20v-7"/><path d="M2.5 20h19"/>'),t:ICG('<circle cx="12" cy="12" r="3.2"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 2 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/>'),r:ICG('<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>'),b:ICG('<path d="M12 3v11"/><path d="M7 10l5 5 5-5"/><path d="M4 19h16"/>')};
TICON.w=ICG('<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4.5 6l1 1 2-2"/><path d="M4.5 12l1 1 2-2"/><path d="M4.5 18l1 1 2-2"/>');
TICON.studio=ICG('<path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4z"/><path d="M18.5 14.5l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z"/><path d="M5 15.5l.7 1.8 1.8.7-1.8.7L5 20.5l-.7-1.8-1.8-.7 1.8-.7z"/>');
const IC_ADM=ICG('<path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M9.5 12l2 2 3.5-4"/>');
const IC_MORE=ICG('<circle cx="5" cy="12" r="1.7" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.7" fill="currentColor" stroke="none"/>');
const DEMO=["أحمد","مريم","يوسف","سلمى"];
const TPL_DEF={
feesM:"السلام عليكم ورحمة الله،\nمصاريف {الطالب} في {المادة} عن شهر {الشهر}: {المبلغ} جنيه.\nولو الدفع تم بالفعل، شكرًا لحضرتك وتجاهل الرسالة.",
feesL:"السلام عليكم ورحمة الله،\nمصاريف {الطالب} في {المادة} متأخرة منذ {عدد_الشهور} شهر. ياريت التسوية في أقرب وقت، وشكرًا لتعاونكم.",
absD:"السلام عليكم، نحب نطمّن على {الطالب}؛ غاب النهارده عن حصة {المادة} ({التاريخ}). نتمنى يكون بخير.",
absM:"السلام عليكم، لاحظنا إن {الطالب} غاب {عدد_الغياب} مرة الشهر ده في {المادة}، فحبينا نطمّن. نتمنى يكون بخير.",
sched:"السلام عليكم، تنبيه مهم: اتغيّر ميعاد {المادة} لمجموعة {المجموعة}.\nالميعاد الجديد: {الميعاد}",
exam:"السلام عليكم، نتيجة {الطالب} في {الامتحان}: {الدرجة} من {المنتهى}. ربنا يوفقه.",
report:"السلام عليكم ورحمة الله،\nتقرير {الطالب} في {المادة} عن شهر {الشهر}:\n• الحضور: {الحضور} حصة (غياب {الغياب})\n• الدرجات: {الدرجات}\n• المصاريف: {حالة_المصاريف}\nربنا يوفقه.",
arrD:"السلام عليكم، نطمّن حضرتك إن {الطالب} وصل حصة {المادة} النهارده ({التاريخ}) الساعة {الوقت}. ربنا يوفقه.",
hwR:"السلام عليكم، نحب نفتكر إن واجب {المادة} المطلوب من {الطالب} لحصة ({التاريخ}) لسه ما اتسلّمش: {الواجب}. نتمنى المتابعة، وشكرًا لكم."};
const TPL_META={
feesM:{label:"تذكير مصاريف الشهر",tokens:["الطالب","المادة","الشهر","المبلغ"]},
feesL:{label:"تذكير المتأخرات",tokens:["الطالب","المادة","عدد_الشهور"]},
absD:{label:"غياب عن حصة",tokens:["الطالب","المادة","التاريخ"]},
absM:{label:"غياب متكرر في الشهر",tokens:["الطالب","المادة","عدد_الغياب"]},
sched:{label:"تغيير ميعاد مجموعة",tokens:["المادة","المجموعة","الميعاد"]},
exam:{label:"درجة امتحان",tokens:["الطالب","الامتحان","الدرجة","المنتهى"]},
report:{label:"التقرير الشهري",tokens:["الطالب","المادة","الشهر","الحضور","الغياب","الدرجات","حالة_المصاريف"]},
arrD:{label:"وصول الطالب للحصة",tokens:["الطالب","المادة","التاريخ","الوقت"]},
hwR:{label:"تذكير بالواجب",tokens:["الطالب","المادة","التاريخ","الواجب"]}};
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const C=OstazyCore;
const rid=()=>crypto.randomUUID();
const today=()=>C.localDate();
const fmt=t=>{const[h,m]=t.split(":").map(Number);return(h%12||12)+(m?":"+String(m).padStart(2,"0"):"")+(h>=12?" م":" ص")};
const mname=m=>new Date(m+"-01").toLocaleDateString("ar-EG-u-nu-latn",{month:"long",year:"numeric"});
const num=v=>Number(String(v).replace(/[٠-٩]/g,d=>"٠١٢٣٤٥٦٧٨٩".indexOf(d)))||0;
const phone=p=>{let d=String(p||"").replace(/\D/g,"");if(d.startsWith("00"))d=d.slice(2);else if(d.startsWith("0"))d="20"+d.slice(1);return d};
const wa=(p,m)=>"https://wa.me/"+phone(p)+"?text="+encodeURIComponent(m);
const A=(p,m,t)=>'<a class="wa" target="_blank" rel="noopener" href="'+wa(p,m)+'">'+t+'</a>';
const tplCustom=k=>S&&S.tpl&&typeof S.tpl[k]==="string"&&S.tpl[k].trim()?S.tpl[k]:null;
const tplMsg=(k,ctx)=>{let t=tplCustom(k)||TPL_DEF[k]||"";t=String(t).slice(0,2000);for(const key in ctx)t=t.split("{"+key+"}").join(ctx[key]==null?"":String(ctx[key]));return t};
const tplCheck=(k,v)=>{if(!v.trim())return"القالب فارغ — اكتب نص الرسالة أو استرجع الافتراضي.";if(v.length>1000)return"القالب أطول من ١٠٠٠ حرف.";const bad=[...v.matchAll(/\{([^{}]*)\}/g)].map(x=>x[1]).filter(x=>!TPL_META[k].tokens.includes(x));return bad.length?"رموز غير معروفة: "+bad.join("، ")+". الرموز المتاحة لهذا القالب: "+TPL_META[k].tokens.map(x=>"{"+x+"}").join(" "):""};
const tplSample=k=>{const m=today().slice(0,7);return{
feesM:{الطالب:"أحمد",المادة:S.subject,الشهر:mname(m),المبلغ:S.price},
feesL:{الطالب:"أحمد",المادة:S.subject,عدد_الشهور:"٢"},
absD:{الطالب:"أحمد",المادة:S.subject,التاريخ:today()},
absM:{الطالب:"أحمد",المادة:S.subject,عدد_الغياب:"٢"},
sched:{المادة:S.subject,المجموعة:"مجموعة السبت والاثنين",الميعاد:"السبت + الاثنين 5 م – 7 م"},
exam:{الطالب:"أحمد",الامتحان:"امتحان الباب الأول",الدرجة:"18",المنتهى:"20"},
report:{الطالب:"أحمد",المادة:S.subject,الشهر:mname(m),الحضور:"7",الغياب:"1",الدرجات:"85%",حالة_المصاريف:"مدفوعة"},
arrD:{الطالب:"أحمد",المادة:S.subject,التاريخ:today(),الوقت:fmt("17:05")},
hwR:{الطالب:"أحمد",المادة:S.subject,التاريخ:today(),الواجب:"حل تدريبات الدرس الثالث ص ٤٥"}}[k]};
function tplPreview(k){const ta=$("tpl_"+k),pv=$("pv_"+k);if(!ta||!pv)return;let t=ta.value.slice(0,2000);const ctx=tplSample(k);for(const key in ctx)t=t.split("{"+key+"}").join(String(ctx[key]));pv.textContent=t}
const gsched=g=>"مجموعة "+(g.days||[g.d||0]).slice().sort((a,b)=>a-b).map(d=>DAYS[d]).join(" + ")+" "+fmt(g.t)+(g.e?" – "+fmt(g.e):"");
const gname=g=>g.label||gsched(g);
const norm=s=>String(s||"").replace(/[\u064B-\u0652\u0670]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه").replace(/\s+/g," ").trim().toLowerCase();
const W={step:0,subject:"رياضيات",stage:"ثانوية عامة",n:2,slots:[{days:[0,3],t:"17:00",e:"19:00"},{days:[1,4],t:"19:00",e:"21:00"},{days:[2,5],t:"16:00",e:"18:00"},{days:[0,3],t:"19:00",e:"21:00"}],price:300,demo:false};
let S=null,store=null,tab="h",gi=0,adate=today(),pmonth=today().slice(0,7),rmonth=today().slice(0,7),pt;
let hwDraftContext=null;
let moreOpen=new URLSearchParams(location.search).get("more")==="1";
const routedTab=new URLSearchParams(location.search).get("view");if(TABS.some(([key])=>key===routedTab))tab=routedTab;
let ADMIN_ROWS=null,ADMIN_ERROR="";

const SB_URL="https://dgktjcjvhhhtcucqsrji.supabase.co",SB_KEY="sb_publishable_wFdMsflUtKeSeby-_m4snw_KNEI7her";
if(!window.supabase){document.getElementById("sync").textContent="تعذّر تحميل خدمة الدخول. افحص الاتصال ثم أعد تحميل الصفحة.";throw new Error("Supabase SDK unavailable")}
const sb=window.supabase.createClient(SB_URL,SB_KEY);let uid=null,SUB=null,EMAIL="";
const ADMIN_WA="201016229014",PAY_NUM="01016229014",NEW_SUBSCRIPTION_PRICE=200;
const amsg=t=>{$("amsg").textContent=t};
let remoteVersion=null,hasRemoteRow=false,dirty=false,saving=false,savePromise=null,editRevision=0,saveBlocked=false,loadFailed=false;
let accountEpoch57=0,sessionLoad57=null,sessionLoadOwner57=null,lastRecoveryOwner57=null;
const sessionRecoveries57=new Map();
function stashSessionWork57(){if(uid&&S&&(dirty||saving))sessionRecoveries57.set(uid,{state:JSON.parse(JSON.stringify(S)),base:remoteVersion});}
function clearAccountDisplay57(){
  $("app").classList.add("hide");$("wiz").classList.add("hide");$("view").innerHTML="";$("bill").innerHTML="";
  $("syncTools").classList.add("hide");$("sessionRecovery").classList.add("hide");if(window.OstazyAccount46?.clear)window.OstazyAccount46.clear();ADMIN_ROWS=null;ADMIN_ERROR="";sid=null;gi=0;hwDraftContext=null;
}
function recoveryView57(){const r=uid&&sessionRecoveries57.get(uid);$("sessionRecovery").classList.toggle("hide",!r);if(!r)return;
 $("recoveryApply").disabled=!active()||saving||dirty||r.base!==remoteVersion;
 $("recoveryText").textContent=r.base===remoteVersion?"فيه تعديلات ما اتأكدش حفظها قبل انتهاء الجلسة. نزّل نسخة منها، أو استعدها على نفس الحساب.":"فيه تعديلات قديمة ما اتأكدش حفظها، لكن النسخة المحفوظة اتغيّرت بعدها. نزّل التعديلات للمراجعة؛ مش هنكتبها فوق النسخة الأحدث تلقائيًا.";
}
function endSession57(){
 stashSessionWork57();lastRecoveryOwner57=uid||lastRecoveryOwner57;accountEpoch57++;clearTimeout(pt);clearAccountDisplay57();
 const hasWork=!!(lastRecoveryOwner57&&sessionRecoveries57.has(lastRecoveryOwner57));
 uid=null;EMAIL="";SUB=null;loadFailed=true;saveBlocked=true;dirty=hasWork;
 if(!hasWork)S=null;
 $("retrySave").disabled=true;$("reloadData").disabled=true;
 if(hasWork)$("syncTools").classList.remove("hide");
 $("auth").classList.remove("hide");status(hasWork?"انتهت جلسة الدخول. تغييراتك لسه في الصفحة. نزّل نسخة احتياطية قبل إغلاقها، أو ادخل بنفس الحساب لمراجعتها.":"انتهت جلسة الدخول. ادخل تاني للمتابعة.");
}
async function startSession57(session){
 const owner=session?.user?.id;if(!owner)return;
 if(sessionLoad57&&sessionLoadOwner57===owner)return sessionLoad57;
 if(uid===owner&&S&&!loadFailed){EMAIL=session.user.email||EMAIL;return;}
 stashSessionWork57();accountEpoch57++;clearTimeout(pt);clearAccountDisplay57();S=null;SUB=null;dirty=false;saveBlocked=false;loadFailed=false;
 uid=owner;EMAIL=session.user.email||"";$("retrySave").disabled=false;$("reloadData").disabled=false;sessionLoadOwner57=owner;
 const epoch=accountEpoch57;sessionLoad57=load();try{await sessionLoad57;if(uid===owner&&epoch===accountEpoch57)recoveryView57();}finally{if(sessionLoadOwner57===owner){sessionLoad57=null;sessionLoadOwner57=null;}}
}
$("recoveryDownload").onclick=()=>{const r=uid&&sessionRecoveries57.get(uid);if(!r)return;const u=URL.createObjectURL(new Blob([JSON.stringify(r.state,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=u;a.download="ostazy-unsaved-"+today()+".json";a.click();setTimeout(()=>URL.revokeObjectURL(u),2000);};
$("recoveryApply").onclick=()=>{const r=uid&&sessionRecoveries57.get(uid);if(!r)return;if(!active()||saving||dirty||r.base!==remoteVersion){recoveryView57();return;}S=JSON.parse(JSON.stringify(r.state));sessionRecoveries57.delete(uid);persist();render();recoveryView57();};
$("recoveryDiscard").onclick=()=>{if(!uid||!sessionRecoveries57.has(uid))return;if(!confirm("تجاهل التعديلات غير المحفوظة والمتابعة بالنسخة الموجودة على الحساب؟ نزّل نسخة منها أولًا لو محتاجها."))return;sessionRecoveries57.delete(uid);recoveryView57();};

const status=t=>{$("sync").textContent=t};
function downloadBackup(){if(!S)return;const u=URL.createObjectURL(new Blob([JSON.stringify(S,null,2)],{type:"application/json"})),link=document.createElement("a");link.href=u;link.download="ostazy-backup-"+today()+".json";link.click();setTimeout(()=>URL.revokeObjectURL(u),2000)}
async function init(){
  try{const{data}=await sb.auth.getSession();if(data.session){await startSession57(data.session);return}}catch(e){}
  $("auth").classList.remove("hide");
}
async function load(){
  const owner57=uid,epoch57=accountEpoch57;const current57=()=>uid===owner57&&accountEpoch57===epoch57;
  $("auth").classList.add("hide");$("wiz").classList.add("hide");$("app").classList.add("hide");$("syncTools").classList.add("hide");
  status("جاري تحميل بياناتك...");loadFailed=false;saveBlocked=false;SUB=null;
  try{
    const {data,error}=await sb.from("teacher_state").select("state,updated_at").eq("user_id",uid).maybeSingle();
    if(!current57())return;if(error)throw error;
    hasRemoteRow=!!data;remoteVersion=data?.updated_at??null;
    S=data?.state||null;
    if(S)C.validateState(S);
    // Never copy unscoped legacy localStorage into a signed-in account automatically.
  }catch(e){if(!current57())return;loadFailed=true;$("syncTools").classList.remove("hide");status("تعذّر تحميل بياناتك. أعد المحاولة؛ الحفظ متوقف لحماية البيانات الموجودة.");return}
  dirty=false;editRevision=0;
  try{
    const {data,error}=await sb.from("subscriptions").select("trial_ends,paid_until").eq("user_id",uid).maybeSingle();
    if(!current57())return;if(error)throw error;
    SUB=data||null;
    status(SUB?"تم تحميل بياناتك.":"لم نتمكن من التحقق من اشتراكك. التعديل متوقف، تواصل مع الدعم.");
  }catch(e){if(!current57())return;status("تعذّر التحقق من الاشتراك. بياناتك متاحة للقراءة والنسخ الاحتياطي فقط.")}
  if(window.OstazyAccount46)await window.OstazyAccount46.load(sb);if(!current57())return;
  $("stor").textContent="الحفظ على حسابك. لا تغلق الصفحة قبل ظهور تأكيد الحفظ.";
  if(S){$("app").classList.remove("hide");render()}else{$("wiz").classList.remove("hide");wizard()}
}
async function save2(){
  clearTimeout(pt);
  if(!uid){if(dirty)status("ادخل بنفس الحساب قبل محاولة الحفظ. نزّل نسخة من التعديلات أولًا لو محتاجها.");return false;}
  if(saving)return savePromise;
  if(!dirty||saveBlocked||loadFailed)return !dirty;
  const saveOwner57=uid,saveEpoch57=accountEpoch57;const sameSave57=()=>uid===saveOwner57&&accountEpoch57===saveEpoch57;
  saving=true;
  savePromise=(async()=>{
    try{
      while(dirty&&!saveBlocked){
        if(!sameSave57())return false;
        const revision=editRevision,snapshot=JSON.parse(JSON.stringify(S));C.validateState(snapshot);
        const stamp=new Date(Math.max(Date.now(),Date.parse(remoteVersion||0)+1||0)).toISOString();
        const row={user_id:uid,state:snapshot,updated_at:stamp};
        let query;
        if(hasRemoteRow){query=sb.from("teacher_state").update(row).eq("user_id",uid);query=remoteVersion===null?query.is("updated_at",null):query.eq("updated_at",remoteVersion)}
        else query=sb.from("teacher_state").insert(row);
        const {data,error}=await query.select("updated_at");
        if(!sameSave57())return false;
        if(error){if(error.code==="23505")saveBlocked=true;throw error}
        if(!data||data.length!==1){saveBlocked=true;throw new Error("تعارض نسخة أو رفض صلاحية الحفظ")}
        hasRemoteRow=true;remoteVersion=data[0].updated_at??stamp;
        dirty=editRevision!==revision;
      }
      $("syncTools").classList.add("hide");status("تم حفظ كل التغييرات على حسابك.");return true;
    }catch(e){if(!sameSave57())return false;$("syncTools").classList.remove("hide");status((saveBlocked?"توقف الحفظ لحماية بياناتك من الكتابة فوق نسخة أحدث. نزّل نسختك أولًا ثم أعد التحميل. ":"لم يتم الحفظ. تغييراتك موجودة في الصفحة فقط. جرّب الحفظ أو نزّل نسخة قبل الإغلاق. "));return false}
    finally{saving=false;if(!sameSave57()&&uid&&dirty&&!saveBlocked&&!loadFailed)pt=setTimeout(save2,0)}
  })();
  return savePromise;
}
function persist(){dirty=true;editRevision++;status("تغييرات لم تُحفظ بعد...");clearTimeout(pt);pt=setTimeout(save2,500)}
$("retrySave").onclick=()=>save2();
$("reloadData").onclick=()=>{if(dirty&&!confirm("يوجد تعديل غير محفوظ. نزّل نسخة احتياطية أولًا. هل تريد تجاهله وتحميل النسخة المحفوظة؟"))return;clearTimeout(pt);if(saving){status("انتظر اكتمال محاولة الحفظ أولًا.");return}load()};
$("downloadAll").onclick=downloadBackup;
async function restoreFile(input){
 const file=input.files[0];input.value="";if(!file)return;
 const rn=$("restoreName");if(rn)rn.textContent=file.name;
 if(!active()){flash();return}
 try{if(file.size>5*1024*1024)throw new Error("حجم النسخة أكبر من 5 ميجابايت");const restored=C.parseBackup(await file.text());
 if(!confirm("الاستعادة ستستبدل بيانات الحساب الحالية بعد الحفظ. سيتم تنزيل نسخة من البيانات الحالية أولًا. هل أنت متأكد؟"))return;
 downloadBackup();S=restored;gi=0;sid=null;tab="h";persist();$("wiz").classList.add("hide");$("app").classList.remove("hide");render();
 }catch(error){status("تعذّر استعادة الملف. تأكد أنه نسخة احتياطية من أستاذي، واحتفظ بنسخة من بياناتك قبل المحاولة مرة أخرى.")}
}
window.addEventListener("beforeunload",event=>{if(dirty||saving||sessionRecoveries57.size){event.preventDefault();event.returnValue=""}});
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden"&&dirty&&!saving)save2()});
let authBusy=false,lastSignupAttempt=0;
async function authGo(up){
  if(authBusy)return;
  const email=$("aem").value.trim(),password=$("apw").value;
  if(!email||!$("aem").checkValidity()||password.length<6){amsg("اكتب إيميل صحيح وباسورد 6 حروف على الأقل.");return}
  if(up&&Date.now()-lastSignupAttempt<60000){amsg("استنى دقيقة قبل طلب تسجيل تاني، وراجع إيميلك لو طلبت حساب بالفعل.");return}
  authBusy=true;for(const id of ["li","su"])if($(id))$(id).disabled=true;
  if(up)lastSignupAttempt=Date.now();
  amsg(up?"جاري طلب حساب التجربة...":"جاري تسجيل الدخول...");
  try{
    const r=up?await sb.auth.signUp({email,password,options:{emailRedirectTo:"https://ostazy.pages.dev/"}}):await sb.auth.signInWithPassword({email,password});
    if(r.error){
      const limited=r.error.status===429||/rate_limit/.test(r.error.code||"");
      amsg(limited?"طلبات كتير دلوقتي. استنى شوية وراجع إيميلك قبل ما تطلب تاني.":up?"ما قدرناش نأكد اكتمال التسجيل. راجع إيميلك لرسالة التفعيل؛ لو عندك حساب بالفعل استخدم دخول، أو اطلب المساعدة على واتساب.":"الدخول ما اكتملش. راجع الإيميل والباسورد واتصالك، أو اطلب المساعدة على واتساب.");return;
    }
    if(up&&!r.data.session){amsg("راجع صندوق الوارد والرسائل غير المرغوب فيها لتأكيد الإيميل. لو الإيميل مسجل بالفعل، استخدم دخول. التجربة 14 يوم من إنشاء الحساب، من غير دفع أو تجديد تلقائي.");return}
    if(!r.data.session){amsg("تسجيل الدخول ما اكتملش. حاول تاني، أو تواصل مع الدعم لو المشكلة مستمرة.");return}
    await startSession57(r.data.session);
  }catch(e){amsg(up?"الاتصال اتقطع قبل ما نقدر نتأكد. راجع إيميلك لرسالة التفعيل قبل أي طلب جديد؛ مفيش إعادة إرسال تلقائية.":"تعذّر الاتصال. حاول الدخول تاني لما الشبكة تستقر.")}
  finally{authBusy=false;for(const id of ["li","su"])if($(id))$(id).disabled=false}
}
$("li").onclick=()=>authGo(false);if($("su"))$("su").onclick=()=>authGo(true);
$("out").onclick=async()=>{if(dirty&&!(await save2()))return;const {error}=await sb.auth.signOut();if(error){status("تعذّر تسجيل الخروج. حاول مرة أخرى.");return}location.reload()};

const active=()=>!loadFailed&&!saveBlocked&&C.isActive(SUB);
function newOfferHtml(){return '<p><b>الاشتراك: '+NEW_SUBSCRIPTION_PRICE+' جنيه شهريًا.</b></p><p>يشمل استوديو التصميمات، المتاح حاليًا بنسخة تجريبية. بدون خصم أو تجديد تلقائي.</p>'}
function waSub(){if(!ADMIN_WA)return'<span class="tag bad">تواصل مع الدعم لتفاصيل الدفع</span>';return A(ADMIN_WA,"السلام عليكم، عايز تفاصيل اشتراكي في أستاذي. إيميل الحساب: "+EMAIL+". برجاء تأكيد قيمة الاشتراك وخطوات الدفع.","تفاصيل الاشتراك على واتساب")}
if($("newOffer"))$("newOffer").innerHTML=newOfferHtml();
if($("trialRequest"))$("trialRequest").innerHTML="<a class=\"wa\" target=\"_blank\" rel=\"noopener\" href=\"https://wa.me/201016229014?text=%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85+%D8%B9%D9%84%D9%8A%D9%83%D9%85%D8%8C+%D9%85%D8%AD%D8%AA%D8%A7%D8%AC+%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9+%D9%81%D9%8A+%D8%AA%D8%B3%D8%AC%D9%8A%D9%84+%D8%AD%D8%B3%D8%A7%D8%A8+%D9%88%D8%A8%D8%AF%D8%A1+%D8%AA%D8%AC%D8%B1%D8%A8%D8%A9+%D8%A3%D8%B3%D8%AA%D8%A7%D8%B0%D9%8A+14+%D9%8A%D9%88%D9%85.\">مساعدة في التسجيل على واتساب</a>";
function billHtml(){
  if(!SUB)return '<div class="card"><p>الاشتراك غير مؤكد. القراءة والنسخ الاحتياطي متاحان، والتعديل متوقف.</p>'+newOfferHtml()+waSub()+'</div>';
  const n=Date.now(),te=new Date(SUB.trial_ends).getTime(),pu=SUB.paid_until?new Date(SUB.paid_until).getTime():0,df=t=>Math.max(0,Math.ceil((t-n)/864e5)),l=waSub();
  if(pu>n)return'<div class="card"><span class="tag ok">اشتراكك ساري</span> لحد '+new Date(pu).toLocaleDateString("ar-EG-u-nu-latn")+(df(pu)<=5?' (باقي '+df(pu)+' أيام) '+l+payBox():'')+'</div>';
  if(te>n)return'<div class="card"><span class="tag warn">تجربة مجانية</span> باقي '+df(te)+' يوم. مفيش دفع أو تجديد تلقائي. <details class="customer-payment-details"><summary>تفاصيل الاشتراك بعد التجربة</summary>'+l+payBox()+'</details></div>';
  return'<div class="card" style="border-color:var(--bad)"><h2>انتهت فترة الاستخدام</h2><p>بياناتك محفوظة وتقدر تشوفها وتنزّل نسخة احتياطية. التعديل متوقف لحد تفعيل الاشتراك، والقرار ليك من غير أي خصم تلقائي.</p>'+l+payBox()+'</div>'}
const IC_BOLT='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>',IC_WAL='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/></svg>';
function payBox(){return'<div class="pay"><b>الدفع وتفعيل الاشتراك</b>'+newOfferHtml()+'<p>تأكد من قيمة الاشتراك وخطوات الدفع على واتساب قبل التحويل.</p><div class="btns" style="margin:6px 0"><span class="pm">'+IC_BOLT+' إنستا باي</span><span class="pm">'+IC_WAL+' فودافون كاش</span></div><div>رقم التحويل بعد تأكيد المبلغ: <b dir="ltr">'+PAY_NUM+'</b> <button class="ghost sm" type="button" data-copy="'+PAY_NUM+'">نسخ الرقم</button></div><small style="color:var(--mute)">بعد التحويل أرسل الإيصال على واتساب لمراجعة الدفع وتفعيل الاشتراك.</small></div>'}
$("bill").onclick=async e=>{if(window.OstazyAccount46&&await window.OstazyAccount46.handleClick(e,{client:sb,render}))return;const b=e.target.closest("button[data-copy]");if(b&&navigator.clipboard)navigator.clipboard.writeText(b.dataset.copy).then(()=>{b.textContent="تم النسخ"}).catch(()=>{})};
function flash(){status(saveBlocked?"الحفظ متوقف بسبب تعارض. نزّل نسخة ثم أعد تحميل البيانات.":"التعديل متوقف. تأكد من الاشتراك واتصال الحساب أولًا.")}
function dayChips(pre,sel){return'<div class="chips">'+DAYS.map((d,j)=>'<label class="chip"><input type="checkbox" data-day="'+pre+'" value="'+j+'"'+(sel.includes(j)?' checked':'')+'> '+d+'</label>').join("")+'</div>'}
function getDays(pre){return[...document.querySelectorAll('input[data-day="'+pre+'"]:checked')].map(x=>+x.value)}
function wizard(){
  $("back").style.visibility=W.step?"visible":"hidden";
  $("next").textContent=W.step==2?"جهّز مجموعاتي":"التالي";
  const t=$("wt"),b=$("wb");
  if(W.step==0){t.textContent="بتدرّس إيه؟";b.innerHTML='<label for="subj">المادة</label><input id="subj" value="'+esc(W.subject)+'"><label for="stg">المرحلة</label><select id="stg">'+STAGES.map(x=>'<option'+(x==W.stage?' selected':'')+'>'+x+'</option>').join("")+'</select>'}
  else if(W.step==1){t.textContent="عندك كام مجموعة؟";
    while(W.slots.length<W.n)W.slots.push({days:[W.slots.length%7,(W.slots.length+3)%7],t:"17:00",e:"19:00"});
    let h='<label for="cnt">عدد المجموعات</label><select id="cnt">'+Array.from({length:12},(_,k)=>k+1).map(x=>'<option'+(x==W.n?' selected':'')+'>'+x+'</option>').join("")+'</select>';
    for(let i=0;i<W.n;i++)h+='<div class="card" style="margin:10px 0"><b>المجموعة '+(i+1)+' (اختار الأيام)</b>'+dayChips("w"+i,W.slots[i].days)+'<div class="row" style="margin-top:6px"><div>من<input id="h'+i+'" type="time" value="'+W.slots[i].t+'"></div><div>إلى<input id="e'+i+'" type="time" value="'+(W.slots[i].e||"")+'"></div></div></div>';
    b.innerHTML=h;$("cnt").onchange=e=>{wsave();W.n=+e.target.value;wizard()}}
  else{t.textContent="سعر الشهر للطالب";b.innerHTML='<label for="pr">بالجنيه</label><input id="pr" type="number" min="0" step="10" value="'+W.price+'"><label><input type="checkbox" id="demo" style="width:auto"> أضف أسماء توضيحية للتجربة</label>'}
}
function wsave(){
  if(W.step==0){W.subject=$("subj").value.trim()||"المادة";W.stage=$("stg").value}
  else if(W.step==1)for(let i=0;i<W.n;i++){const ds=getDays("w"+i);W.slots[i]={days:ds.length?ds:[0],t:$("h"+i).value||"17:00",e:$("e"+i).value||""}}
  else{W.price=num($("pr").value);W.demo=$("demo").checked}
}
$("next").onclick=()=>{
  if(!active()){flash();return}wsave();if(W.step<2){W.step++;wizard();return}
  const m=today().slice(0,7);
  S={subject:W.subject,stage:W.stage,price:W.price,since:m,groups:W.slots.slice(0,W.n).map((s,i)=>({id:rid(),days:s.days,t:s.t,e:s.e,notify:false,students:W.demo?DEMO.map((n,j)=>({id:rid(),name:n,phone:"2010000000"+i+j,since:m})):[]})),att:{},pay:{},exams:[]};
  gi=0;tab="h";persist();$("wiz").classList.add("hide");$("app").classList.remove("hide");render();
};
$("back").onclick=()=>{wsave();W.step--;wizard()};

const allSt=()=>S.groups.flatMap(g=>g.students.map(s=>({...s,g})));
const paid=(m,id)=>!!(S.pay[m]&&S.pay[m][id]);
const monthsFrom=(a,b)=>{const r=[];let[y,m]=a.split("-").map(Number);const[y2,m2]=b.split("-").map(Number);while(y<y2||(y==y2&&m<=m2)){r.push(y+"-"+String(m).padStart(2,"0"));if(++m>12){m=1;y++}}return r};
const overdue=s=>monthsFrom(s.since||S.since,today().slice(0,7)).slice(0,-1).filter(m=>!paid(m,s.id));
function monthAtt(sid,m){let p=0,x=0;for(const k in S.att){if(k.slice(0,7)!=m)continue;const v=S.att[k][sid];if(v===true||v==="l")p++;else if(v===false)x++}return{p,x}}
function monthExam(sid,m){const r=S.exams.filter(e=>e.date.slice(0,7)==m&&e.scores[sid]!=null&&e.scores[sid]!=="");return r.length?Math.round(r.reduce((a,e)=>a+e.scores[sid]/e.max*100,0)/r.length):null}

let sid=null;
let gq="",sq="",egi=-1,esij=null;
function applyFilters(){const q1=norm(gq);document.querySelectorAll("#view .gcard").forEach(c=>{const visible=!q1||c.dataset.q.includes(q1);c.style.display=visible?"":"none";const d=c.querySelector(".groupManage");if(d&&q1){if(d.dataset.wasOpen===undefined)d.dataset.wasOpen=String(d.open);d.open=visible}else if(d&&d.dataset.wasOpen!==undefined){d.open=d.dataset.wasOpen==="true";delete d.dataset.wasOpen}});const q2=norm(sq),rows=document.querySelectorAll("#view .srow");rows.forEach(r=>{r.style.display=!q2||r.dataset.q.includes(q2)?"":"none"});if(rows.length)document.querySelectorAll("#view .card").forEach(c=>{const rs=[...c.querySelectorAll(".srow")];if(rs.length)c.style.display=q2&&!rs.some(r=>r.style.display!=="none")?"none":""})}
const findSt=id=>C.findStudent(S,id);
const sm=m=>new Date(m+"-01").toLocaleDateString("ar-EG-u-nu-latn",{month:"short"});
const months6=()=>C.recentMonths();
const totals=m=>C.monthlyTotals(S,m);
const income=m=>{const t=totals(m);return t.amount+" جنيه"+(t.legacyCount?" + "+t.legacyCount+" دفعات قديمة بدون مبلغ مسجل":"")};
function bars(vals,labels,suf){const mx=Math.max(1,...vals.map(v=>v||0)),w=60;return'<svg viewBox="0 0 '+(labels.length*w)+' 140" style="width:100%;height:auto" role="img">'+vals.map((v,i)=>{const hh=Math.round((v||0)/mx*85),cx=i*w+30;return'<rect x="'+(cx-18)+'" y="'+(104-hh)+'" width="36" height="'+hh+'" rx="4" fill="var(--acc)"/><text x="'+cx+'" y="'+(98-hh)+'" text-anchor="middle" font-size="12" font-weight="700" fill="var(--ink)">'+(v==null?"—":v+(suf||""))+'</text><text x="'+cx+'" y="124" text-anchor="middle" font-size="11" fill="var(--mute)">'+esc(labels[i])+'</text>'}).join("")+'</svg>'}
function render(){
  hwDraftContext=null;
  $("bill").innerHTML=billHtml()+(window.OstazyAccount46?window.OstazyAccount46.html():"");
  S.groups.forEach(g=>{if(!g.days)g.days=[g.d||0];if(g.e===undefined)g.e=""});
  $("ttl").textContent=S.subject+" · "+S.stage;
  const all=allSt();$("sub").textContent=S.groups.length+" مجموعات، "+all.length+" طالب، "+S.price+" جنيه في الشهر";
  if(tab=="m"&&uid!==ADMIN_UID)tab="h";
  const ticon=k=>k=="m"?IC_ADM:TICON[k],isAdm=uid===ADMIN_UID,tabs=isAdm?TABS.concat([ATAB]):TABS,moreTabs=isAdm?BMORE.concat(["m"]):BMORE;
  $("tabs").innerHTML=tabs.map(([k,l])=>'<button role="tab" data-t="'+k+'" aria-selected="'+(k==tab)+'">'+ticon(k)+'<span>'+l+'</span></button>').join("");
  $("btabs").innerHTML=BMAIN.map(k=>'<button role="tab" data-t="'+k+'" aria-selected="'+(k==tab)+'">'+ticon(k)+'<span>'+TL[k]+'</span></button>').join("")+'<a class="appStudioLink" href="/studio">'+TICON.studio+'<span>التصميمات</span></a><button type="button" data-t="more" aria-expanded="'+moreOpen+'" aria-controls="sheet" aria-selected="'+moreTabs.includes(tab)+'">'+IC_MORE+'<span>المزيد</span></button>';
  if(moreOpen)$("sheet").classList.remove("hide");else $("sheet").classList.add("hide");
  $("tabs").insertAdjacentHTML("beforeend",'<a class="appStudioLink" href="/studio">'+TICON.studio+'<span>التصميمات</span></a>');
  $("sheet").innerHTML=moreTabs.map(k=>'<button role="tab" data-t="'+k+'" aria-selected="'+(k==tab)+'">'+ticon(k)+'<span>'+(k=="m"?ATAB[1]:TL[k])+'</span></button>').join("");
  if(gi>=S.groups.length)gi=0;
  const v=$("view");
  const gsel=()=>'<label for="gs">المجموعة</label><select id="gs">'+S.groups.map((x,i)=>'<option value="'+i+'"'+(i==gi?' selected':'')+'>'+esc(gname(x))+'</option>').join("")+'</select>';
  if(!S.groups.length&&tab!="g"&&tab!="b"){v.innerHTML='<p>أضف مجموعة الأول من تبويب المجموعات.</p>';return}
  if(tab=="h"){
    const m=today().slice(0,7),rt=(ids)=>{let p=0,x=0;ids.forEach(id=>{const a=monthAtt(id,m);p+=a.p;x+=a.x});return p+x?Math.round(p/(p+x)*100)+"%":"—"};
    const col=all.filter(s=>paid(m,s.id)).length,sc=all.map(s=>monthExam(s.id,m)).filter(x=>x!=null),avg=sc.length?Math.round(sc.reduce((a,b)=>a+b,0)/sc.length)+"%":"—";
    const late=all.filter(s=>overdue(s).length),risky=all.map(s=>({s,x:monthAtt(s.id,m).x})).filter(r=>r.x>=2).sort((a,b)=>b.x-a.x).slice(0,6);
    const st=(n,l)=>'<div class="stat"><strong>'+n+'</strong><span>'+l+'</span></div>';
    const dstr=new Date().toLocaleDateString("ar-EG-u-nu-latn",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
    let h='<div class="hero"><h2>أهلًا بيك تاني</h2><p class="hd">'+dstr+' · نظرة سريعة على مجموعاتك ('+mname(m)+')</p><div class="stats">'+st(all.length,"طالب")+st(rt(all.map(s=>s.id)),"نسبة الحضور")+st(avg,"متوسط الدرجات")+st(totals(m).amount,"تحصيل بمبالغ مسجلة")+st((all.length-col)*S.price,"تقدير المطلوب بالسعر الحالي")+st(late.length,"متأخرين عن شهور")+'</div></div>';
    h+='<div class="qgrid">'+[["a","qa-b","تسجيل الحضور","حاضر، متأخر، معذور، غايب"],["g","qa-g","المجموعات والطلاب","إضافة وتعديل"],["p","qa-o","المصاريف","تأكيد التحصيل"],["e","qa-p","امتحان جديد","سجّل الدرجات"]].map(q=>'<button type="button" class="qa '+q[1]+'" data-t="'+q[0]+'">'+TICON[q[0]]+'<b>'+q[2]+'</b><span>'+q[3]+'</span></button>').join("")+'<button type="button" class="qa qa-s" data-go="/studio">'+TICON.studio+'<b>استوديو التصميمات</b><span>شهادات وبوستات بالصور</span></button></div>';
    const ms6=months6(),rate=mm=>{let p=0,x=0;all.forEach(s=>{const a=monthAtt(s.id,mm);p+=a.p;x+=a.x});return p+x?Math.round(p/(p+x)*100):null};
    h+='<div class="card"><h2>نسبة الحضور آخر 6 شهور</h2>'+bars(ms6.map(rate),ms6.map(sm),"%")+'</div><div class="card"><h2>الدخل آخر 6 شهور (جنيه)</h2>'+bars(ms6.map(mm=>totals(mm).amount),ms6.map(sm))+'<p>الرسم للمبالغ المسجلة فقط. الدفعات القديمة بلا مبلغ لا تدخل فيه.</p>'+'</div>';
    h+='<div class="card"><h2>المجموعات</h2>'+S.groups.map(g=>'<div class="stu"><b>'+esc(gname(g))+'</b><span>'+g.students.length+' طالب · حضور '+rt(g.students.map(s=>s.id))+' · دفع '+g.students.filter(s=>paid(m,s.id)).length+'/'+g.students.length+'</span></div>').join("")+'</div>';
    h+='<div class="card"><h2>محتاجين متابعة</h2>'+(risky.length||late.length?risky.map(r=>'<div class="stu"><span>'+esc(r.s.name)+' <span class="tag bad">غاب '+r.x+' مرة الشهر ده</span></span>'+A(r.s.phone,tplMsg("absM",{الطالب:r.s.name,المادة:S.subject,عدد_الغياب:r.x}),"ابعت")+'</div>').join("")+late.map(s=>'<div class="stu"><span>'+esc(s.name)+' <span class="tag warn">متأخر '+overdue(s).length+' شهر</span></span>'+A(s.phone,tplMsg("feesL",{الطالب:s.name,المادة:S.subject,عدد_الشهور:overdue(s).length}),"تذكير")+'</div>').join(""):'<p>مفيش حد محتاج متابعة دلوقتي.</p>')+'</div>';
    v.innerHTML=h;
  }else if(tab=="g"){
    const m=today().slice(0,7),col=all.filter(s=>paid(m,s.id)).length;
    let h='<div class="stats"><div class="stat"><strong>'+all.length+'</strong><span>طالب</span></div><div class="stat"><strong>'+col+'</strong><span>دفعوا الشهر ده</span></div><div class="stat"><strong>'+(all.length-col)*S.price+'</strong><span>تقدير المتبقي بالسعر الحالي</span></div></div>';
    h+='<input id="gq" type="search" inputmode="search" placeholder="ابحث باسم مجموعة أو طالب…" aria-label="بحث في المجموعات والطلاب" value="'+esc(gq)+'" style="margin-bottom:10px">';
    h+=S.groups.map((g,i)=>'<div class="card gcard" data-q="'+esc(norm(gname(g)+" "+gsched(g)+" "+g.students.map(s=>s.name+" "+s.phone).join(" ")))+'"><div class="row" style="justify-content:space-between"><h2>'+esc(gname(g))+(g.label?' <span style="color:var(--mute);font-size:12.5px;font-weight:600">'+esc(gsched(g))+'</span>':'')+'</h2><div class="btns fx"><button class="ghost sm" data-a="eg" data-i="'+i+'">تعديل الاسم</button><button class="ghost sm" data-a="dg" data-i="'+i+'">حذف</button></div></div>'+
      (egi===i?'<div class="row" style="margin-bottom:8px"><input id="egv'+i+'" value="'+esc(g.label||"")+'" placeholder="اسم مميز للمجموعة — اتركه فارغًا للاسم التلقائي" aria-label="اسم المجموعة"><button class="sm fx" data-a="sg" data-i="'+i+'">حفظ الاسم</button></div>':'')+
      g.students.map((s,j)=>esij===i+"|"+j?'<div class="stu"><div class="row" style="width:100%"><input id="esn" value="'+esc(s.name)+'" aria-label="اسم الطالب"><input id="esp" type="tel" inputmode="tel" dir="ltr" style="text-align:end" value="'+esc(s.phone)+'" aria-label="رقم ولي الأمر"><button class="sm fx" data-a="ss" data-i="'+i+'" data-j="'+j+'">حفظ</button><button class="sm ghost fx" data-a="xs">إلغاء</button></div></div>':'<div class="stu"><span>'+esc(s.name)+' <span style="color:var(--mute);font-size:13px">'+esc(s.phone)+'</span></span><div class="btns">'+(g.notify?A(s.phone,tplMsg("sched",{المادة:S.subject,المجموعة:gname(g),الميعاد:gsched(g)}),"أبلغ"):"")+'<button class="ghost sm" data-a="es" data-i="'+i+'" data-j="'+j+'">تعديل</button><button class="ghost sm" data-a="ds" data-i="'+i+'" data-j="'+j+'">حذف</button></div></div>').join("")+
      (g.notify?'<button class="ghost sm" data-a="nd" data-i="'+i+'">تم إبلاغ الكل</button>':'')+
      '<label for="ns'+i+'">أضف طلاب (اسم، رقم ولي الأمر، كل طالب في سطر)</label><textarea id="ns'+i+'" placeholder="أحمد، 01012345678"></textarea><button class="sm" data-a="as" data-i="'+i+'" style="margin-top:6px">أضف</button>'+
      '<div style="margin-top:10px"><b>الأيام والميعاد</b>'+dayChips("r"+i,g.days)+'<div class="row" style="margin-top:6px"><div>من<input id="rt'+i+'" type="time" value="'+g.t+'"></div><div>إلى<input id="re'+i+'" type="time" value="'+(g.e||"")+'"></div><button class="ghost sm fx" data-a="rs" data-i="'+i+'">غيّر الميعاد</button></div></div></div>').join("");
    h+='<div class="card"><h2>مجموعة جديدة</h2><b>اختار الأيام</b>'+dayChips("n",[])+'<div class="row" style="margin-top:6px"><input id="nt" type="time" value="17:00" aria-label="من"><input id="ne" type="time" value="19:00" aria-label="إلى"><button class="fx" data-a="ag">أضف</button></div></div>';
    v.innerHTML=h;
  }else if(tab=="s"){
    const student=sid&&findSt(sid),f=student?{...student,g:S.groups.find(group=>group.students.includes(student))}:null;
    if(!f){v.innerHTML=all.length?'<input id="sq" type="search" inputmode="search" placeholder="ابحث باسم طالب أو رقم…" aria-label="بحث في الطلاب" value="'+esc(sq)+'" style="margin-bottom:10px">'+S.groups.map(g=>'<div class="card"><h2>'+esc(gname(g))+'</h2>'+g.students.map(s=>'<div class="stu srow" data-q="'+esc(norm(s.name+" "+s.phone))+'"><span>'+esc(s.name)+(s.lvl?' <span class="tag '+(s.lvl=="محتاج دعم"?'bad':'ok')+'">'+s.lvl+'</span>':'')+(s.ct?' <span class="tag warn">'+s.ct+'</span>':'')+'</span><button class="sm ghost" data-a="os" data-id="'+s.id+'">الملف</button></div>').join("")+'</div>').join(""):'<p>أضف طلاب الأول من تبويب المجموعات.</p>'}
    else{const ms=months6(),att=ms.map(mm=>monthAtt(f.id,mm)),ex=S.exams.filter(e=>e.gid==f.g.id&&e.scores[f.id]!=null&&e.scores[f.id]!=="").slice(-6);
      const sl=(fl,l,o)=>'<label>'+l+'<select data-f="'+fl+'" data-sid="'+f.id+'"><option value="">—</option>'+o.map(x=>'<option'+(f[fl]==x?' selected':'')+'>'+x+'</option>').join("")+'</select></label>';
      const ta=(fl,l)=>'<label>'+l+'<textarea data-f="'+fl+'" data-sid="'+f.id+'">'+esc(f[fl]||"")+'</textarea></label>';
      v.innerHTML='<button class="ghost sm" data-a="cs">رجوع لكل الطلاب</button><div class="card" style="margin-top:10px"><h2>'+esc(f.name)+'</h2><p>'+esc(gname(f.g))+' · '+esc(f.phone)+'</p>'+sl("lvl","المستوى",["ممتاز","جيد","محتاج دعم"])+sl("ct","أفضل وقت للتواصل مع ولي الأمر",["صباحًا","مساءً","أي وقت"])+sl("style","أسلوب التعلم المفضل",["شرح","تمارين","ملخصات","مراجعة شفوية"])+ta("strg","نقاط القوة")+ta("weak","نقاط تحتاج تحسين")+ta("note","ملاحظات")+'</div><div class="card"><h2>الحضور (حصص في الشهر)</h2>'+bars(att.map(a=>a.p),ms.map(sm))+'</div><div class="card"><h2>درجات آخر امتحانات</h2>'+(ex.length?bars(ex.map(e=>Math.round(e.scores[f.id]/e.max*100)),ex.map(e=>e.title.slice(0,7)),"%"):'<p>مفيش درجات لسه.</p>')+'</div><div class="card"><h2>المصاريف</h2><div class="btns">'+ms.map(mm=>'<span class="tag '+(paid(mm,f.id)?'ok':'warn')+'">'+sm(mm)+(paid(mm,f.id)?' دفع':' لسه')+'</span>').join("")+'</div></div>'}
  }else if(tab=="a"){
    const g=S.groups[gi],k=adate+"|"+g.id,rec=S.att[k]||{};
    let h=gsel()+'<label for="ad">التاريخ</label><input id="ad" type="date" value="'+adate+'"><div class="card" style="margin-top:12px">'+(g.students.length?g.students.map((s,j)=>{const r=rec[s.id],mm=monthAtt(s.id,adate.slice(0,7));return'<div class="stu"><span>'+esc(s.name)+' <span class="tag '+(mm.x>2?'bad':'ok')+'">غاب '+mm.x+' في الشهر</span></span><div class="btns">'+(r===false?A(s.phone,tplMsg("absD",{الطالب:s.name,المادة:S.subject,التاريخ:adate}),"ابعت لولي الأمر"):"")+((r===true||r==="l")?A(s.phone,tplMsg("arrD",{الطالب:s.name,المادة:S.subject,التاريخ:adate,الوقت:fmt(new Date().toTimeString().slice(0,5))}),"وصل"):"")+'<button class="sm'+(r===true?'':' ghost')+'" data-a="p" data-j="'+j+'">حاضر</button><button class="sm'+(r==="l"?'':' ghost')+'" data-a="l" data-j="'+j+'">متأخر</button><button class="sm'+(r==="e"?'':' ghost')+'" data-a="e" data-j="'+j+'">معذور</button><button class="sm'+(r===false?'':' ghost')+'" data-a="x" data-j="'+j+'">غايب</button></div></div>'}).join(""):'<p>مفيش طلاب في المجموعة دي لسه.</p>')+'<p style="color:var(--mute);font-size:12px;margin-top:8px">متأخر بيتحسب حضور، ومعذور مش بيدخل في نسبة الحضور.</p></div>';
    const gk=Object.keys(S.att).filter(x=>x.split('|')[1]===g.id&&g.students.some(s=>S.att[x][s.id]!=null)).sort().reverse();
    h+='<div class="card"><h2>ملخص الحضور — '+gk.length+' حصة مسجلة</h2>'+(gk.length?g.students.map(s2=>{let pp=0,xx=0;gk.forEach(x=>{const val=S.att[x][s2.id];if(val===true||val==="l")pp++;else if(val===false)xx++});const n=pp+xx;return n?'<div class="stu"><span>'+esc(s2.name)+'</span><span><span class="tag '+(pp/n>=.75?'ok':pp/n>=.5?'warn':'bad')+'">'+Math.round(pp/n*100)+'%</span> <span style="color:var(--mute);font-size:13px">حضر '+pp+' من '+n+'</span></span></div>':''}).join(""):'<p>مفيش حصص مسجلة للمجموعة دي لسه.</p>')+'</div>';
    h+='<div class="card"><h2>سجل الحصص</h2>'+(gk.length?gk.slice(0,12).map(x=>{const d=x.split('|')[0],r2=S.att[x],pv=g.students.filter(s2=>r2[s2.id]===true||r2[s2.id]==="l").length,xv=g.students.filter(s2=>r2[s2.id]===false).length,lv=g.students.filter(s2=>r2[s2.id]==="l").length,wd=DAYS[(new Date(d+"T12:00:00").getDay()+1)%7];return'<div class="stu"><span>'+wd+' '+d+'</span><div class="btns"><span class="tag ok">حضر '+pv+'</span><span class="tag '+(xv?'bad':'ok')+'">غاب '+xv+'</span>'+(lv?'<span class="tag warn">تأخر '+lv+'</span>':'')+'<button class="sm ghost" data-a="sd" data-d="'+d+'">عرض</button></div></div>'}).join("")+(gk.length>12?'<p>يعرض آخر 12 حصة من إجمالي '+gk.length+'.</p>':''):'<p>مفيش سجل لسه — سجّل أول حصة من فوق.</p>')+'</div>';
    v.innerHTML=h;
  }else if(tab=="w"){
    const g=S.groups[gi],k=adate+"|"+g.id,hw=(S.hw||{})[k]||{text:"",done:{}};
    let h=gsel()+'<label for="ad">تاريخ الحصة</label><input id="ad" type="date" value="'+adate+'">';
    h+='<div class="card" style="margin-top:12px"><h2>واجب الحصة</h2><textarea id="hwText" rows="3" aria-label="نص الواجب" placeholder="اكتب الواجب المطلوب للحصة دي">'+esc(hw.text||"")+'</textarea><div class="btns" style="margin-top:8px"><button class="sm" data-a="hwsv">حفظ الواجب</button><button type="button" class="sm ghost" data-a="hw-message">جهّز رسالة المجموعة</button></div><p id="hwDraftStatus" class="note" role="status"></p></div>';
    h+='<div class="card" id="hwMessage" hidden><h2>رسالة واجب المجموعة</h2><label for="hwMessageText">راجع النص قبل ما تبعته</label><textarea id="hwMessageText" rows="8" readonly dir="auto" aria-label="رسالة واجب المجموعة الجاهزة"></textarea><div class="btns" style="margin-top:10px"><button type="button" class="sm" data-a="hw-copy">نسخ الرسالة</button></div><p class="note">الرسالة من الواجب المحفوظ وتاريخ الحصة اللي اخترته، مش موعد تسليم جديد. انسخها والصقها بنفسك في جروب المجموعة. مفيش إرسال تلقائي أو فتح لواتساب.</p></div>';
    h+='<div class="card"><h2>تسليم الواجب</h2>'+(g.students.length?g.students.map((s,j)=>{const dn=!!(hw.done&&hw.done[s.id]);return '<div class="stu"><span>'+esc(s.name)+' <span class="tag '+(dn?'ok':'warn')+'">'+(dn?'سلّم':'لسه')+'</span></span><div class="btns">'+((hw.text||"").trim()&&!dn?A(s.phone,tplMsg("hwR",{الطالب:s.name,المادة:S.subject,التاريخ:adate,الواجب:hw.text}),"ذكّر"):"")+'<button class="sm'+(dn?'':' ghost')+'" data-a="hwd" data-j="'+j+'">'+(dn?'سلّم':'لم يسلّم')+'</button></div></div>'}).join(""):'<p>مفيش طلاب في المجموعة دي لسه.</p>')+'</div>';
    v.innerHTML=h;
  }else if(tab=="p"){
    const exp=all.filter(s=>!paid(pmonth,s.id)).length*S.price,col=totals(pmonth).amount;
    let h='<label for="pm">الشهر</label><input id="pm" type="month" value="'+pmonth+'"><div class="stats" style="margin-top:12px"><div class="stat"><strong>'+income(pmonth)+'</strong><span>تفصيل التحصيل</span></div><div class="stat"><strong>'+col+'</strong><span>اتحصّل</span></div><div class="stat"><strong>'+exp+'</strong><span>تقدير غير المدفوع</span></div></div>';
    h+=S.groups.map(g=>'<div class="card"><h2>'+esc(gname(g))+'</h2>'+g.students.map(s=>{const o=overdue(s),pd=paid(pmonth,s.id);return'<div class="stu"><span>'+esc(s.name)+' <span class="tag '+(pd?'ok':'warn')+'">'+(pd?'دفع':'لسه')+'</span>'+(o.length?' <span class="tag bad">متأخر '+o.length+' شهر</span>':'')+'</span><div class="btns">'+(pd?'':A(s.phone,tplMsg("feesM",{الطالب:s.name,المادة:S.subject,الشهر:mname(pmonth),المبلغ:S.price}),"تذكير"))+'<button class="sm ghost" data-a="pay" data-id="'+s.id+'">'+(pd?'إلغاء':'تم الدفع')+'</button></div></div>'}).join("")+'</div>').join("");
    v.innerHTML=h;
  }else if(tab=="e"){
    let h='<div class="card"><h2>امتحان جديد</h2>'+gsel()+'<div class="row"><div><label for="et">الاسم</label><input id="et" placeholder="امتحان الباب الأول"></div><div><label for="em">من كام</label><input id="em" type="number" value="20"></div></div><button class="sm" data-a="ae" style="margin-top:8px">أضف الامتحان</button></div>';
    h+=S.exams.slice().reverse().map(e=>{const g=S.groups.find(x=>x.id==e.gid);if(!g)return"";return'<div class="card"><div class="row" style="justify-content:space-between"><h2>'+esc(e.title)+' <span style="color:var(--mute);font-size:13px">'+esc(gname(g))+" · "+e.date+'</span></h2><button class="ghost sm fx" data-a="de" data-id="'+e.id+'">حذف</button></div>'+g.students.map(s=>{const sc=e.scores[s.id];return'<div class="stu"><span>'+esc(s.name)+'</span><div class="btns"><input class="sc" type="number" min="0" max="'+e.max+'" data-e="'+e.id+'" data-s="'+s.id+'" value="'+(sc==null?"":sc)+'" aria-label="درجة '+esc(s.name)+'"> / '+e.max+(sc!=null&&sc!==""?A(s.phone,tplMsg("exam",{الطالب:s.name,الامتحان:e.title,الدرجة:sc,المنتهى:e.max}),"ابعت"):"")+'</div></div>'}).join("")+'</div>'}).join("");
    v.innerHTML=h;
  }else if(tab=="t"){
    let h='<div class="card"><h2>قوالب الرسائل</h2><p>كل الرسائل اللي بتتجهّز لك في التطبيق بتستخدم القوالب دي. عدّل أي قالب بطريقتك، والرموز اللي بين أقواس بتتملى تلقائيًا ببيانات كل طالب. الرسالة بتتفتح في واتساب بتاعك للمراجعة، ومش بتتبعت غير لما تضغط إرسال بنفسك.</p></div>';
    h+=Object.keys(TPL_DEF).map(k=>{const meta=TPL_META[k],custom=tplCustom(k);
      return'<div class="card"><div class="row" style="justify-content:space-between"><h2>'+meta.label+'</h2>'+(custom?'<span class="tag ok">مخصص</span>':'<span class="tag warn">افتراضي</span>')+'</div>'
      +'<p style="margin:4px 0 8px">الرموز المتاحة: '+meta.tokens.map(x=>'<span class="tag">{'+x+'}</span>').join(" ")+'</p>'
      +'<textarea id="tpl_'+k+'" rows="4" aria-label="'+meta.label+'">'+esc(custom||TPL_DEF[k])+'</textarea>'
      +'<div class="btns" style="margin-top:8px"><button class="sm" data-a="tsv" data-k="'+k+'">حفظ القالب</button>'+(custom?'<button class="sm ghost" data-a="trst" data-k="'+k+'">استرجاع الافتراضي</button>':'')+'</div>'
      +'<b style="font-size:13px">مثال توضيحي:</b><div id="pv_'+k+'" style="white-space:pre-line;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:10px;font-size:13.5px;margin-top:6px"></div></div>'}).join("");
    v.innerHTML=h;
    Object.keys(TPL_DEF).forEach(tplPreview);
  }else if(tab=="b"){
    v.innerHTML='<div class="card"><h2>النسخ الاحتياطي</h2><p>نزّل نسخة JSON من كل بياناتك في أي وقت. النسخة تحتوي بيانات طلابك، احفظها في مكان خاص وآمن.</p><button type="button" data-a="bk">تنزيل نسخة احتياطية</button></div>'
      +'<div class="card"><h2>استعادة نسخة</h2><label for="restorePick">استعادة نسخة JSON (بحد أقصى 5 ميجابايت)</label><input id="restorePick" class="srfile" type="file" accept="application/json,.json"><div class="btns"><button type="button" id="restoreBtn">اختيار ملف النسخة</button><span id="restoreName" class="fname" aria-live="polite"></span></div><small>الاستعادة بتنزّل نسخة من بياناتك الحالية الأول، وبعدين بتستبدلها بعد الحفظ.</small></div>'
      +'<div class="card"><h2>مزامنة الحفظ</h2><p>حالة الحفظ بتظهر دايمًا في شريط الحالة أعلى الصفحة.</p><div class="btns"><button type="button" class="ghost sm" data-a="retry">حاول الحفظ</button><button type="button" class="ghost sm" data-a="reload">إعادة تحميل البيانات</button></div></div>';
  }else if(tab=="m"){
    if(ADMIN_ROWS==null){v.innerHTML='<p>جاري تحميل سجل العملاء الخاص...</p>';adminLoad()}
    else if(ADMIN_ERROR){v.innerHTML='<div class="card"><p>'+esc(ADMIN_ERROR)+'</p><button type="button" class="ghost sm" data-a="adm-refresh">حاول تاني</button></div>'}
    else v.innerHTML=window.OstazyAccount46?window.OstazyAccount46.adminHtml(ADMIN_ROWS):'<div class="card"><p>تعذّر تحميل واجهة السجل الخاص. أعد تحميل الصفحة.</p></div>';
  }else{
    const ms=months6();
    let h='<div class="card report-export"><div class="export-heading"><span class="export-badge" aria-hidden="true">XLSX</span><div><h2>تصدير التقارير</h2><p>تقارير كل مجموعاتك، في ملف Excel واحد.</p></div></div><p>شيت مستقل لكل مجموعة: بيانات الطلاب، المواعيد، الحضور، المصاريف وحركات التحصيل، الامتحانات والواجب. يشمل كل الفترات المسجلة، مش الشهر المختار بس.</p><button type="button" data-a="export-xlsx">تنزيل Excel كامل</button><small>الملف بيتجهّز على جهازك من غير رفع إضافي لخدمة خارجية. فيه بيانات خاصة بطلابك، احفظه في مكان آمن.</small></div>';
    h+='<div class="card"><h2>الدخل آخر 6 شهور</h2>'+ms.map(m=>{const c=income(m);return'<div class="stu"><span>'+mname(m)+'</span><b>'+c+'</b></div>'}).join("")+'</div>';
    const tp=all.map(s=>({s,e:monthExam(s.id,rmonth)})).filter(r=>r.e!=null).sort((a,b)=>b.e-a.e).slice(0,5);
    h+='<div class="card"><h2>الأوائل في '+mname(rmonth)+'</h2>'+(tp.length?tp.map(r=>'<div class="stu"><span>'+esc(r.s.name)+'</span><b>'+r.e+'%</b></div>').join(""):'<p>مفيش درجات الشهر ده.</p>')+'</div>';
    h+='<label for="rm">تقرير شهر</label><input id="rm" type="month" value="'+rmonth+'" style="margin-bottom:12px">';
    h+=S.groups.map(g=>'<div class="card"><h2>'+esc(gname(g))+'</h2>'+g.students.map(s=>{const a=monthAtt(s.id,rmonth),ex=monthExam(s.id,rmonth),pd=paid(rmonth,s.id);
      const msg=tplMsg("report",{الطالب:s.name,المادة:S.subject,الشهر:mname(rmonth),الحضور:a.p,الغياب:a.x,الدرجات:(ex==null?"لا يوجد امتحان":ex+"%"),حالة_المصاريف:(pd?"مدفوعة":"لم تُدفع بعد")});
      return'<div class="stu"><span>'+esc(s.name)+' <span class="tag ok">حضر '+a.p+'</span> <span class="tag '+(a.x?'bad':'ok')+'">غاب '+a.x+'</span>'+(ex==null?'':' <span class="tag warn">'+ex+'%</span>')+'</span>'+A(s.phone,msg,"ابعت التقرير")+'</div>'}).join("")+'</div>').join("");
    v.innerHTML=h;
  }
  const q=(id,fn)=>{const e=$(id);if(e)e.onchange=fn};
  q("gs",e=>{gi=+e.target.value;render()});q("ad",e=>{adate=e.target.value||today();render()});
  q("pm",e=>{pmonth=e.target.value||pmonth;render()});q("rm",e=>{rmonth=e.target.value||rmonth;render()});
  const rb=$("restoreBtn");if(rb)rb.onclick=()=>{const i=$("restorePick");if(i)i.click()};
  decorateGroupOverview();
  applyFilters();
}
async function adminLoad(){const r=await sb.rpc("ostazy_admin_list_customers");if(r.error){ADMIN_ERROR="تعذّر تحميل سجل العملاء الخاص. حاول تاني من حساب الإدارة.";status(ADMIN_ERROR);ADMIN_ROWS=[];render();return}ADMIN_ERROR="";ADMIN_ROWS=r.data||[];render()}
$("tabs").onclick=e=>{const b=e.target.closest("button[data-t]");if(b){tab=b.dataset.t;render()}};
$("btabs").onclick=e=>{const b=e.target.closest("button[data-t]");if(!b)return;if(b.dataset.t=="more"){moreOpen=!moreOpen;render();return}moreOpen=false;tab=b.dataset.t;render()};
$("sheet").onclick=e=>{const b=e.target.closest("button[data-t]");if(!b)return;moreOpen=false;tab=b.dataset.t;render()};
$("view").onchange=e=>{const t=e.target;if(t.id==="restorePick"){restoreFile(t);return}if(t.dataset&&(t.dataset.f||t.dataset.e)&&!active()){flash();render();return}if(t.dataset&&t.dataset.f){const s=findSt(t.dataset.sid);if(s){s[t.dataset.f]=t.value;persist()}return}if(t.dataset&&t.dataset.e){const ex=S.exams.find(x=>x.id==t.dataset.e);ex.scores[t.dataset.s]=C.clampScore(t.value,ex.max);persist();render()}};
$("view").addEventListener("input",e=>{const t=e.target;if(t.id==="customerSearch"){window.OstazyAccount46.search(t.value)}else if(t.id==="hwText"){hwDraftContext=null;if($("hwMessage"))$("hwMessage").hidden=true;if($("hwDraftStatus"))$("hwDraftStatus").textContent="النص اتغيّر. احفظ الواجب واستنى تأكيد الحفظ، وبعدها جهّز الرسالة من جديد."}else if(t.id==="gq"){gq=t.value;applyFilters()}else if(t.id==="sq"){sq=t.value;applyFilters()}else if(t.id&&t.id.indexOf("tpl_")===0)tplPreview(t.id.slice(4))});
$("view").onclick=async e=>{
  const go=e.target.closest("[data-go]");if(go){location.href=go.dataset.go;return}
  const tb=e.target.closest("button[data-t]");if(tb){tab=tb.dataset.t;render();return}
  const b=e.target.closest("button[data-a]");if(!b)return;
  if(b.dataset.a==='export-xlsx'){
    if(!S||!uid||loadFailed){status('لا توجد بيانات موثوقة جاهزة للتصدير. أعد تحميل بيانات الحساب أولًا.');return}
    const snapshot=structuredClone(S),owner=uid,account=EMAIL,label=b.textContent;b.disabled=true;b.textContent='جاري تجهيز Excel…';
    await new Promise(resolve=>setTimeout(resolve,32));
    try{if(owner!==uid)throw new Error('تغيّر الحساب أثناء التجهيز. افتح التقرير من الحساب المطلوب.');if(!window.OstazyReports)throw new Error('تعذّر تحميل أداة Excel. حدّث الصفحة وحاول تاني.');const result=window.OstazyReports.download(snapshot,{accountEmail:account});status('تم تجهيز ملف Excel: '+result.groupCount+' مجموعة، و'+result.sheetCount+' شيت مع الملخص والسجلات الإضافية. لو التحميل لم يبدأ، اسمح بتنزيل الملفات من المتصفح.');}
    catch(error){status(error&&error.message||'تعذّر تجهيز Excel. بياناتك الأصلية لم تتغير.');}
    finally{b.disabled=false;b.textContent=label}return;
  }
  if(!active()&&!["os","cs","bk","retry","reload","adm-ext","adm-set","adm-refresh"].includes(b.dataset.a)){flash();return}
  const a=b.dataset.a,i=+b.dataset.i,j=+b.dataset.j,m=today().slice(0,7);
  if(a==="hw-message"||a==="hw-copy"){
    const notice=text=>{if($("hwDraftStatus"))$("hwDraftStatus").textContent=text;status(text)};
    const hide=()=>{hwDraftContext=null;if($("hwMessage"))$("hwMessage").hidden=true};
    if(!S||!uid||loadFailed||saveBlocked){hide();notice("أعد تحميل بيانات الحساب الأول. الرسالة محتاجة بيانات محفوظة وموثوقة.");return}
    const group=S.groups[gi],key=group&&adate+"|"+group.id,assignment=key&&(S.hw||{})[key];
    if(dirty||saving){hide();notice("استنى لحد ما يظهر تأكيد حفظ كل التغييرات، وبعدها جهّز الرسالة.");return}
    if(!group||!$("hwText")||$("hwText").value.trim()!==String(assignment&&assignment.text||"").trim()){hide();notice("نص الواجب اتغيّر. احفظ الواجب واستنى تأكيد الحفظ الأول.");return}
    let text;try{if(!window.OstazyHomework)throw Error("أداة الرسالة ما اتحمّلتش. حدّث الصفحة وحاول تاني.");text=OstazyHomework.build({subject:S.subject,groupName:gname(group),classDate:adate,homework:assignment&&assignment.text})}catch(error){hide();notice(error.message||"تعذّر تجهيز الرسالة.");return}
    if(a==="hw-message"){hwDraftContext={owner:uid,group:group.id,date:adate,text};$("hwMessageText").value=text;$("hwMessage").hidden=false;notice("الرسالة جاهزة للمراجعة والنسخ. لم يتم إرسال أي شيء.");return}
    if(!hwDraftContext||hwDraftContext.owner!==uid||hwDraftContext.group!==group.id||hwDraftContext.date!==adate||hwDraftContext.text!==text||$("hwMessageText").value!==text){hide();notice("البيانات اتغيّرت. جهّز الرسالة من جديد قبل النسخ.");return}
    const area=$("hwMessageText");try{if(!navigator.clipboard||!navigator.clipboard.writeText)throw Error("clipboard");await navigator.clipboard.writeText(text);notice("تم نسخ الرسالة فقط. الصقها بنفسك في جروب المجموعة.")}catch(error){area.focus();area.select();notice("النسخ التلقائي مش متاح هنا. النص متحدد، انسخه يدويًا.")}return;
  }
  if(a==="adm-refresh"){ADMIN_ROWS=null;ADMIN_ERROR="";render();return}
  if(a==="os"||a==="cs"){sid=a==="os"?b.dataset.id:null;render();return}
  if(a=="adm-ext"||a=="adm-set"){
    const row=(ADMIN_ROWS||[]).find(x=>x.user_id==b.dataset.id);if(!row)return;
    let until;
    if(a=="adm-ext"){const base=new Date(Math.max(Date.now(),Date.parse(row.paid_until||0)||0));base.setMonth(base.getMonth()+1);until=base}
    else{const inp=$("admd_"+row.user_id);if(!inp||!inp.value){status("اختار تاريخ التفعيل الأول.");return}until=new Date(inp.value+"T23:59:59")}
    if(until.getTime()<=Date.now()){status("تاريخ التفعيل لازم يكون في المستقبل.");return}
    if(!confirm("تفعيل اشتراك "+row.email+" لحد "+until.toLocaleDateString("ar-EG-u-nu-latn")+"؟ ده تعديل إداري في حالة الاشتراك فقط، من غير أي دفع إلكتروني."))return;
    status("جاري حفظ التفعيل...");
    const r=await sb.rpc("admin_set_paid_until",{target:row.user_id,until:until.toISOString()});
    if(r.error){status("تعذّر تفعيل الاشتراك. تحقق من الحساب والتاريخ، ثم أعد المحاولة.");return}
    status("تم تفعيل الاشتراك لحد "+until.toLocaleDateString("ar-EG-u-nu-latn")+".");ADMIN_ROWS=null;render();return;
  }
  if(a=="sd"){adate=b.dataset.d||adate;render();return}
  if(a=="eg"){egi=egi===i?-1:i;esij=null;render();if(egi===i){const el=$("egv"+i);el&&el.focus()}return}
  if(a=="sg"){const nv=($("egv"+i).value||"").trim(),g=S.groups[i];if(nv)g.label=nv.slice(0,80);else delete g.label;egi=-1}
  else if(a=="es"){esij=i+"|"+j;egi=-1;render();const el=$("esn");el&&el.focus();return}
  else if(a=="xs"){esij=null;render();return}
  else if(a=="ss"){const stu=S.groups[i].students[j],nn=($("esn").value||"").trim();if(!nn){status("اسم الطالب مطلوب.");return}stu.name=nn.slice(0,100);stu.phone=($("esp").value||"").trim().slice(0,30);esij=null}
  else if(a=="dg"){confirm("حذف المجموعة وطلابها من القوائم؟ نزّل نسخة احتياطية قبل الحذف. سيظل سجل التحصيل محفوظًا.")&&S.groups.splice(i,1)}
  else if(a=="ds"){confirm("حذف الطالب من القوائم؟ نزّل نسخة احتياطية قبل الحذف. سيظل سجل التحصيل محفوظًا.")&&S.groups[i].students.splice(j,1)}
  else if(a=="as"){S.groups[i].students.push(...$("ns"+i).value.split("\n").map(l=>l.split(/[,،]/).map(x=>x.trim())).filter(r=>r[0]).map(r=>({id:rid(),name:r[0],phone:r[1]||"",since:m})))}
  else if(a=="rs"){const g=S.groups[i],ds=getDays("r"+i);if(!ds.length)return;g.days=ds;g.t=$("rt"+i).value||g.t;g.e=$("re"+i).value||"";g.notify=g.students.length>0}
  else if(a=="nd"){S.groups[i].notify=false}
  else if(a=="ag"){const ds=getDays("n");if(!ds.length)return;S.groups.push({id:rid(),days:ds,t:$("nt").value||"17:00",e:$("ne").value||"",notify:false,students:[]})}
  else if(a=="p"||a=="x"||a=="l"||a=="e"){const g=S.groups[gi],k=adate+"|"+g.id;S.att[k]=S.att[k]||{};const id=g.students[j].id,v=a=="p"?true:a=="x"?false:a;S.att[k][id]=S.att[k][id]===v?null:v}
  else if(a=="hwsv"){const g=S.groups[gi],k=adate+"|"+g.id;S.hw=S.hw||{};const t=(($("hwText")||{}).value||"").trim().slice(0,1000);const old=S.hw[k]||{text:"",done:{}};if(!t&&!Object.keys(old.done||{}).length)delete S.hw[k];else S.hw[k]={text:t,done:old.done||{}}}
  else if(a=="hwd"){const g=S.groups[gi],k=adate+"|"+g.id;S.hw=S.hw||{};S.hw[k]=S.hw[k]||{text:"",done:{}};S.hw[k].done=S.hw[k].done||{};const id=g.students[j].id;if(S.hw[k].done[id]===true)delete S.hw[k].done[id];else S.hw[k].done[id]=true}
  else if(a=="pay"){const student=findSt(b.dataset.id);if(!confirm(paid(pmonth,student.id)?"تأكيد إلغاء الدفعة؟ سيتم تسجيل عكس للمبلغ المعروف.":"تأكيد تحصيل "+S.price+" جنيه من "+student.name+" لشهر "+mname(pmonth)+"؟"))return;C.togglePayment(S,pmonth,student.id,rid())}
  else if(a=="ae"){const t=$("et").value.trim();if(!t)return;S.exams.push({id:rid(),gid:S.groups[gi].id,title:t,date:today(),max:Math.max(1,num($("em").value)||20),scores:{}})}
  else if(a=="de"){confirm("حذف الامتحان ودرجاته؟")&&(S.exams=S.exams.filter(x=>x.id!=b.dataset.id))}
  else if(a=="tsv"){const k=b.dataset.k;if(!TPL_DEF[k])return;const val=$("tpl_"+k).value,err=tplCheck(k,val);if(err){status(err);return}S.tpl=S.tpl||{};S.tpl[k]=val.trim()}
  else if(a=="trst"){const k=b.dataset.k;if(S.tpl&&TPL_DEF[k])delete S.tpl[k]}
  else if(a=="bk"){downloadBackup();return}
  else if(a=="retry"){save2();return}
  else if(a=="reload"){if(dirty&&!confirm("يوجد تعديل غير محفوظ. نزّل نسخة احتياطية أولًا. هل تريد تجاهله وتحميل النسخة المحفوظة؟"))return;clearTimeout(pt);if(saving){status("انتظر اكتمال محاولة الحفظ أولًا.");return}load();return}
  persist();render();
};
sb.auth.onAuthStateChange((event,session)=>{
 if(event==="SIGNED_OUT"&&uid){endSession57();return;}
 const next57=session?.user?.id;
 if(next57&&next57!==uid){stashSessionWork57();accountEpoch57++;clearTimeout(pt);clearAccountDisplay57();S=null;SUB=null;dirty=false;uid=null;loadFailed=true;const expected57=accountEpoch57;setTimeout(()=>{if(accountEpoch57===expected57)startSession57(session)},0);}
 else if(next57===uid&&session?.user?.email)EMAIL=session.user.email;
});
init();

// Group overview is presentation state only. Existing account/data handlers stay in use.
const groupPanelsOpen=new Set();
function decorateGroupOverview(){
 if(tab!=="g")return;
 document.querySelectorAll("#view .gcard").forEach((card,i)=>{
  const group=S.groups[i];if(!group||card.dataset.overviewReady)return;card.dataset.overviewReady="1";
  const original=[...card.children],intro=document.createElement("div");intro.className="groupOverview";
  const heading=document.createElement("h2");heading.textContent=gname(group);intro.append(heading);
  if(group.label){const schedule=document.createElement("p");schedule.textContent=gsched(group);intro.append(schedule)}
  const count=document.createElement("span");count.className="groupCount";count.textContent=group.students.length+" طالب";intro.append(count);
  const actions=document.createElement("div");actions.className="groupQuickActions";
  for(const [destination,label]of [["a","تسجيل الحضور"],["p","المصاريف"]]){const button=document.createElement("button");button.type="button";button.className="ghost sm";button.textContent=label;button.onclick=()=>{gi=i;tab=destination;render()};actions.append(button)}
  intro.append(actions);
  const details=document.createElement("details");details.className="groupManage";details.open=groupPanelsOpen.has(group.id)||egi===i||String(esij||"").startsWith(i+"|");
  const summary=document.createElement("summary");summary.textContent="إدارة الطلاب والمواعيد";details.append(summary);original.forEach(node=>details.append(node));
  details.ontoggle=()=>{if(norm(gq))return;if(details.open)groupPanelsOpen.add(group.id);else groupPanelsOpen.delete(group.id)};
  card.replaceChildren(intro,details);
 });
 const last=document.querySelector("#view>.card:last-child");if(last&&!last.classList.contains("gcard")&&!last.querySelector("details")){const details=document.createElement("details");details.className="groupManage newGroup";const summary=document.createElement("summary");summary.textContent="إضافة مجموعة جديدة";details.append(summary);[...last.children].forEach(node=>details.append(node));last.replaceChildren(details)}
}
