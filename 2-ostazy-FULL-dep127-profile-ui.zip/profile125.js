/* ملفي: بيانات المدرس نفسه (اسم، سنتر، واتساب، تاجات، خط، شعار) تتحط افتراضيًا في الشهادات والإعلانات والستوري.
   محفوظة على جهاز المدرس فقط. مفيش أي بيانات طلبة. */
(function(){'use strict';
const KEY='ostazyProfileV1';
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){return{}}};
let P=load();
const has=()=>!!(P.name||P.school||P.phone||P.tags||P.font||P.logo);
const wa=()=>P.phone?('واتساب: '+P.phone):'';
const tagLine=()=>[P.tags,P.school].filter(Boolean).join('  •  ');
// ---- ads ----
const _aac=applyAdCopy;
applyAdCopy=function(){_aac.apply(this,arguments);if(!P.auto&&P.auto!==undefined)return;if(!has())return;
 if(ELS.teacher&&P.name)ELS.teacher.text=P.name;
 if(ELS.phone&&P.phone)ELS.phone.text=wa();
 if(P.tags||P.school){const tl=tagLine();if(tl){ELS.ptags=T('ptags','التاجات',250,614,{z:19,text:tl,size:11,weight:700,color:'#fff',bg:'rgba(0,0,0,.45)',radius:99,pad:'3px 14px'})}}
 if(P.font)Object.keys(ELS).forEach(k=>{if(ELS[k]&&typeof ELS[k]==='object'&&'font' in ELS[k])ELS[k].font=P.font})};
// ---- stories ----
const _bv=buildVTpl;
buildVTpl=function(){const t=_bv.apply(this,arguments);if(P.auto===false||!has()||!t||!t.layers)return t;
 const f=P.font||'Cairo',y=t.height-52,L=[];
 if(P.name&&!t.layers.some(l=>l.value===P.name))L.push({type:'text',value:P.name,font:f,weight:800,size:24,color:'#FFFFFF',y:y-34,x:270,maxW:440,fadeIn:[.2,1],alpha:.95});
 const bot=[P.phone,P.tags].filter(Boolean).join('  •  ');
 if(bot)L.push({type:'text',value:bot,font:f,weight:700,size:20,color:'#FFFFFF',y:y,x:270,maxW:460,fadeIn:[.4,1.2],alpha:.9});
 t.layers=t.layers.concat(L);
 if(P.font)t.layers.forEach(l=>{if(l.type==='text')l.font=P.font});return t};
const _fv=fillVFields;fillVFields=function(){_fv.apply(this,arguments);if(P.auto===false||!P.name)return;document.querySelectorAll('#vFields input').forEach(i=>{if(i.value==='مدرّسك'||i.value==='مدرّسكم')i.value=P.name})};
// ---- certificates ----
function applyCert(){if(P.name&&$('#cTeacher'))$('#cTeacher').value=P.name;if(P.school&&$('#cSchool'))$('#cSchool').value=P.school}
// ---- logo ----
function applyLogo(){if(!P.logo||logo)return;const im=new Image();im.onload=()=>{if(logo)return;logo={src:P.logo,x:430,y:64,s:Math.min(1,110/(im.naturalWidth||120)),r:0};const d=$('#logoDel');if(d)d.hidden=false;renderLogo()};im.src=P.logo}
// ---- dialog ----
const css=document.createElement('style');css.textContent=`#profOv{display:none;position:fixed;inset:0;z-index:220;background:rgba(0,27,77,.45);align-items:center;justify-content:center;padding:16px}#profOv.open{display:flex}#profBox{background:var(--card,#fff);color:var(--ink);border:1px solid var(--line);border-radius:16px;max-width:480px;width:100%;max-height:88dvh;overflow:auto;padding:0;direction:rtl;font-family:Tajawal,Cairo,sans-serif;box-shadow:0 18px 50px rgba(0,27,77,.35)}#profHead{background:#0B1F44;color:#fff;padding:16px 18px 14px;border-radius:16px 16px 0 0;text-align:center;border-bottom:3px solid #00D4FF}#profHead h3{margin:0;font-size:18px;font-weight:800}#profHead p{margin:6px 0 0;font-size:12px;color:#B6C7DD;font-weight:600}#profBody{padding:14px 18px 18px}#profBody .g2{display:grid;grid-template-columns:1fr 1fr;gap:10px}@media(max-width:420px){#profBody .g2{grid-template-columns:1fr}}#profBody label{display:block;margin:10px 0 5px;font-weight:700;font-size:12.5px;color:var(--mute)}#profBody input:not([type=checkbox]),#profBody select{width:100%;box-sizing:border-box;min-height:42px;font:inherit;font-size:14px;color:var(--ink);border:1px solid var(--line);border-radius:10px;background:#fff;text-align:center;text-align-last:center;padding:0 12px;display:block}#profBody input:focus,#profBody select:focus{outline:2px solid #00D4FF;outline-offset:1px}#profBody .sec{margin-top:14px;padding-top:12px;border-top:1px solid var(--line)}#profBody .row{display:flex;gap:8px;margin-top:10px}#profBody .row button{flex:1;min-height:44px;display:flex;align-items:center;justify-content:center;text-align:center;padding:0 10px;line-height:1.2;box-sizing:border-box}@media(max-width:600px){#profOv{padding-top:64px;align-items:flex-start}#profBox{max-height:calc(100dvh - 80px)}}#profBody .hint{font-size:12px;color:var(--mute);text-align:center;margin:4px 0 0;font-weight:600}#profBody .bkshow{margin-top:14px;justify-content:center}`;document.head.appendChild(css);
const ov=document.createElement('div');ov.id='profOv';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');
ov.innerHTML=`<div id="profBox"><div id="profHead"><h3>ملفي</h3><p>بياناتك بتتحط تلقائيًا في الشهادات والإعلانات والستوري. بتتحفظ على جهازك بس.</p></div><div id="profBody">
<div class="g2"><div><label>اسمك</label><input id="pfName" placeholder="الأستاذ أحمد علي"></div><div><label>السنتر / المدرسة</label><input id="pfSchool"></div>
<div><label>رقم الواتساب</label><input id="pfPhone" dir="ltr" inputmode="tel" placeholder="01xxxxxxxxx"></div><div><label>التاجات (حساباتك)</label><input id="pfTags" dir="ltr" placeholder="@yourname"></div></div>
<label>الخط الافتراضي</label><select id="pfFont"></select>
<label class="bkshow"><input type="checkbox" id="pfAuto"> حطها تلقائيًا في كل التصميمات</label>
<div class="sec"><label style="margin-top:0;text-align:center">الشعار</label><div class="hint" id="pfLogoNote"></div>
<div class="row"><button type="button" class="btn ghost" id="pfLogoSave">اعتمد الشعار الحالي</button><button type="button" class="btn ghost" id="pfLogoClr">امسح الشعار</button></div></div>
<div class="row" style="margin-top:16px"><button type="button" class="btn" id="pfSave">حفظ وتطبيق</button><button type="button" class="btn ghost" id="pfClose">إغلاق</button></div></div></div>`;
document.body.appendChild(ov);
const g=id=>ov.querySelector('#'+id);
g('pfFont').innerHTML='<option value="">افتراضي التصميم</option>'+FONTS.map(f=>`<option value="${f[0]}">${f[1]}</option>`).join('');
function logoNote(){g('pfLogoNote').textContent=P.logo?'فيه شعار محفوظ وبيظهر تلقائيًا.':'ضيف شعارك من زر الشعار في المحرر، وبعدين اعتمده هنا.'}
function fill(){g('pfName').value=P.name||'';g('pfSchool').value=P.school||'';g('pfPhone').value=P.phone||'';g('pfTags').value=P.tags||'';g('pfFont').value=P.font||'';g('pfAuto').checked=P.auto!==false;logoNote()}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(P));return true}catch(e){return false}}
function reapply(){applyCert();applyLogo();try{setTpl(curTpl,false)}catch(e){}try{refreshVTpl()}catch(e){}}
g('pfSave').onclick=()=>{P.name=g('pfName').value.trim().slice(0,60);P.school=g('pfSchool').value.trim().slice(0,60);P.phone=g('pfPhone').value.trim().slice(0,20);P.tags=g('pfTags').value.trim().slice(0,60);P.font=g('pfFont').value;P.auto=g('pfAuto').checked;
 if(!persist()){alert('مساحة التخزين ممتلئة');return}ov.classList.remove('open');if(P.auto)reapply()};
g('pfClose').onclick=()=>ov.classList.remove('open');ov.addEventListener('click',e=>{if(e.target===ov)ov.classList.remove('open')});
g('pfLogoSave').onclick=()=>{if(!logo||!logo.src){alert('ضيف الشعار الأول من المحرر');return}if(logo.src.length>600000){alert('الشعار كبير، استخدم صورة أصغر');return}P.logo=logo.src;persist();logoNote()};
g('pfLogoClr').onclick=()=>{delete P.logo;persist();logoNote()};
const b=document.createElement('button');b.className='tbtn';b.id='profBtn';b.type='button';b.textContent='ملفي';
const db=$('#designsBtn');db.parentNode.insertBefore(b,db);b.onclick=()=>{P=load();fill();ov.classList.add('open')};
// initial application
if(P.auto!==false&&has()){applyCert();applyLogo();try{if(ELS.teacher&&P.name&&ELS.teacher.text==='الأستاذ أحمد علي')ELS.teacher.text=P.name;if(ELS.phone&&P.phone&&/0100 000 0000/.test(ELS.phone.text))ELS.phone.text=wa();const tl=tagLine();if(tl&&!ELS.ptags)ELS.ptags=T('ptags','التاجات',250,614,{z:19,text:tl,size:11,weight:700,color:'#fff',bg:'rgba(0,0,0,.45)',radius:99,pad:'3px 14px'});if(P.font)Object.keys(ELS).forEach(k=>{if(ELS[k]&&typeof ELS[k]==='object'&&'font' in ELS[k]&&!k.startsWith('cust'))ELS[k].font=P.font});drawTexts()}catch(e){}}
})();
