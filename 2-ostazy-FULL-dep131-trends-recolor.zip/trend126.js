/* قوالب إعلان اتجاهات ٢٠٢٦ (أصلية): بينتو، زجاجي، أورورا، نيو بروتاليست، طين ناعم، تحريري. */
(function(){'use strict';
if(typeof TPLS==='undefined'||typeof mkEls==='undefined')return;
const fs=(s,m)=>Math.min(m,Math.floor(1000/Math.max(3,s.length)));
const box=(x,y,w,h,bg,ex)=>bl(x,y,w,h,bg,'border-radius:22px;'+(ex||''));
Object.assign(TPLS,{
bento:{label:'بينتو ٢٠٢٦',desc:'شبكة بطاقات مستديرة بألوان متباينة، كل معلومة في بطاقتها',hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',
 dots:['#0B1F44','#FBBF24','#F3F1EC'],
 fx(){const s=adSubjName();return bl(0,0,500,625,'#F1EEE7')+box(24,24,452,206,'#0B1F44')+box(24,242,220,146,pal.acc)+box(256,242,220,146,'#fff','box-shadow:0 2px 0 rgba(0,0,0,.06)')+box(24,400,452,84,'#14181F')+box(24,496,296,100,'#16A34A')+box(332,496,144,100,'#E4DFD2')+
  `<div style="position:absolute;left:256px;width:220px;top:262px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${fs(s,46)*.6}px;color:#0B1F44;line-height:1.1">${s}</div>`},
 els(){return mkEls([['season',NM.season,404,546,{text:TXT,size:11,color:'#3A352A',mw:120,weight:800}],
  ['kicker',NM.kicker,250,62,{text:'احجز مكانك الآن في',size:14,weight:800,color:pal.acc}],
  ['title',NM.title,250,142,{text:'العنوان',font:'Changa',size:44,weight:800,color:'#fff',mw:410}],
  ['teacher',NM.teacher,134,315,{text:'الأستاذ أحمد علي',font:'El Messiri',size:23,color:pal.onAcc||'#10203A',mw:190}],
  ['stage',NM.stage,366,352,{text:'المرحلة',size:13,weight:800,color:'#475569',mw:200}],
  ['sched',NM.sched,250,442,{text:SCH,size:16,weight:800,color:'#fff',mw:420}],
  ['phone',NM.phone,172,546,{text:PH,size:16,weight:800,color:'#fff'}]])}},
glass:{label:'زجاجي أورورا',desc:'لوح زجاجي شفاف فوق سحب ألوان متدرجة، نص أبيض هادئ',hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',
 dots:['#0A0F2C','#1D4ED8','#06B6D4'],
 fx(){const b=(x,y,r,c)=>`<div style="position:absolute;left:${x-r}px;top:${y-r}px;width:${2*r}px;height:${2*r}px;border-radius:50%;background:${c};filter:blur(46px);opacity:.85"></div>`;
  return bl(0,0,500,625,'#0A0F2C','overflow:hidden')+b(90,120,110,'#1D4ED8')+b(420,200,100,'#06B6D4')+b(300,560,120,pal.acc)+b(60,520,90,'#F97316')+
  bl(32,118,436,404,'rgba(255,255,255,.13)','border-radius:30px;border:1.5px solid rgba(255,255,255,.38);box-shadow:0 20px 50px rgba(0,0,0,.35)')},
 els(){return mkEls([['season',NM.season,250,56,{text:TXT,size:12,color:'#fff',weight:800,bg:'rgba(255,255,255,.16)',radius:99,pad:'4px 16px'}],
  ['kicker',NM.kicker,250,172,{text:'احجز مكانك الآن في',size:15,weight:700,color:'#DCE6FF'}],
  ['title',NM.title,250,262,{text:'العنوان',font:'Changa',size:48,weight:800,color:'#fff',mw:390}],
  ['teacher',NM.teacher,250,350,{text:'الأستاذ أحمد علي',font:'El Messiri',size:27,color:'#fff'}],
  ['stage',NM.stage,250,392,{text:'المرحلة',size:14,color:'#BAE6FD'}],
  ['sched',NM.sched,250,462,{text:SCH,size:15,weight:800,color:pal.onAcc||'#10203A',bg:pal.acc,radius:99,pad:'7px 22px'}],
  ['phone',NM.phone,250,572,{text:PH,size:15,weight:800,color:'#fff'}]])}},
aurora:{label:'تدرج شبكي ضخم',desc:'خلفية تدرجات شبكية ملوّنة واسم المادة عملاق شفاف',hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',
 dots:['#0B1F44','#F97316','#F59E0B'],
 fx(){const s=adSubjName();return bl(0,0,500,625,'radial-gradient(420px 360px at 15% 12%,#1D4ED8 0%,transparent 70%),radial-gradient(380px 340px at 90% 30%,#F97316 0%,transparent 70%),radial-gradient(420px 380px at 30% 100%,#F59E0B 0%,transparent 72%),#0B1F44')+
  `<div style="position:absolute;left:0;right:0;top:34px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${fs(s,190)}px;line-height:1.1;color:#fff;opacity:.2;white-space:nowrap">${s}</div>`+bl(40,300,420,2,'rgba(255,255,255,.5)')},
 els(){return mkEls([['season',NM.season,250,30,{text:TXT,size:11,color:'#fff',weight:800}],
  ['kicker',NM.kicker,250,268,{text:'احجز مكانك الآن',size:15,weight:800,color:'#FDE68A'}],
  ['title',NM.title,250,380,{text:'العنوان',font:'Changa',size:52,weight:800,color:'#fff',mw:420}],
  ['teacher',NM.teacher,250,452,{text:'الأستاذ أحمد علي',font:'El Messiri',size:28,color:'#fff'}],
  ['stage',NM.stage,250,490,{text:'المرحلة',size:14,color:'#BAE6FD'}],
  ['sched',NM.sched,250,540,{text:SCH,size:15,weight:800,color:'#0B1F44',bg:'#fff',radius:99,pad:'7px 22px'}],
  ['phone',NM.phone,250,590,{text:PH,size:14,weight:800,color:'#fff'}]])}},
neobrut:{label:'نيو بروتاليست',desc:'حدود سوداء سميكة وظلال مزاحة وألوان صريحة مسطحة',hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',
 dots:['#FFE066','#111','#FF8A1F'],
 fx(){const s=adSubjName(),bx=(x,y,w,h,c,r)=>bl(x,y,w,h,c,`border:3px solid #111;box-shadow:6px 6px 0 #111;border-radius:${r||10}px`);
  return bl(0,0,500,625,'#FFE066')+bx(34,96,432,170,'#fff')+bx(34,296,250,66,'#FF8A1F')+bx(300,296,166,66,'#5EB6FF')+bx(34,392,432,64,'#111',10)+bx(34,490,300,64,'#7CE38B')+
  `<div style="position:absolute;left:0;right:0;top:18px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:${fs(s,60)*.34}px;color:#111;letter-spacing:1px">${s} ★ ${s} ★ ${s}</div>`},
 els(){return mkEls([['season',NM.season,250,64,{text:TXT,size:12,color:'#111',weight:800}],
  ['kicker',NM.kicker,250,128,{text:'احجز مكانك الآن في',size:15,weight:800,color:'#111'}],
  ['title',NM.title,250,202,{text:'العنوان',font:'Changa',size:48,weight:800,color:'#111',accw:'#C2410C',mw:400}],
  ['teacher',NM.teacher,159,329,{text:'الأستاذ أحمد علي',font:'El Messiri',size:23,color:'#111',mw:230}],
  ['stage',NM.stage,383,329,{text:'المرحلة',size:11.5,weight:800,color:'#111',mw:150}],
  ['sched',NM.sched,250,424,{text:SCH,size:16,weight:800,color:'#FFE066',mw:410}],
  ['phone',NM.phone,184,522,{text:PH,size:16,weight:800,color:'#111'}]])}},
clay:{label:'طين ناعم',desc:'كرات وأشكال باستيل ناعمة بظلال داخلية تعطي إحساس ثلاثي الأبعاد',hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',
 dots:['#ECFEFF','#38BDF8','#FB923C'],
 fx(){const o=(x,y,r,c)=>`<div style="position:absolute;left:${x-r}px;top:${y-r}px;width:${2*r}px;height:${2*r}px;border-radius:50%;background:${c};box-shadow:inset -14px -16px 30px rgba(0,0,0,.12),inset 12px 12px 26px rgba(255,255,255,.55),0 22px 34px rgba(10,60,100,.18)"></div>`;
  return bl(0,0,500,625,'linear-gradient(180deg,#ECFEFF,#E0F2FE)')+o(410,90,70,'#38BDF8')+o(80,130,44,'#FB923C')+o(440,520,56,'#FCD34D')+o(60,560,34,'#5EEAD4')+bl(40,236,420,250,'rgba(255,255,255,.7)','border-radius:36px;box-shadow:0 20px 40px rgba(10,60,100,.14)')},
 els(){return mkEls([['season',NM.season,200,40,{text:TXT,size:11,color:'#0C4A6E',weight:800}],
  ['kicker',NM.kicker,250,200,{text:'احجز مكانك الآن في',size:15,weight:800,color:'#0E7490'}],
  ['title',NM.title,250,290,{text:'العنوان',font:'Changa',size:46,weight:800,color:'#0B2A4A',accw:'#0E7490',mw:380}],
  ['teacher',NM.teacher,250,368,{text:'الأستاذ أحمد علي',font:'El Messiri',size:26,color:'#0B2A4A'}],
  ['stage',NM.stage,250,408,{text:'المرحلة',size:14,color:'#4B6A88'}],
  ['sched',NM.sched,250,452,{text:SCH,size:14,weight:800,color:'#fff',bg:'#0E7490',radius:99,pad:'6px 20px'}],
  ['phone',NM.phone,250,560,{text:PH,size:15,weight:800,color:'#0B2A4A'}]])}},
editorial:{label:'تحريري هادئ',desc:'مساحة بيضاء واسعة وخطوط رفيعة وعنوان كبير بحرف أنيق',hasPhoto:false,shape:null,dood:false,ribbon:false,titleFontFixed:true,ownArt:true,art:'none',
 dots:['#F5F2EA','#111','#FBBF24'],
 fx(){const y=new Date().getFullYear()+1;return bl(0,0,500,625,'#F5F2EA')+
  `<div style="position:absolute;left:0;right:0;top:34px;text-align:center;font-family:Changa,Tajawal,sans-serif;font-weight:800;font-size:150px;line-height:1;color:#111;opacity:.06">${y}</div>`+bl(40,86,420,2,'#111')+bl(40,500,420,2,'#111')+bl(40,30,14,14,pal.acc)},
 els(){return mkEls([['season',NM.season,250,62,{text:TXT,size:12,color:'#111',weight:800}],
  ['kicker',NM.kicker,250,160,{text:'احجز مكانك الآن في',size:14,weight:700,color:'#6B6455'}],
  ['title',NM.title,250,252,{text:'العنوان',font:'El Messiri',size:56,weight:800,color:'#111',accw:'#B45309',mw:410}],
  ['teacher',NM.teacher,250,342,{text:'الأستاذ أحمد علي',font:'Amiri',size:30,color:'#111'}],
  ['stage',NM.stage,250,384,{text:'المرحلة',size:14,color:'#6B6455'}],
  ['sched',NM.sched,250,440,{text:SCH,size:15,weight:800,color:'#111'}],
  ['phone',NM.phone,250,540,{text:PH,size:15,weight:800,color:'#fff',bg:'#111',radius:4,pad:'7px 22px'}]])}}
});
try{if(typeof renderAdGrid==='function')renderAdGrid()}catch(e){}
})();
