/* ملفي: بيانات المدرس نفسه (اسم، سنتر، واتساب، تاجات، خط، شعار) تتحط افتراضيًا في الشهادات والإعلانات والستوري.
   محفوظة على جهاز المدرس فقط. مفيش أي بيانات طلبة. */
(function(){'use strict';
const KEY='ostazyProfileV1';
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){return{}}};
let P=load();
const PLAT=[['ig','إنستجرام'],['fb','فيسبوك'],['tt','تيك توك'],['yt','يوتيوب'],['x','إكس'],['tg','تيليجرام'],['sc','سناب'],['web','موقع']];
const ICO={
 ig:'<rect width="24" height="24" rx="6" fill="#E1306C"/><rect x="5.5" y="5.5" width="13" height="13" rx="4" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="12" cy="12" r="3.1" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="16.1" cy="7.9" r="1" fill="#fff"/>',
 fb:'<circle cx="12" cy="12" r="12" fill="#1877F2"/><path d="M13.2 19.5v-6h2l.4-2.4h-2.4V9.6c0-.7.3-1.2 1.3-1.2h1.2V6.2c-.2 0-1-.1-1.8-.1-1.8 0-3 1.1-3 3.1v1.9H8.8v2.4h2.1v6z" fill="#fff"/>',
 tt:'<rect width="24" height="24" rx="6" fill="#111"/><path d="M13 5.5v8.2a2.4 2.4 0 1 1-2.4-2.4" fill="none" stroke="#25F4EE" stroke-width="2" transform="translate(-.7 .5)"/><path d="M13 5.5v8.2a2.4 2.4 0 1 1-2.4-2.4M13 5.5c.2 1.8 1.4 3 3.3 3.1" fill="none" stroke="#fff" stroke-width="2"/>',
 yt:'<rect y="4" width="24" height="16" rx="5" fill="#FF0000"/><path d="M10 8.6v6.8l6-3.4z" fill="#fff"/>',
 x:'<rect width="24" height="24" rx="6" fill="#111"/><path d="M6.5 6.5l11 11M17.5 6.5l-11 11" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/>',
 tg:'<circle cx="12" cy="12" r="12" fill="#229ED9"/><path d="M5.5 11.7l12-4.7-2 10.2-3.4-2.5-1.8 1.7-.4-3.4 5.6-5-7 4.4z" fill="#fff"/>',
 sc:'<rect width="24" height="24" rx="6" fill="#FFD400"/><path d="M12 5.5c-2.2 0-3.3 1.6-3.3 3.6v1.6c-.8 0-1.2.4-1.2.8 0 .5.7.8 1.4 1-.3 1-1.2 1.9-2.4 2.2.1.5 1.3.6 1.9.8.2.5.3 1 .9 1 .6 0 1.2-.4 2.7-.4s2.1.4 2.7.4c.6 0 .7-.5.9-1 .6-.2 1.8-.3 1.9-.8-1.2-.3-2.1-1.2-2.4-2.2.7-.2 1.4-.5 1.4-1 0-.4-.4-.8-1.2-.8V9.1c0-2-1.1-3.6-3.3-3.6z" fill="#fff" stroke="#111" stroke-width=".9"/>',
 web:'<circle cx="12" cy="12" r="12" fill="#0B1F44"/><circle cx="12" cy="12" r="6.5" fill="none" stroke="#00D4FF" stroke-width="1.6"/><ellipse cx="12" cy="12" rx="2.8" ry="6.5" fill="none" stroke="#00D4FF" stroke-width="1.4"/><path d="M5.5 12h13" stroke="#00D4FF" stroke-width="1.4"/>'};
const svgOf=p=>'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'+(ICO[p]||ICO.web)+'</svg>';
const uriOf=p=>'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svgOf(p));
const IMGS={};PLAT.forEach(([p])=>{const i=new Image();i.src=uriOf(p);IMGS[p]=i});
const cleanU=u=>String(u||'').replace(/[<>"'`]/g,'').trim().slice(0,40);
if(!Array.isArray(P.accts)){P.accts=[];if(P.tags){P.accts.push({p:/^@/.test(P.tags)?'ig':'web',u:cleanU(P.tags)})}}
const accts=()=>(P.accts||[]).filter(a=>a&&a.u&&IMGS[a.p]).slice(0,6);
const has=()=>!!(P.name||P.school||P.phone||accts().length||P.font||P.logo);

const wa=()=>P.phone?('واتساب: '+P.phone):'';
const esc=t=>String(t).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const tagLine=()=>{const it=accts().map(a=>'<span dir="ltr" style="display:inline-flex;align-items:center;gap:4px;margin:0 6px"><img src="'+uriOf(a.p)+'" width="14" height="14" style="display:block">'+esc(a.u)+'</span>');const sc=P.school?'<span style="margin:0 6px">'+esc(P.school)+'</span>':'';return (sc+it.join('')).trim()};
// ---- ads ----
const _aac=applyAdCopy;
applyAdCopy=function(){_aac.apply(this,arguments);if(!P.auto&&P.auto!==undefined)return;if(!has())return;
 if(ELS.teacher&&P.name)ELS.teacher.text=P.name;
 if(ELS.phone&&P.phone)ELS.phone.text=wa();
 if(accts().length||P.school){const tl=tagLine();if(tl){ELS.ptags=T('ptags','التاجات',250,614,{z:19,text:tl,size:11,weight:700,color:'#fff',bg:'rgba(0,0,0,.5)',radius:14,pad:'4px 10px',mw:470,lh:1.6})}}
 if(P.font)Object.keys(ELS).forEach(k=>{if(ELS[k]&&typeof ELS[k]==='object'&&'font' in ELS[k])ELS[k].font=P.font})};
// ---- stories ----
const _bv=buildVTpl;
buildVTpl=function(){const t=_bv.apply(this,arguments);if(P.auto===false||!has()||!t||!t.layers)return t;
 const f=P.font||'Cairo',y=t.height-84,L=[];
 if(P.name&&!t.layers.some(l=>l.value===P.name))L.push({type:'text',value:P.name,font:f,weight:800,size:24,color:'#FFFFFF',y:y-40,x:270,maxW:440,fadeIn:[.2,1],alpha:.95});
 const bot=P.phone||'';
 if(bot)L.push({type:'text',value:bot,font:f,weight:700,size:20,color:'#FFFFFF',y:y,x:270,maxW:460,fadeIn:[.4,1.2],alpha:.9});
 t.layers=t.layers.concat(L);
 if(P.font)t.layers.forEach(l=>{if(l.type==='text')l.font=P.font});return t};
const _fv=fillVFields;fillVFields=function(){_fv.apply(this,arguments);if(P.auto===false||!P.name)return;document.querySelectorAll('#vFields input').forEach(i=>{if(i.value==='مدرّسك'||i.value==='مدرّسكم')i.value=P.name})};
const _df=drawFrame;drawFrame=function(tpl,t){_df.apply(this,arguments);if(P.auto===false||!tpl||!tpl.layers)return;const A=accts();if(!A.length)return;
 vx.save();vx.globalAlpha=Math.min(1,Math.max(0,(t-.6)/.6));vx.direction='ltr';vx.textAlign='left';vx.textBaseline='alphabetic';vx.font='700 20px '+(P.font||'Cairo')+',Cairo,sans-serif';
 const items=A.map(a=>({p:a.p,u:a.u,w:30+vx.measureText(a.u).width})),rows=[[]];let cw=0;
 items.forEach(it=>{if(cw+it.w>440&&rows[rows.length-1].length){rows.push([]);cw=0}rows[rows.length-1].push(it);cw+=it.w+22});
 rows.forEach((r,i)=>{const tw=r.reduce((a,b)=>a+b.w+22,-22);let x=(tpl.width-tw)/2;const y=tpl.height-42+i*34;
  r.forEach(it=>{const im=IMGS[it.p];if(im.complete&&im.naturalWidth)vx.drawImage(im,x,y-20,26,26);vx.fillStyle='#fff';vx.fillText(it.u,x+32,y);x+=it.w+22})});
 vx.restore()};
// ---- certificates ----
function applyCert(){if(P.name&&$('#cTeacher'))$('#cTeacher').value=P.name;if(P.school&&$('#cSchool'))$('#cSchool').value=P.school}
// ---- logo ----
function applyLogo(){if(!P.logo||logo)return;const im=new Image();im.onload=()=>{if(logo)return;logo={src:P.logo,x:430,y:64,s:Math.min(1,110/(im.naturalWidth||120)),r:0};const d=$('#logoDel');if(d)d.hidden=false;renderLogo()};im.src=P.logo}
// ---- dialog ----
const css=document.createElement('style');css.textContent=`#profOv{display:none;position:fixed;inset:0;z-index:220;background:rgba(0,27,77,.45);align-items:center;justify-content:center;padding:16px}#profOv.open{display:flex}#profBox{background:var(--card,#fff);color:var(--ink);border:1px solid var(--line);border-radius:16px;max-width:480px;width:100%;max-height:88dvh;overflow:auto;padding:0;direction:rtl;font-family:Tajawal,Cairo,sans-serif;box-shadow:0 18px 50px rgba(0,27,77,.35)}#profHead{background:#0B1F44;color:#fff;padding:16px 18px 14px;border-radius:16px 16px 0 0;text-align:center;border-bottom:3px solid #00D4FF}#profHead h3{margin:0;font-size:18px;font-weight:800}#profHead p{margin:6px 0 0;font-size:12px;color:#B6C7DD;font-weight:600}#profBody{padding:14px 18px 18px}#profBody .g2{display:grid;grid-template-columns:1fr 1fr;gap:10px}@media(max-width:420px){#profBody .g2{grid-template-columns:1fr}}#profBody label{display:block;margin:10px 0 5px;font-weight:700;font-size:12.5px;color:var(--mute)}#profBody input:not([type=checkbox]),#profBody select{width:100%;box-sizing:border-box;min-height:42px;font:inherit;font-size:14px;color:var(--ink);border:1px solid var(--line);border-radius:10px;background:#fff;text-align:center;text-align-last:center;padding:0 12px;display:block}#profBody input:focus,#profBody select:focus{outline:2px solid #00D4FF;outline-offset:1px}#profBody .sec{margin-top:14px;padding-top:12px;border-top:1px solid var(--line)}#profBody .row{display:flex;gap:8px;margin-top:10px}#profBody .row button{flex:1;min-height:44px;display:flex;align-items:center;justify-content:center;text-align:center;padding:0 10px;line-height:1.2;box-sizing:border-box}@media(max-width:600px){#profOv{padding-top:64px;align-items:flex-start}#profBox{max-height:calc(100dvh - 80px)}}#profBody .hint{font-size:12px;color:var(--mute);text-align:center;margin:4px 0 0;font-weight:600}#profBody .acct{margin:8px 0;padding:8px;border:1px solid var(--line);border-radius:12px}#profBody .chips{display:flex;gap:6px;flex-wrap:wrap;justify-content:center}#profBody .chip{width:36px;height:36px;min-height:0!important;flex:none!important;padding:0!important;border:2px solid transparent;border-radius:10px;background:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}#profBody .chip.on{border-color:#00D4FF;background:#E6F9FF}#profBody .ainp{display:flex;gap:6px;margin-top:8px}#profBody .ainp input{flex:1}#profBody .ainp .del{flex:none!important;width:42px;min-height:42px!important;padding:0!important}#profBody .bkshow{margin-top:14px;justify-content:center}`;document.head.appendChild(css);
const ov=document.createElement('div');ov.id='profOv';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');
ov.innerHTML=`<div id="profBox"><div id="profHead"><h3>ملفي</h3><p>بياناتك بتتحط تلقائيًا في الشهادات والإعلانات والستوري. بتتحفظ على جهازك بس.</p></div><div id="profBody">
<div class="g2"><div><label>اسمك</label><input id="pfName" placeholder="الأستاذ أحمد علي"></div><div><label>السنتر / المدرسة</label><input id="pfSchool"></div>
<div><label>رقم الواتساب</label><input id="pfPhone" dir="ltr" inputmode="tel" placeholder="01xxxxxxxxx"></div></div>
<div class="sec"><label style="margin-top:0;text-align:center">حساباتك (تاجات)</label><div id="pfAccts"></div><div class="row"><button type="button" class="btn ghost" id="pfAddAcct">＋ إضافة حساب</button></div></div>
<label>الخط الافتراضي</label><select id="pfFont"></select>
<label class="bkshow"><input type="checkbox" id="pfAuto"> حطها تلقائيًا في كل التصميمات</label>
<div class="sec"><label style="margin-top:0;text-align:center">الشعار</label><div id="pfLogoPrev"></div><div class="hint" id="pfLogoNote"></div>
<input type="file" id="pfLogoFile" accept="image/*" style="position:absolute;width:1px;height:1px;opacity:0;pointer-events:none" tabindex="-1">
<div class="row"><button type="button" class="btn ghost" id="pfLogoUp">رفع شعار جديد</button><button type="button" class="btn ghost" id="pfLogoClr">امسح الشعار</button></div></div>
<div class="row" style="margin-top:16px"><button type="button" class="btn" id="pfSave">حفظ وتطبيق</button><button type="button" class="btn ghost" id="pfClose">إغلاق</button></div></div></div>`;
document.body.appendChild(ov);
const g=id=>ov.querySelector('#'+id);
g('pfFont').innerHTML='<option value="">افتراضي التصميم</option>'+FONTS.map(f=>`<option value="${f[0]}">${f[1]}</option>`).join('');
function renderAccts(){const box=g('pfAccts');box.innerHTML='';
 (P.accts||[]).forEach((a,i)=>{const r=document.createElement('div');r.className='acct';
  r.innerHTML='<div class="chips">'+PLAT.map(([p,n])=>'<button type="button" class="chip'+(a.p===p?' on':'')+'" data-p="'+p+'" title="'+n+'" aria-label="'+n+'"><svg viewBox="0 0 24 24" width="22" height="22">'+ICO[p]+'</svg></button>').join('')+'</div><div class="ainp"><input dir="ltr" maxlength="40" placeholder="اسم المستخدم" value="'+esc(a.u||'').replace(/"/g,'&quot;')+'"><button type="button" class="btn ghost del" aria-label="حذف الحساب">✕</button></div>';
  r.querySelectorAll('.chip').forEach(c=>c.onclick=()=>{a.p=c.dataset.p;renderAccts()});
  r.querySelector('input').oninput=e=>{a.u=e.target.value};r.querySelector('.del').onclick=()=>{P.accts.splice(i,1);renderAccts()};box.appendChild(r)});
 g('pfAddAcct').style.display=(P.accts||[]).length>=6?'none':''}
g('pfAddAcct').onclick=()=>{(P.accts=P.accts||[]).push({p:'ig',u:''});renderAccts()};
function logoNote(){const pv=g('pfLogoPrev');pv.innerHTML=P.logo?'<img alt="معاينة الشعار" style="display:block;margin:6px auto;max-width:140px;max-height:90px;object-fit:contain;border:1px solid var(--line);border-radius:10px;padding:6px;background:#fff">':'';if(P.logo)pv.firstChild.src=P.logo;g('pfLogoNote').textContent=P.logo?'الشعار ده هو الافتراضي وبيظهر تلقائيًا في تصاميمك.':'اختار صورة شعارك من جهازك، وهتتحفظ كافتراضي.'}
function fill(){g('pfName').value=P.name||'';g('pfSchool').value=P.school||'';g('pfPhone').value=P.phone||'';renderAccts();g('pfFont').value=P.font||'';g('pfAuto').checked=P.auto!==false;logoNote()}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(P));return true}catch(e){return false}}
function reapply(){applyCert();applyLogo();try{setTpl(curTpl,false)}catch(e){}try{refreshVTpl()}catch(e){}}
g('pfSave').onclick=()=>{P.name=g('pfName').value.trim().slice(0,60);P.school=g('pfSchool').value.trim().slice(0,60);P.phone=g('pfPhone').value.trim().slice(0,20);P.accts=(P.accts||[]).map(a=>({p:a.p,u:cleanU(a.u)})).filter(a=>a.u).slice(0,6);delete P.tags;P.font=g('pfFont').value;P.auto=g('pfAuto').checked;
 if(!persist()){alert('مساحة التخزين ممتلئة');return}ov.classList.remove('open');if(P.auto)reapply()};
g('pfClose').onclick=()=>ov.classList.remove('open');ov.addEventListener('click',e=>{if(e.target===ov)ov.classList.remove('open')});
g('pfLogoUp').onclick=()=>g('pfLogoFile').click();
g('pfLogoFile').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(!/^image\//.test(f.type)){alert('اختار صورة');return}
 const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,500/Math.max(im.naturalWidth,im.naturalHeight)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.naturalWidth*k));c.height=Math.max(1,Math.round(im.naturalHeight*k));c.getContext('2d').drawImage(im,0,0,c.width,c.height);
  let u=c.toDataURL('image/png');if(u.length>600000)u=c.toDataURL('image/jpeg',.85);if(u.length>600000){alert('الصورة كبيرة، جرّب صورة أصغر');return}
  P.logo=u;if(!persist()){alert('مساحة التخزين ممتلئة');return}logo=null;applyLogo();logoNote()};im.onerror=()=>alert('الصورة مش مقروءة');im.src=r.result};r.readAsDataURL(f)};
g('pfLogoClr').onclick=()=>{delete P.logo;persist();logoNote()};
const b=document.createElement('button');b.className='tbtn';b.id='profBtn';b.type='button';b.textContent='ملفي';
const db=$('#designsBtn');db.parentNode.insertBefore(b,db);b.onclick=()=>{P=load();fill();ov.classList.add('open')};
// initial application
if(P.auto!==false&&has()){applyCert();applyLogo();try{if(ELS.teacher&&P.name&&ELS.teacher.text==='الأستاذ أحمد علي')ELS.teacher.text=P.name;if(ELS.phone&&P.phone&&/0100 000 0000/.test(ELS.phone.text))ELS.phone.text=wa();const tl=tagLine();if(tl&&!ELS.ptags)ELS.ptags=T('ptags','التاجات',250,614,{z:19,text:tl,size:11,weight:700,color:'#fff',bg:'rgba(0,0,0,.5)',radius:14,pad:'4px 10px',mw:470,lh:1.6});if(P.font)Object.keys(ELS).forEach(k=>{if(ELS[k]&&typeof ELS[k]==='object'&&'font' in ELS[k]&&!k.startsWith('cust'))ELS[k].font=P.font});drawTexts()}catch(e){}}
})();
