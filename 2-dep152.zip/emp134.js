(function(){
var css='.empty-card{margin:14px 0;padding:28px 20px;text-align:center;border-radius:20px;background:linear-gradient(135deg,rgba(14,124,134,.12),rgba(11,79,138,.10));border:1px solid rgba(14,124,134,.25)}.empty-card .eic{width:64px;height:64px;margin:0 auto 12px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0E7C86,#0B4F8A);color:#fff}.empty-card h3{margin:0 0 6px;font-size:20px;font-weight:800}.empty-card p{margin:0 0 16px;opacity:.8}.empty-card button{min-width:220px;height:48px;font-size:16px;font-weight:800;display:inline-flex;align-items:center;justify-content:center}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
var ICON='<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M19 8v6M16 11h6"/></svg>';
function run(){
 document.querySelectorAll('#view p,#view div,#view section').forEach(function(e){
  if(e.dataset.emp||e.children.length>1)return;
  if(!/أضف مجموعة الأول|أضف مجموعتك الأولى/.test(e.textContent||'')||(e.textContent||'').length>60)return;
  e.dataset.emp='1';
  var d=document.createElement('div');d.className='empty-card';
  d.innerHTML='<div class="eic">'+ICON+'</div><h3>لسه مفيش مجموعات</h3><p>ابدأ بإضافة مجموعتك الأولى وطلابها، وباقي الشاشات هتشتغل لوحدها.</p><button type="button" class="th-btn">أضف مجموعتك الأولى</button>';
  d.querySelector('button').onclick=function(){var t=document.querySelector('button[data-t="g"]');if(t)t.click()};
  e.replaceWith(d);
 });
}
var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(run,150)}).observe(document.documentElement,{childList:true,subtree:true});run();
})();
